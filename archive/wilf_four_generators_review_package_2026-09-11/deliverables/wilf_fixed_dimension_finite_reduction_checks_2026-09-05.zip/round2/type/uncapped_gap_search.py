import numpy as np,random,json
from scipy.optimize import linprog
rng=random.Random(23689);best=3.;records=[]
for it in range(5000):
 n=rng.randint(3,35)
 p=sorted([rng.randint(1,n) for _ in range(n)],reverse=True)
 q=sorted([rng.randint(1,n) for _ in range(n)],reverse=True)
 f=sorted([rng.randint(1,n) for _ in range(n)],reverse=True)
 h=[[min(p[x],q[y]) if y<f[x] else 0 for y in range(n)] for x in range(n)]
 m=sum(map(sum,h))
 means=[sum((x+.5)*h[x][y] for x in range(n) for y in range(n))/m,sum((y+.5)*h[x][y] for x in range(n) for y in range(n))/m,sum(h[x][y]**2/2 for x in range(n) for y in range(n))/m]
 tops=[]
 for x in range(n):
  for y in range(n):
   z=h[x][y]
   if z and (x==n-1 or h[x+1][y]<z) and(y==n-1 or h[x][y+1]<z):tops.append([x+1,y+1,z])
 res=linprog([-v for v in means],A_ub=tops,b_ub=np.ones(len(tops)),bounds=[(0,None)]*3,method='highs')
 kap=3+4*res.fun
 if kap<best:
  best=kap;r=dict(it=it,n=n,m=m,kappa=kap,p=p,q=q,f=f,weights=res.x.tolist());records.append(r);print(json.dumps(r),flush=True)
 if kap<1/3-1e-9:break
open('round2/type/uncapped_gap_search.json','w').write(json.dumps(records,indent=2))
