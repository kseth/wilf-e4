from math import gcd
from itertools import combinations
import sys,random,json
sys.path.insert(0,'prior/wilf_edim4_six_point_verification_2026-09-05')
from wilf_work import apery

def sg_two(n,a,b):
 if n<0:return False
 return any((n-i*a)%b==0 for i in range(n//a+1))

def critical(gens):
 out=[]
 for i,g in enumerate(gens):
  others=[h for j,h in enumerate(gens) if j!=i]
  cap=min(h//gcd(h,g)*g for h in others)
  vals=[False]*(cap+1);vals[0]=True
  hit=None
  for v in range(1,cap+1):
   vals[v]=any(v>=h and vals[v-h] for h in others)
   if v%g==0 and vals[v]:hit=v;break
  out.append(hit)
 return out

def types(gens):
 rr=apery(gens)
 if not rr:return None
 m,a,best=rr;ap=[w for w,x in best]
 def ins(x):return x>=0 and ap[x%m]<=x
 return sum(w>0 and all(ins(w+b-m) for b in a) for w in ap)

if __name__=='__main__':
 rng=random.Random(987)
 sec=[];non=[]
 for i in range(10000):
  a,b=sorted(rng.sample(range(2,13),2));c,d=sorted(rng.sample(range(2,13),2))
  if gcd(a,b)>1 or gcd(c,d)>1:continue
  p,q=sorted(rng.sample(range(2,101),2))
  if gcd(p,q)>1:continue
  gens=[p*a,p*b,q*c,q*d]
  if len(set(gens))<4:continue
  cv=critical(gens)
  if cv!=[p*a*b,p*a*b,q*c*d,q*c*d] or cv[0]==cv[2]:continue
  # Require criticalvalues to have only their intended pure factorizations.
  mixed=False
  for val in [cv[0],cv[2]]:
   fac=[]
   for x in range(val//gens[0]+1):
    for y in range((val-x*gens[0])//gens[1]+1):
     for z in range((val-x*gens[0]-y*gens[1])//gens[2]+1):
      rem=val-x*gens[0]-y*gens[1]-z*gens[2]
      if rem%gens[3]==0:
       u=rem//gens[3]
       if sum(k>0 for k in [x,y,z,u])>1:mixed=True;break
     if mixed:break
    if mixed:break
   if mixed:break
  if mixed:continue
  gluing=sg_two(q,a,b) and sg_two(p,c,d)
  r=dict(gens=gens,scales=[p,q],pairs=[[a,b],[c,d]],gluing=gluing,t=types(gens))
  sec.append(r)
  if not gluing:
   non.append(r)
   if len(non)>=3:break
 print(json.dumps(dict(secondary_count=len(sec),non_gluing=non),indent=2))
