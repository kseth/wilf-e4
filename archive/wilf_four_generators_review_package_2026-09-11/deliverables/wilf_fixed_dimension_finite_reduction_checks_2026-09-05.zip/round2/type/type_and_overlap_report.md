# Type route: scope correction, a valid forest estimate, and its obstruction

Date: 5 September 2026. This note does not prove or disprove Wilf's conjecture.

## 1. The residual type range begins at seven

Let m,c be the multiplicity and conductor and let

Z_w = Ap(S,m) ∩ [c,c+m).

For every w∈Z_w, f=w−m is a gap and every positive s∈S satisfies s≥m, so f+s≥w≥c and therefore f+s∈S. Hence f is pseudo-Frobenius. Conversely every gap f∈[c−m,c) has f+m∈Ap(S,m)∩[c,c+m). Consequently

|Z_w| = |([c−m,c)\S)| = |PF(S)∩[c−m,c)| ≤ t(S).

The prior complete six-point theorem therefore already implies Wilf for every minimally four-generated semigroup with type at most six. This includes type four and five; type four is not a new unresolved subcase of this project. This conclusion inherits the prior theorem's finite computer-assisted part. It is a corollary of the existing result, rather than new progress into its residual class.

Any possible residual counterexample must have t≥7 and at least seven pseudo-Frobenius numbers in [c−m,c).

## 2. A forest lower bound for the redundancy defect

Put L=S∩[0,c), n=|L|, F=c−1, PF(S)={f_1,...,f_t}, and

G_i={f_i−s:s∈S, 0≤s≤f_i}.

Each G_i is a set of gaps and these sets cover the gap set. Write

λ_i=|G_i|,
σ=Σ_i(n−λ_i),
ν(x)=|{i:x∈G_i}|,
Θ=Σ_{x gap}(ν(x)−1).

Counting the incidences yields the exact established identity

W_4=(3−t)n+σ+Θ.

Define the complete weighted graph on the t pseudo-Frobenius numbers by

b_ij=|G_i∩G_j|.

**Forest lemma.** For every forest E on these vertices,

Σ_{ij∈E} b_ij ≤ Θ.

**Proof.** Exchange the order of summation. A gap x contributes the number of forest edges induced on its ν(x) dominating vertices. An induced subgraph of a forest has at most ν(x)−1 edges. Sum over all gaps. ∎

Let B be the weight of a maximum spanning tree. Since all weights are nonnegative this also maximizes total weight among all forests (zero edges may connect components). Then

W_4 ≥ σ+B−(t−3)n.

This is a valid sufficient criterion, applicable also when |Z_w|≥7. The proof only uses finite set incidence and the exact defect identity. It does not prove the sufficient condition universally.

## 3. Exact residue computation

Let A_r be the Apéry representative of residue r modulo m. For any integer f≥0,

λ(f)=Σ_{r=0}^{m−1} max(0, floor((f−A_r)/m)+1).

For f_i<f_j put d=f_j−f_i. A gap x belongs to G_i∩G_j precisely when s=f_i−x lies in S and s+d lies in S, with 0≤s≤f_i. Since A_{r+d}−d is congruent to r, the first allowed s of residue r is

max(A_r,A_{(r+d) mod m}−d).

Thus

b_ij=Σ_r max(0, floor((f_i−max(A_r,A_{r+d}−d))/m)+1).

There is no enumeration through the whole conductor in these formulas.

## 4. The proposed universal forest criterion is false

An initial seeded diagnostic tested 6,000 generator tuples. Of these, 1,266 were genuine minimally four-generated semigroups of type at least seven; all satisfied σ+B≥(t−3)n. This is only exploratory evidence.

A subsequent adversarial generator distribution found

S=⟨175,185,201,202⟩,

with exact invariants

m=175, c=1846, n=677, t=11, |Z_w|=10, W_4=862,
σ=554, Θ=5724, B=4853.

Its pseudo-Frobenius numbers are

1626,1724,1775,1792,1805,1808,1819,1821,1825,1835,1845.

The forest certificate gives

σ+B−(t−3)n = 554+4853−8·677 = −9.

Thus the maximum spanning forest does not capture enough redundancy even for a semigroup satisfying Wilf with a margin of 862. This is a counterexample to an auxiliary stronger inequality, not to Wilf. It prevents claiming that a universal graph-theoretic forest estimate closes the residual range.

## 5. A newly located primary source

Kazimierz Chomicz, *The type and cardinality of minimal presentations of numerical semigroups with embedding dimension four*, arXiv:2609.04000v1 (3 September 2026),
https://arxiv.org/html/2609.04000v1

is later than the prior checkpoints' main source searches. It proves t−11≤η≤4t+5, where η is minimal-presentation cardinality, using an Apéry L-shape construction. Lemma 2.2 divides semigroups into a primary case, permitting an ordered generator base for which two critical pure-power relations involve that base, and a secondary case with paired pure-power critical relations. Propositions 2.7–2.8 construct L-shapes by truncating one coordinate; mixed exclusions are controlled by (2,2)-type relations plus critical exceptions. This is relevant structure, but its preferred base d_0 is not necessarily the multiplicity. Any attempt to use it in the current weighted-line estimates must account for that difference. Its conclusions do not establish Wilf.

Primary source for the exact defect identity:
Mohammad F. Marashdeh, *An upper bound for the type of a numerical semigroup, and a reduction of Wilf's conjecture*, arXiv:2608.12531v1,
https://arxiv.org/html/2608.12531v1

Neither source supplies the missing estimate needed to close the remaining e=4 range.
