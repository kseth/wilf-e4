import sys,random,json
sys.path.insert(0,'prior/wilf_edim4_six_point_verification_2026-09-05')
from wilf_work import apery

def lam(ap,x):
 m=len(ap)
 return sum(max(0,(x-w)//m+1) for w in ap)

def analyze(gens):
 r=apery(gens)
 if r is None:return
 m,a,best=r
 ap=[w for w,x in best]
 def isin(x):return x>=0 and ap[x%m]<=x
 F=max(ap)-m;c=F+1;g=sum(w//m for w in ap);n=c-g
 pf=sorted(w-m for w in ap if all(not isin(w+b-m) for b in a))
 # w+b not Apery iff w+b-m in S, so reverse condition!
 pf=sorted(w-m for w in ap if w>0 and all(isin(w+b-m) for b in a))
 t=len(pf)
 if t<7:return
 lams=[lam(ap,f) for f in pf]
 sigma=t*n-sum(lams)
 edges=[]
 for i,f in enumerate(pf):
  for j in range(i+1,t):
   d=pf[j]-f
   overlap=sum(max(0,(f-max(ap[r],ap[(r+d)%m]-d))//m+1) for r in range(m))
   edges.append((overlap,i,j))
 parents=list(range(t))
 def root(i):
  while i!=parents[i]:
   parents[i]=parents[parents[i]];i=parents[i]
  return i
 weight=0;chosen=[]
 for o,i,j in sorted(edges,reverse=True):
  ri,rj=root(i),root(j)
  if ri!=rj:
   parents[ri]=rj;weight+=o;chosen.append((i,j,o))
 theta=sum(lams)-g
 W=4*n-c
 assert W==(3-t)*n+sigma+theta
 assert theta>=weight
 return dict(gens=gens,m=m,n=n,F=F,t=t,k=sum(w>=c for w in ap),W=W,pf=pf,sigma=sigma,theta=theta,forest=weight,certificate=sigma+weight-(t-3)*n,chosen=chosen)

if __name__=='__main__':
 rng=random.Random(9102);attempts=0;found=0;bad=[];best=None
 for _ in range(6000):
  m=rng.randint(20,400)
  a=sorted(rng.sample(range(m+1,6*m),3))
  attempts+=1
  r=analyze([m,*a])
  if r is None:continue
  found+=1
  if best is None or r['certificate']<best['certificate']:best=r
  if r['certificate']<0:
   bad.append(r)
   if len(bad)>=10:break
 out=dict(attempts=attempts,type_ge7=found,failed=bad,worst=best)
 print(json.dumps(out,indent=2))
 open('round2/type/forest_diagnostic.json','w').write(json.dumps(out,indent=2))
