import sys,json,random
from math import gcd
sys.path.insert(0,'prior/wilf_edim4_six_point_verification_2026-09-05')
from wilf_work import inspect

def triples(limit=42):
 buckets={}
 for a in range(2,limit):
  for b in range(a+1,limit+1):
   if gcd(a,b)>1:continue
   F=a*b-a-b
   inv=pow(a,-1,b)
   def ins(n):return n>=0 and ((n*inv)%b)*a<=n
   for q in range(2,F+1):
    if ins(q):continue
    if any(ins(q*z) and ins(a*b-q*z) for z in range(1,a*b//q+1)):continue
    gaps=tuple(z for z in range(1,F//q+1) if not ins(q*z))
    buckets.setdefault(gaps,[]).append((a,b,q))
 return buckets

rng=random.Random(8901);buckets=triples();hist={len(g):len(ls) for g,ls in buckets.items()};tested=0;worst=None
print('buckets',len(buckets),'triples',sum(map(len,buckets.values())),flush=True)
for attempt in range(30000):
 gs=rng.choice([g for g in buckets if len(g)>=2 and len(buckets[g])>=2])
 a,b,q=rng.choice(buckets[gs]);c,d,p=rng.choice(buckets[gs])
 if gcd(p,q)>1 or p==q:continue
 r=inspect([p*a,p*b,q*c,q*d],False)
 if r is None:continue
 tested+=1
 if worst is None or r['k']>worst['k']:
  worst=dict(r,scale_p=p,scale_q=q,pair_a=a,pair_b=b,pair_c=c,pair_d=d,Rgaps=gs)
  print(json.dumps(worst),flush=True)
 if r['k']>=7:break
out=dict(attempts=attempt+1,tested=tested,worst=worst)
open('round2/type/secondary_quotient_search.json','w').write(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
