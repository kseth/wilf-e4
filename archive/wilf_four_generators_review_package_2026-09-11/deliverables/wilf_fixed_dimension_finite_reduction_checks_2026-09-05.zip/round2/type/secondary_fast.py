from math import gcd
import random,json,sys
sys.path.insert(0,'round2/type')
from secondary_search import types,sg_two

def ins(n,a,b):
 if n<0:return False
 return ((n*pow(a,-1,b))%b)*a<=n

def secondary(p,q,a,b,c,d):
 # Any unwanted criticalvaluefactorization gives a z in one ofthesetests.
 for z in range(1,a*b//q+1):
  if ins(a*b-q*z,a,b) and ins(p*z,c,d):return False
 for z in range(1,c*d//p+1):
  if ins(c*d-p*z,c,d) and ins(q*z,a,b):return False
 return p*a*b!=q*c*d

rng=random.Random(1129);secs=0;worst=None;examples=[]
for i in range(200000):
 a,b=sorted(rng.sample(range(2,51),2));c,d=sorted(rng.sample(range(2,51),2))
 if gcd(a,b)>1 or gcd(c,d)>1:continue
 p,q=sorted(rng.sample(range(2,250),2))
 if gcd(p,q)>1:continue
 if not secondary(p,q,a,b,c,d):continue
 if ins(q,a,b) and ins(p,c,d):continue
 gens=[p*a,p*b,q*c,q*d]
 t=types(gens)
 if t is None:continue
 secs+=1
 if worst is None or t>worst['t']:
  worst=dict(gens=gens,p=p,q=q,a=a,b=b,c=c,d=d,t=t);print(json.dumps(worst),flush=True)
 if t>=7:
  examples.append(worst)
  if len(examples)>=3:break
out=dict(attempts=i+1,secondary_non_gluing=secs,worst=worst,examples=examples)
open('round2/type/secondary_fast.json','w').write(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
