# Independent audit: pure critical relations and interior corners

**Audited source:** Section 1 of `round2/type/secondary_structure_report.md`.

**Conclusion:** The proof is valid. In fact, its hypothesis can be weakened: criticality of the multiplicity's coefficient `b` is not required.

## Stronger statement

Let `S=⟨m,A,B,C⟩` be minimally four-generated, with multiplicity `m`. Suppose

`aA=bm`,

where `a` is the least positive integer such that `aA∈⟨m,B,C⟩`. Then every preferred Apéry factorization lower ideal modulo `m` has no minimal excluded exponent with all three coordinates positive.

For `0≤r<a`, `rA` has a unique factorization: cancelling its A-coefficient from any different factorization would yield `sA∈⟨m,B,C⟩` for `0<s<a`. In particular, `rA` is Apéry, and all points `re_A`, `0≤r<a`, belong to every preferred ideal. The point `ae_A` is excluded because `aA=bm`.

If `p=(x,y,z)` were a full-support minimal excluded point, its residue representative would be zero by the disjoint-support lemma. Thus `xA+yB+zC≡0 mod m`. Minimality of the excluded point gives `1≤x<a`, since `p−e_B` is included and the A-axis stops at exponent `a−1`.

Both `(0,y,z)` and `(a−x,0,0)` belong to the ideal. The first is a divisor of `p−e_A`; the second lies on the verified pure axis. Their residues coincide:

`yB+zC≡−xA≡(a−x)A mod m`.

The points are distinct, contradicting residue injectivity. This proof does not use criticality of `b` or the sign of a quotient `k−b`.

## The secondary-class application

I directly checked the cited primary source, Chomicz, *The type and cardinality of minimal presentations of numerical semigroups with embedding dimension four*, arXiv:2609.04000v1, Section 2.1, Lemma 2.2 and the definitions immediately following it:

https://arxiv.org/html/2609.04000v1

The secondary generators split into two paired pure critical relations. Therefore the multiplicity belongs to one such pair, and the theorem's hypothesis is satisfied. The secondary application is valid.

This establishes absence of full-support corners for every preferred Apéry staircase. It does not bound the number of maximal points and does not prove Wilf for all secondary semigroups.

## Subsequent audit of Section 1.1: fixed critical pure exponent

The added fixed-exponent structural bounds are valid:

`r≤a`, `q≤a(r+1)`, `K≤a(a+r)^2≤4a^3`.

Here `r` counts mixed corners in the BC plane, `q` counts global maximal points, and `K` counts occupied compressed cells. The proof uses the first theorem's precise A-axis length `a`, not a separate bound on semigroup type.

Mixed BC corners inject into the `a` A-axis residue representatives. Zero can be one of these representatives, so the asserted bound `r≤a` is the safe count. The BC-plane ideal `F` has exactly `r+1` maxima. With no interior excluded corner, every A-coordinate slice is exactly `F` intersected with an anchored rectangle. Intersecting the `r+1` maximal anchored boxes of `F` with that rectangle proves that the slice has at most `r+1` maxima. Summing over the `a` slices gives the bound on `q`.

The compression count also checks. Every slice maximal point is the top of one of the clipped original boxes. Its B-coordinate plus one is either an original F-maximal B-coordinate plus one or the clipping level `B_x`; the same holds for C. The initial levels `B_0,C_0` already occur among the original F-maximal coordinate levels. There are therefore at most `(r+1)+(a−1)=r+a` positive partition levels in each of B and C. There are at most `a` levels in A. The product bounds the number of occupied cells, proving `K≤a(a+r)^2`.

Substitution into the established slab theorem `m≥4K−2⇒W_4≥0` gives exactly

`m≥4a(a+r)^2−2 ⇒ W_4≥0`,

and the coarse sufficient bound `m≥16a^3−2`. The integer counterexample endpoint is correctly `m≤16a^3−3`.

For `a=2`, the maximal-point bound gives `q≤2(2+1)=6`, so the full family satisfies Wilf by the earlier six-final-window theorem. This last deduction retains that theorem's finite computational dependency; the source correctly identifies it.

**Audit conclusion for Section 1.1:** valid, no gap found. It settles the critical pure exponent-two class through the established six-point theorem and gives a multiplicity cutoff for each fixed exponent. It does not settle all secondary semigroups.
