# Independent audit and improved multiplicity cutoff

This is a fresh mathematical audit of sections 2–4 of the 5 September checkpoint. I found no gap in the Apéry corner restriction, continuous line identities, minimum-coordinate slicing, propagation rectangles, modular phase argument, cell transfer, or conductor reduction. The conclusion remains a partial result, not a proof of unrestricted Wilf in embedding dimension four.

Two strengthened estimates give the following new result:

> Every minimally four-generated numerical semigroup with multiplicity
> `m ≥ 5×10^20` has strictly positive Wilf number.

## 1. Improved continuous gap

Use the checkpoint's notation `κ_c = 3−4 E[X_1+X_2+X_3]`, and the same hypotheses on the downset `K` and excluded orthants. Then

`κ_c ≥ ε = 1296/100000000 = 0.00001296`.

Suppose instead that `κ_c < ε`. The minimum-coordinate slicing inequality gives

`E[min_i X_i] ≥ 1/12−κ_c/4 > 0.08`,

so `K` contains `[0,0.08]^3`. Put `r=0.02` and use the same three propagation steps as the checkpoint. They apply to every target satisfying

`q_i ≤ 0.495`, `q_1+q_2 ≤ 0.75`, `Σq_i ≤ 0.765`.

The three deficit lower bounds, after using `vol(K)≤1/6`, are respectively

1. `6(0.08)(0.02)^2(1−0.495−11(0.02)) = 0.00005472`;
2. `18(0.02)^3(1−0.75−8(0.02)) = 0.00001296`;
3. `12(0.02)^3(1−0.765−5(0.02)) = 0.00001296`.

All contradict `κ_c<ε`, so all such targets belong to `K`.

Take

`p=(0.495,0.255,0.255)`,
`q=(0.255,0.495,0.255)`,
`b=(0.255,0.255,0.255)`.

The first two have coordinate sum `1.005>1`, so are outside `K`. The six points obtained by replacing one coordinate of `p` or `q` by zero satisfy the propagation bounds, as does `b`. Any excluded-orthant vertex below `p` must consequently have full support; the same applies below `q`. Since there is at most one such vertex, it lies below `min(p,q)=b`, contradicting `b∈K`.

The use of zero-coordinate witnesses is legitimate: if a vertex has a zero coordinate, the witness with that coordinate replaced by zero still dominates that vertex. The half-open convention from the checkpoint supplies literal membership of the witnesses.

## 2. Stronger phase estimate from the fibre distribution

For the normalized discrete lower ideal, let `U=max u_j`, `v=min u_j`, and `κ=3−4E[u·X]`. Retain `μ_k=E[vX_k]` for a direction of minimum weight. For any positive integer `h`, put `s=hv`.

The checkpoint used `P(vX_k≥s)≥μ_k−s`. The stronger bound is

`P(vX_k≥s)≥2μ_k−s`.

To see this, condition on the other coordinates. The fibre is uniformly distributed on `0,…,H`, with `vH≤1`. When `H≥h`, its tail is

`(H−h+1)/(H+1) ≥ v(H−h)`.

Indeed, for `H>0`, the left side is at least `(H−h)/H`, which is at least `v(H−h)`. For `H<h`, the right side is negative, so the same inequality holds. Averaging gives the claim because `E[vH]=2μ_k`.

Assume `κ≤1/1000`. If `v>U/14`, then `U<14v`. Otherwise let

`s_0=2U/7`, `h=floor(s_0/v)`, `s=hv`.

Then `3U/14≤s≤2U/7<U/2`. The same nonnegative modular gap pairing as in the checkpoint gives

`2κ ≥ s P(vX_k≥s) ≥ s(2μ_k−s)`.

Since `2μ_k≥(1−3κ)/2` and `U≤1`, the final factor is positive and

`2κ ≥ (3U/14)(3/14−3κ/2)`.

Thus

`U ≤ 392κ/(9−63κ) < 44κ`.

Both cases establish

`U≤44κ+14v`.

The usual pixelization, with `s_total=Σu_j`, consequently gives

`κ_c=(κ+s_total)/(1+s_total)≤κ+s_total≤133κ+42v`.

An all-m numerical certificate, under `κ≤1/1000`, is therefore

`(133−132ε)D/m ≥ εM−42(1−ε)a_min`.

This is obtained by retaining `κ_c≥ε` in the exact transfer formula before bounding `s_total`.

## 3. New cutoff

Suppose `W≤0` and set `R=(6m)^(1/3)−3`. The Apéry identity and lattice count imply

`κ=D/(mM)≤(m−1)/M<1/R`,

`v=a_min/M≤1/R`.

For `m≥5×10^20`, we have `R>14,000,000`; in particular `κ<1/1000`, so the strengthened phase estimate applies. Then

`κ_c≤133κ+42v<175/R<175/14,000,000=0.0000125<ε`,

contradiction.

The bound `R>14,000,000` follows entirely by integer arithmetic:

`6m≥3×10^21>(14,000,003)^3`.

Hence `W>0` when `m≥5×10^20`.

The argument leaves `20≤m<5×10^20` after invoking the published small-multiplicity verification. It cannot be described as resolving that region.

## 4. Literature context checked

I reread Zhai, *An asymptotic result concerning a question of Wilf*, arXiv:1111.2779. Its final Question 1 asks whether the limit infimum of `n/c` with fixed embedding dimension and growing multiplicity equals `1/e`. The checkpoint's positive gap goes beyond the asymptotic estimate in that paper; this is not itself a publication-priority claim.

