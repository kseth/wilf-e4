# Independent audit: interior corner (1,1,1)

**Source:** `round2/arithmetic/interior_corner_111.md`.

**Conclusion:** The structural theorem is valid: a residue-bijective three-variable lower ideal whose minimal excluded set contains `(1,1,1)` has at most six coordinatewise maximal points. Its Wilf corollary is valid conditional on the previously certified six-final-window theorem, whose finite computational dependency remains present.

## Structural proof

The predecessor residue argument correctly implies disjoint supports between an excluded corner and its selected residue representative. Applied to `(1,1,1)`, it gives `A+B+C=0 mod m`. Any other mixed corner in the xy-plane must represent a nonzero point `γe_3`; it cannot represent zero because its support intersects that of `(1,1,1)`.

For `p=(u,v,0)`, the point `r=(u−1,v−1,0)` is in the ideal: it is below the included predecessor `p−e_1`. Its label equals `(γ+1)C mod m`. If `γ<h_3`, the distinct point `(γ+1)e_3` is also in the ideal and has the same residue. Thus necessarily `γ=h_3`.

Every mixed xy-corner therefore has the same residue `h_3C`. The same-support boundary injectivity permits at most one such corner. This reasoning is valid even when one exponent is one, and the exceptional pair `(1,1)` is already excluded by minimality of `(1,1,1)` itself.

A minimal excluded point of a coordinate-plane section is also a minimal excluded point of the full ideal: its zero coordinate adds no predecessor requirement. Each plane therefore has at most one mixed excluded corner, together with its pure axis bounds. Such a planar ideal is a rectangle with at most one upper-right quadrant removed and has at most two planar maxima.

Since every point with three positive coordinates dominates the excluded `(1,1,1)`, the full ideal is the union of its three plane sections. A global maximal point must be maximal in every section containing it. The union of their planar maxima has at most six points. No assumption that these six points are distinct is needed; duplicates only strengthen the bound.

## Wilf dependency

For genuine Apéry weights, any exponent satisfying `M−w(x)<m` is coordinatewise maximal, since every nonmultiplicity generator exceeds `m`. Thus the final Apéry window has at most six points.

The earlier checkpoint `prior/wilf_edim4_six_point_and_column_theorems_2026-09-05.md` states exactly the sufficient theorem required here: at most six elements of `Ap(S,m)∩[c,c+m)` imply Wilf, without restrictions on multiplicity or the sizes of the generators. Therefore the corollary uses the correct theorem with all of its hypotheses satisfied.

That earlier theorem contains finite enumeration and exact certificate checks. This audit read its statement and proof reduction to confirm the dependency, but did not rerun its enumeration. The new structural argument does not remove that computational component, and the source manuscript explicitly says so. Describing the structural bound as analytic is accurate; describing the resulting Wilf class as having a wholly analytic proof would not be supported by the present dependency chain.

