# Independent audit of the summed sawtooth improvement

I independently checked the sawtooth proof in `round2/sharp_stability/phase_improvement.md` and the root's summation argument. No gap was found. The result improves the multiplicity threshold to

`m≥10^17 ⇒ W>0`.

## Sawtooth step

Let `k` have minimum normalized weight `v`; let `j≠k`. Write `δ̄_j=Eδ_j` and `μ_k=E[vX_k]`. The sawtooth argument establishes

`2δ̄_j(1+v+u_j) ≥ 2u_j μ_k−v(1+v)`.

The relevant details were checked independently:

- Along a k-fibre, `δ_j(t)≥[A−tv]_(u_j)`.
- Intervals `[A−tv,A−tv+v]` concatenate into one interval of length `h=Lv`.
- The periodic sawtooth integral over length `h=qu_j+r` is at least `(qu_j²+r²)/2`; the leftover arc has integral at least `r²/2`, including when it crosses the discontinuity.
- Cauchy gives `qu_j²+r²≥h²/(q+1)≥u_j h²/(h+u_j)`.
- `h≤1+v`, and the length-weighted fibre average satisfies `v E[L]=2μ_k+v`.

These statements require only a finite lower ideal and positive weights normalized by maximum weight one.

## Summing both nonminimum directions

Put `s=u_1+u_2+u_3`, `U=max u_j`, and `κ=Σδ̄_j`. Summing the sawtooth inequality over `j≠k`, and enlarging both coefficients on the left, yields

`(s−v)μ_k ≤ (1+v+U)(κ−δ̄_k)+v(1+v)`.

Since `μ_k=(1+κ)/4−δ̄_k`,

`(s−v)(1+κ)/4 ≤ (1+v+U)κ+v(1+v)+δ̄_k[(s−v)−(1+v+U)]`.

The bracket equals `B−1−v`, where `B` is the middle weight, and is nonpositive since `B≤1`. Discarding this term and using `U≤s−2v` gives

`s(1−3κ)≤4κ+5v−3κv+4v²`.                 (1)

## Consequence for a hypothetical nonpositive Wilf number

The Apéry moment identity gives

`W≤0 ⇒ κ≤(m−1)/M < a_min/M=v`.

Suppose also `v<1/3`. The right-hand quotient in (1) is strictly increasing in κ: its derivative has numerator `4+12v+12v²>0`. Consequently

`s < (9v+v²)/(1−3v)`.

The pixelized continuous deficit satisfies `κ_c=(κ+s)/(1+s)`. This is increasing in both κ and s when `κ<1`. Thus

`κ_c < 2v(5−v)/(1+6v+v²) < 10v`.         (2)

All strict inequalities are justified by `κ<v`, which follows from minimality of the generating set and `a_min>m`.

## Exact multiplicity endpoint

The lattice count gives

`v≤1/((6m)^(1/3)−3)`.

If `m≥10^17`, then

`6m≥6×10^17>(800003)^3=512005760021600027`.

Hence `v<1/800000<1/3`. Equation (2) implies

`κ_c<10/800000=1/80000<81/6250000`.

This contradicts the improved continuous gap proved in `audit_and_improved_cutoff.md`. Therefore `W>0` for every minimally four-generated semigroup of multiplicity at least `10^17`.

This proof leaves the smaller multiplicities unresolved. It is an analytic exclusion of a tail of multiplicities, not an enumeration or elimination of the remaining region.

## Subsequent stronger continuous lemma

I also independently audited `round2/sharp_stability/continuous_gap_1e4.md`. Its bootstrap from the cube of side `.08` to the cube of side `.16`, and all seven final witness propagations, are valid. The respective exact lower bounds are

`0.00044544`, `0.0001176`, `0.000126`,

and

`0.00107136`, `0.000378`, `0.0001291248`.

Every value exceeds `1/10000`; the coordinate permutations and excluded-support contradiction also check.

Using this stronger continuous lemma, the same summed sawtooth argument now gives

`m≥2×10^14 ⇒ W>0`.

Indeed, `(100003)^3=1000090002700027<1200000000000000=6(2×10^14)`. Hence `v<1/100000`, and `κ_c<10v<1/10000` contradicts the continuous lemma. This supersedes the `10^17` threshold above.
