# Independent adversarial audit: general fixed embedding dimension

**Audited source:** `round2/amplification/general_dimension.md`.

**Conclusion:** I found no mathematical gap in Theorems A or B as written. The manuscript supplies an analytic proof of eventual strict Wilf at sufficiently large multiplicity for each fixed embedding dimension `e=d+1≥3`, and an analytic bound on the generators of every possible remaining counterexample. Consequently its conclusion that only finitely many counterexamples are possible at each fixed embedding dimension follows from the displayed arguments.

This is an independent mathematical review of the written derivation. It is not external peer review or a formal proof-assistant certificate. The result does not establish that any of the finite regions is empty, and therefore does not prove Wilf's conjecture.

## 1. The arithmetic hypothesis really holds in every dimension

The selected Apéry factorizations form a lower ideal because both Apéry membership and preference under an additive lexicographic order pass to divisors. The labels are injective modulo the multiplicity.

If a minimal excluded exponent `p` and its selected residue representative `q` shared a positive coordinate `j`, the two distinct predecessors `p−e_j` and `q−e_j` would both belong to the ideal and have equal residues. This is impossible. Thus a full-support excluded exponent represents zero. The identical predecessor argument shows that two distinct excluded exponents sharing a positive coordinate cannot have equal residues. This proves the claimed uniqueness of a full-support excluded exponent in all `d`, without a hidden restriction to `d=3`.

## 2. The continuous argument generalizes correctly

The coordinate-fibre identity is dimension-independent. Its coefficient is `d+1`, since summing the fibre top contributions counts the first moment once in every coordinate and once more in its own coordinate.

Partitioning a uniform point by its uniquely minimum coordinate is legitimate outside a null set. At a fixed minimum `ρ`, translation of the other coordinates by `−ρ` leaves a downset in a simplex of radius `1−dρ`. The conditional mean bound is exactly

`dρ+(d−1)(1−dρ)/d=(d−1)/d+ρ`.

Hence the initial cube deduction has no dependence on symmetry, convexity, or full dimensionality of individual exceptional slices.

For the propagation rectangle in step `j`, the maximum allowed sum of the other coordinates plus the missing fibre endpoint is

`Σ_(i≤j) z_i + [d(d−j+2)−1]r`.

This verifies the potentially delicate coefficient in the manuscript. Since the coefficient is at most `d(d+1)`, the deficit is at least `h/2`. The previously forced point gives fibre length at least `2r`, and the base rectangle has measure `r^(d−1)`. Thus the lower bound is precisely `J_j≥h r^d`; no missing factor or dimension-dependent sign arises.

The two outside points have sum `1+1/(4d)`. Replacing a small coordinate `1/(2d)` by `h=1/(8d)` changes that sum to exactly `1−h`; replacing the large coordinate reduces it further. Every required witness is therefore inside the propagated target region. The use of different first and second coordinates is valid for every `d≥2`.

The excluded-orthant assumption is used only after membership of these witnesses is proved. A vertex of deficient support would also exclude the witness corresponding to one of its zero coordinates. The two outside points therefore dominate full-support vertices, and uniqueness forces a common vertex below their coordinatewise minimum, which was also forced inside. This contradiction is valid for any number of lower-support vertices.

The finite-orthant and half-open-cell boundary conventions are compatible: the pixelized set has exactly the upper-orthant complement obtained from the finitely many minimal excluded integer exponents. Positive diagonal scaling preserves supports. Literal membership of witnesses is therefore justified, not merely membership up to a null set.

## 3. Phase and pixel transfer

The coordinate mean lower bound is correctly

`μ_j≥(1−dκ)/(d+1)`.

In the small-minimum-weight case, the directions of largest and smallest weights are distinct automatically: otherwise `v=U` would contradict `v≤s_0/2≤U/8`. The modular difference of the two direction-j deficits is `−s mod U`, with `0<s≤U/4`, so their nonnegative sum is at least `s`. The shift is injective, and each deficit is counted at most twice.

The threshold choices correctly give

`2κ≥s_0 A/4≥U/[32(d+1)^2]`.

In the other case the bound `U<8(d+1)v` follows directly. Therefore the phase estimate is valid as stated; it does not require equal weights, rational weights, or additional arithmetic hypotheses.

The continuous correction for rectangular cells is correctly

`κ_c=[κ+(d−1)σ/2]/(1+σ)`.

In particular the coefficient `(d−1)/2`, which differs from the three-dimensional special case, has been retained throughout. Substitution yields the displayed `P_d` and `Q_d` without an omitted factor.

## 4. Eventual strictness

The ceiling in `B_d` gives `x_m≥H_d`, not merely an asymptotic estimate. The inequality `2Q_d≤(d−1)P_d` holds for every `d≥2`.

One can also verify the smallness assertions without checking individual dimensions: `d!≤d^d` and `r_d<1/d` imply `δ_d<h_d<1/(2d)`, and then `η_d=δ_d/(2P_d)<1/(2d)`.

Thus either the phase hypothesis holds and forces `κ≥η_d`, or its failure gives an even larger `κ`. Minimality of the generating set gives `a_min>m`, which makes

`M/m>M/a_min≥H_d`

strict. Consequently the conclusion `W_(d+1)>(d−1)/2>0` is justified even when the ceiling defining `B_d` or other preceding bounds attain equality.

## 5. The simplex exclusion is valid

Injectivity on `Δ_R` implies injectivity on `E=Δ_(R−1)−Δ_1`: two equal labels in `E` produce equal labels of `p+q'` and `p'+q`, both in `Δ_R`, and hence equality of the original difference vectors.

The nonnegative part of `E` is exactly `Δ_(R−1)`. Every other point has exactly one coordinate `−1`, and the sum of the other coordinates is at most `R−1`. These pieces are disjoint, so the count in the manuscript is exact. Subtracting `|Δ_R|` gives the stated positive quantity for every `d≥2,R≥2`.

There is no assumption of unique representations of elements of `E`; the argument compares the resulting integer difference vectors, which is all that injectivity requires. Indeed the lemma would work for labels in any group of order `|Δ_R|` arising from an additive map, not just a cyclic group.

## 6. The finite conductor bound does follow

If every coordinate-line top were coordinatewise maximal, every allowable unit transfer `x−e_i+e_j` would belong to the ideal. Otherwise `x−e_i` would be a nonmaximal direction-j line top. Unit transfers connect the whole layer of any fixed total degree. A point of maximum degree therefore forces its entire layer, and downward closure forces every preceding layer. This proves the claimed characterization of standard simplexes.

For a non-simplex, the nonmaximal line top has a successor and hence a weight deficit at least the minimum weight `β`. Let `ℓ` be the height of the minimum-weight axis, and `ε=M−ℓβ≥0`. If the nonmaximal line is the axis line, `ε≥β` implies `D≥M`. Otherwise the distinct line contributions give

`D≥(ℓ+1)ε+β`,

and multiplying by `ℓ≥1` gives `ℓD≥M`. Since `ℓ≤m−d`, the bound `D≥M/(m−d)` follows. This argument has no uncounted overlap between line contributions: lines are indexed together with their coordinate direction, exactly as in the slack identity.

For Apéry ideals with `m>d+1`, the simplex exclusion removes every simplex alternative. Integrality of `W<0` gives the stated bound on `D`, and combining it with the geometric estimate gives the displayed upper bound on `M`. Every nonmultiplicity minimal generator is an Apéry element, so it is at most `M`.

The edge case `m=d+1` is handled correctly by the distinct-integer estimate on the `m−1` nonzero Apéry values. Multiplicities below `d+1` cannot have `d+1` minimal generators. Thus all possibilities are accounted for.

## Final assessment

**Valid as a written analytic proof, with no gap found in this audit:** explicit eventual Wilf and finitely many possible counterexamples for each fixed embedding dimension.

**Not established:** emptiness of the finite region in embedding dimension four or any new unrestricted case of Wilf's conjecture; a finite bound uniform over all embedding dimensions; publication priority.

