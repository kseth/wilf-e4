import random,json,itertools,time
rng=random.Random(9142026)
def inv(T):
 q=C=0;g={}
 for x in sorted(T,key=sum,reverse=True):
  up=[tuple(v+(i==j) for i,v in enumerate(x)) for j in range(3)];sx=sum(x);gx=max([sx]+[g[y] for y in up if y in g]);g[x]=gx
  q+=all(y not in T for y in up);C+=sum((x[j]+1)*(gx-sx) for j,y in enumerate(up) if y not in T)
 return q,C

def prof(a,b,mode):
 if mode:return [b]+sorted([rng.randint(1,b) for _ in range(a-1)],reverse=True)
 return [b]+sorted([max(1,min(b,int(b*(1-i/a))+rng.randint(-1,1))) for i in range(1,a)],reverse=True)
records=[];best=1e30;eligible=0;count=0;start=time.time()
for i in range(100000):
 d=rng.randint(2,10);A,B,C=[max(2,d+rng.randint(-2,2)) for _ in range(3)];p=prof(A,B,i%3);q=prof(A,C,i%3);r=prof(B,C,i%3)
 T=frozenset((x,y,z) for x in range(A) for y in range(p[x]) for z in range(min(q[x],r[y])))
 m=len(T);qq,cc=inv(T);count+=1
 if qq<7:continue
 eligible+=1;ratio=cc/(m-1)
 if ratio<best:
  best=ratio;rec={'i':i,'m':m,'q':qq,'C':cc,'ratio':ratio,'profiles':[p,q,r]};records.append(rec);print(json.dumps(rec),flush=True)
 if cc<m-1:
  rec['T']=sorted(T);break
open('round2/arithmetic/no_interior_C_results.json','w').write(json.dumps({'proposals':count,'eligible':eligible,'records':records},indent=2));print('FINAL',count,eligible,best,time.time()-start,flush=True)
