import sys,itertools,random,json,math
from pathlib import Path
sys.path.insert(0,'prior/wilf_edim4_reassessment_checks_2026-09-05')
from wilf_reassessment import maximal,ordered_geometric_optimum
from scipy.optimize import linprog
rng=random.Random(9172026);seen=set();bad=[];maxbad=0;counts={'shapes':0,'unordered_fail':0,'ordered_fail':0}
def profile(a,b,kind):
 if kind==0:return [b]+sorted([rng.randint(1,b) for _ in range(a-1)],reverse=True)
 vals=[max(1,min(b,int(b*(1-i/a))+rng.randint(-1,1))) for i in range(a)]
 vals[0]=b
 return sorted(vals,reverse=True)
for i in range(100000):
 d=rng.randint(2,13);sizes=[max(2,d+rng.randint(-2,2)) for _ in range(3)]
 A,B,C=sizes;p=profile(A,B,i%7==0);q=profile(A,C,i%7==0);r=profile(B,C,i%7==0)
 cap=[rng.randint(1,max(1,n//3)) for n in sizes] if i%5 else None
 T=frozenset((x,y,z) for x in range(A) for y in range(p[x]) for z in range(min(q[x],r[y])) if cap is None or not all(a>=b for a,b in zip((x,y,z),cap)))
 m=len(T)
 if m<20 or T in seen:continue
 seen.add(T);counts['shapes']+=1;tops=maximal(T);ss=[sum(x[j] for x in T) for j in range(3)];cost=[-4*s for s in ss]+[3*m]
 G=[(1,0,0,0),(0,1,0,0),(0,0,1,0)]+[tuple(-v for v in x)+(1,) for x in tops]
 b=[m+1]*3+[0]*len(tops)
 res=linprog(cost,A_ub=[[-v for v in row] for row in G],b_ub=[-v for v in b],bounds=[(None,None)]*4,method='highs');assert res.success
 if res.fun>=m*(m-1)-1e-6:continue
 counts['unordered_fail']+=1
 for order in itertools.permutations(range(3)):
  t=frozenset(tuple(x[j] for j in order) for x in T);res=ordered_geometric_optimum(t)
  if res['sufficient']:continue
  counts['ordered_fail']+=1
  rec={'m':m,'profiles':[p,q,r],'cap':cap,'order':order,'LP':res,'T':sorted(t)};bad.append(rec)
  if m>maxbad:
   maxbad=m;print('MAXBAD '+json.dumps(rec),flush=True)
 if i%1000==0:Path('round2/arithmetic/abstract_profiles_results.json').write_text(json.dumps({'i':i,'counts':counts,'failures':bad},indent=2))
Path('round2/arithmetic/abstract_profiles_results.json').write_text(json.dumps({'i':i,'counts':counts,'failures':bad},indent=2))
print('FINAL',counts,maxbad,flush=True)
