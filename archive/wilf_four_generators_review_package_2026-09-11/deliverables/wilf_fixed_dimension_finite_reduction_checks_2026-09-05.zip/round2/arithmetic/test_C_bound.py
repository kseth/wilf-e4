import sys,random,json,itertools,time
from pathlib import Path
rng=random.Random(6919926)
def invariants(T):
 q=0;C=0;g={}
 for x in sorted(T,key=sum,reverse=True):
  up=[tuple(v+(i==j) for i,v in enumerate(x)) for j in range(3)]
  sx=sum(x);gx=max([sx]+[g[y] for y in up if y in g]);g[x]=gx
  q+=all(y not in T for y in up)
  C+=sum((x[j]+1)*(gx-sx) for j,y in enumerate(up) if y not in T)
 return q,C

def profile(a,b,kind):
 if kind==0:return [b]+sorted([rng.randint(1,b) for _ in range(a-1)],reverse=True)
 vals=[max(1,min(b,int(b*(1-i/a))+rng.randint(-1,1))) for i in range(a)];vals[0]=b
 return sorted(vals,reverse=True)

seen=set();data=[];best=1000.;eligible=0;start=time.time()
for i in range(20000):
 d=rng.randint(5,30);sizes=[max(2,d+rng.randint(-3,3)) for _ in range(3)];A,B,C=sizes
 p=profile(A,B,i%3);q=profile(A,C,i%3);r=profile(B,C,i%3)
 cap=[rng.randint(1,max(1,n//2)) for n in sizes] if i%6 else None
 T=frozenset((x,y,z) for x in range(A) for y in range(p[x]) for z in range(min(q[x],r[y])) if cap is None or not all(a>=b for a,b in zip((x,y,z),cap)))
 if T in seen:continue
 # Store hashes only to avoid retaining large shapes; hash collisions only skip samples.
 seen.add(T) if i<50 else None
 n=len(T);qq,cc=invariants(T)
 if qq>12:
  eligible+=1;rat=9*cc/(n*(qq-12))
  if rat<best:
   best=rat;rec={'i':i,'m':n,'q':qq,'C':cc,'ratio':rat,'margin':9*cc-n*(qq-12),'profiles':[p,q,r],'cap':cap};data.append(rec);print(json.dumps(rec),flush=True)
  if 9*cc<n*(qq-12):
   rec['T']=sorted(T);break
 if i%1000==0:Path('round2/arithmetic/C_bound_results.json').write_text(json.dumps({'i':i,'eligible':eligible,'records':data},indent=2))
Path('round2/arithmetic/C_bound_results.json').write_text(json.dumps({'i':i,'eligible':eligible,'records':data},indent=2))
print('FINAL',i,eligible,best,time.time()-start,flush=True)
