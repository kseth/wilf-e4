import sys,random,json,time
from pathlib import Path
from collections import Counter
sys.path.insert(0,'prior/wilf_edim4_reassessment_checks_2026-09-05')
from wilf_work import apery
from wilf_reassessment import ordered_geometric_optimum,maximal
from scipy.optimize import linprog
rng=random.Random(5152026)
seen=set();out=[]; counts=Counter();extreme=1e10
for i in range(100000):
 m=rng.randint(20,100) if i%5 else rng.randint(101,1000)
 mode=i%7
 if mode in (0,1):
  q=rng.choice([2,3,5,10,100,10000]);g=[m,*sorted(rng.sample(range(q*m+1,(q+1)*m),3))]
 elif mode==2:
  g=[m,*sorted(rng.sample(range(m+1,2*m),3))]
 elif mode==3:
  a=rng.randint(m+1,m*m);g=[m,a,a+rng.randint(1,m-1),a+rng.randint(m,2*m-1)]
 elif mode==4:
  g=[m,*sorted(rng.sample(range(m+1,2*m*m),3))]
 else:
  q=rng.randint(1,10);r=rng.randint(1,m-3);g=[m,q*m+r,q*m+r+1,q*m+r+2]
 ap=apery(g)
 if ap is None:continue
 counts['semigroups']+=1;t=frozenset(x for _,x in ap[2])
 if t in seen:continue
 seen.add(t);counts['shapes']+=1
 sums=[sum(x[j] for x in t) for j in range(3)]; tops=maximal(t)
 G=[(1,0,0,0),(-1,1,0,0),(0,-1,1,0)]+[tuple(-v for v in x)+(1,) for x in tops]
 b=[m+1,1,1]+[0]*len(tops);cost=[-4*s for s in sums]+[3*m]
 res=linprog(cost,A_ub=[[-v for v in r] for r in G],b_ub=[-v for v in b],bounds=[(None,None)]*4,method='highs')
 assert res.success
 ratio=res.fun/(m*(m-1))
 if ratio<extreme:
  extreme=ratio;print(json.dumps({'i':i,'gens':g,'ratio':ratio,'weights':res.x.tolist()}),flush=True)
 if res.fun < m*(m-1)-1e-6:
  rec=ordered_geometric_optimum(t);rec['gens']=g;rec['T']=sorted(t);out.append(rec)
  print('FAILURE '+json.dumps(rec),flush=True)
 if i%1000==0:
  Path('round2/arithmetic/search_geometric_results.json').write_text(json.dumps({'i':i,'counts':counts,'failures':out},indent=2))
Path('round2/arithmetic/search_geometric_results.json').write_text(json.dumps({'i':i,'counts':counts,'failures':out},indent=2))
print('FINAL',dict(counts),len(out),flush=True)
