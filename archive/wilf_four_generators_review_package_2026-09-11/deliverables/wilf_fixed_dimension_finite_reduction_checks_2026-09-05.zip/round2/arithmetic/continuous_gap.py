import sys,itertools,random,json
sys.path.insert(0,'prior/wilf_edim4_reassessment_checks_2026-09-05')
from wilf_reassessment import shape_from_pair_bounds,maximal
from scipy.optimize import linprog
rng=random.Random(72026);best=3.;data=[]
for i in range(10000):
 d=rng.randint(2,25);bd=tuple(rng.randint(max(1,d//2),max(2,3*d//2)) for _ in range(3));c=tuple(rng.randint(1,d) for _ in range(3)) if i%10 else None
 t=shape_from_pair_bounds(bd,c);m=len(t);tops=maximal(t);ss=[sum(x[j]+.5 for x in t)/m for j in range(3)]
 r=linprog([-s for s in ss],A_ub=[[xj+1 for xj in x] for x in tops],b_ub=[1]*len(tops),bounds=[(0,None)]*3,method='highs');assert r.success
 k=3+4*r.fun
 if k<best:
  best=k;v={'i':i,'m':m,'bounds':bd,'corner':c,'gap':k,'weights':r.x.tolist()};data.append(v);print(json.dumps(v),flush=True)
 if k<1/3-1e-8:break
open('round2/arithmetic/continuous_gap_results.json','w').write(json.dumps(data,indent=2))
