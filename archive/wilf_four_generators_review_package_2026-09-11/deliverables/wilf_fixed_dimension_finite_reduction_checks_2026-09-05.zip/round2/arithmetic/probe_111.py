import sys,random,json,time
sys.path.insert(0,'prior/wilf_edim4_reassessment_checks_2026-09-05')
from wilf_work import apery
from wilf_reassessment import maximal,corners
rng=random.Random(991626);mx=0;stats={};examples=[];valid=0;hit=0
for i in range(20000):
 m=rng.randint(20,1000);A=rng.randint(1,m-1);B=rng.randint(1,m-1);C=(-A-B)%m
 if not C or len({A,B,C})<3:continue
 rs=[A,B,C];base=rng.randint(1,10)
 a=sorted(base*m+r+m*rng.randint(0,2) for r in rs)
 ap=apery([m,*a])
 if ap is None:continue
 valid+=1;T={x for _,x in ap[2]}
 if not {(1,1,0),(1,0,1),(0,1,1)}<=T:continue
 hit+=1;tops=maximal(T);q=len(tops);stats[q]=stats.get(q,0)+1
 if q>mx:
  mx=q;rec={'gens':[m,*a],'m':m,'q':q,'corners':corners(T),'maximal':tops};examples.append(rec);print(json.dumps(rec),flush=True)
open('round2/arithmetic/probe_111_results.json','w').write(json.dumps({'valid':valid,'p111':hit,'q_histogram':stats,'records':examples},indent=2));print('FINAL',valid,hit,stats,flush=True)
