# Two triangular faces exclude an Apéry staircase

Let `T` be a finite lower ideal in `N^3`, let `m=|T|`, and suppose a linear map `w(x)=A x_1+B x_2+C x_3 (mod m)` is bijective on `T`. Assume `(1,1,1)` is a minimal excluded point. Then two coordinate-plane sections of `T` cannot both be full triangles of a common degree `d>=2`.

More explicitly, the forbidden configuration is

- `T ∩ {x_2=0} = {(i,0,j): i+j<=d}`;
- `T ∩ {x_1=0} = {(0,i,j): i+j<=d}`;
- `(1,1,1)` is a minimal excluded point.

No hypothesis is imposed on the remaining coordinate-plane section beyond the stated downset and bijectivity assumptions. The two given sections already force all three axes to have exactly `d` nonzero points.

## Proof

For a minimal excluded point `p`, its representative `q∈T` has disjoint support from `p`. Moreover, two distinct minimal excluded points with intersecting supports have different residues. Both facts follow by subtracting one shared coordinate and contradicting bijectivity on `T`.

The interior corner therefore has representative zero, so `A+B+C=0 (mod m)`.

The `d` mixed corners `(i,0,d+1-i)`, `1<=i<=d`, are minimal excluded points. Their representatives are nonzero, because each shares support with `(1,1,1)`, and lie on the second axis. Their residues are distinct, so the representatives permute `e_2,2e_2,...,d e_2`. With `N=d(d+1)/2`, summing gives

`N(A+C)=NB (mod m)`, hence `2NB=0 (mod m)`.

The other triangular face similarly gives `2NA=0 (mod m)`. The interior relation now gives `2NC=0 (mod m)`. Every value of `w` is killed by multiplication by `2N`; bijectivity includes the residue `1`, so `m` divides `2N`.

But the union of the two triangular sections has

`2*binom(d+2,2) - (d+1) = (d+1)^2`

points. Consequently `m >= (d+1)^2 > d(d+1)=2N`, contradiction.

This strictly enlarges the earlier exclusion of the symmetric three-face family. For example it excludes the size-30 shape obtained from `{x+y+z<=4, xyz=0}` by deleting `(3,1,0)`. Its ordered geometric LP has minimum `D=860<870=m(m-1)`, so arithmetic exclusion is needed for that relaxation.

This lemma is a structural exclusion, not a proof of Wilf for unrestricted embedding dimension four. Publication priority has not been investigated.
