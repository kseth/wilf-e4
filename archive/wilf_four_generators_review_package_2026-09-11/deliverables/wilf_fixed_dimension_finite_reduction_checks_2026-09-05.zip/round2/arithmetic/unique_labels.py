import sys,random,json,itertools,time
from pathlib import Path
sys.path.insert(0,'prior/wilf_edim4_reassessment_checks_2026-09-05')
from wilf_reassessment import shape_from_pair_bounds,maximal,ordered_geometric_optimum
from scipy.optimize import linprog
rng=random.Random(69526);seen=set();count=bad=0; failures=[];extreme=1e10
for i in range(20000):
 d=rng.randint(2,15)
 bd=tuple(rng.randint(max(1,d-3),d+3) for _ in range(3))
 c=tuple(rng.randint(1,max(1,d//2)) for _ in range(3))
 t=frozenset(shape_from_pair_bounds(bd,c));m=len(t)
 if t in seen:continue
 seen.add(t);count+=1; tops=maximal(t);ss=[sum(x[j] for x in t) for j in range(3)]
 # Permute axis order randomly; symmetric prototypes otherwise bias all three bounds.
 for order in itertools.permutations(range(3)):
  sp=[ss[j] for j in order];tp=[tuple(x[j] for j in order) for x in tops]
  co=[-4*s for s in sp]+[3*m];G=[(1,0,0,0),(-1,1,0,0),(0,-1,1,0)]+[tuple(-v for v in x)+(1,) for x in tp]
  res=linprog(co,A_ub=[[-v for v in row] for row in G],b_ub=[-m-1,-1,-1]+[0]*len(tp),bounds=[(None,None)]*4,method='highs')
  assert res.success
  if res.fun>=m*(m-1)-1e-6:continue
  bad+=1
  ordered=[tuple(x[j] for j in order) for x in t]
  # Search near minimizer and small lifts/base weights: any found failure is exact.
  candidates=set()
  for x in range(m+1,min(m+31,int(res.x[0])+10)):
   for y in range(x+1,x+16):
    for z in range(y+1,y+16):candidates.add((x,y,z))
  for _ in range(2000):
   a=tuple(max(m+1,int(round(v))+rng.randint(-10,10)) for v in res.x[:3])
   if a[0]<a[1]<a[2]:candidates.add(a)
  for a in candidates:
   M=max(sum(v*w for v,w in zip(a,x)) for x in tp);D=3*m*M-4*sum(v*w for v,w in zip(a,sp))
   if D>=m*(m-1):continue
   vals=[sum(v*w for v,w in zip(a,x)) for x in ordered]
   if len(set(vals))==m:
    rec={'m':m,'bounds':bd,'corner':c,'order':order,'a':a,'M':M,'D':D,'target':m*(m-1),'T':ordered}
    failures.append(rec);print('FAILURE '+json.dumps(rec),flush=True)
    Path('round2/arithmetic/unique_labels_results.json').write_text(json.dumps({'count':count,'bad_lp':bad,'failures':failures},indent=2))
    sys.exit()
 if i%100==0:print('PROGRESS',i,count,bad,flush=True)
Path('round2/arithmetic/unique_labels_results.json').write_text(json.dumps({'count':count,'bad_lp':bad,'failures':failures},indent=2))
