# Arithmetic and finite-shape results, round 2

This branch does not prove or disprove unrestricted Wilf in embedding dimension four. Its main result is an analytic proof that a residue-bijective lower ideal with minimal excluded corner `(1,1,1)` has at most six coordinatewise maxima. The previously certified complete six-point theorem therefore proves Wilf for that entire class. The full argument and its computational dependency are explicit in `interior_corner_111.md`. A second structural result is the two-triangular-faces exclusion in `two_triangular_faces.md`. The strongest completed finite classification covers all 4,095 lower ideals strictly between the degree-3 and degree-4 three-face staircases.

## Exact finite classification

Write `F_d={x in N^3 : x1+x2+x3<=d, min(x1,x2,x3)=0}`. Every set `F_3 ⊊ T ⊆ F_4` is a lower ideal, and arises uniquely by selecting a nonempty subset of the 12 degree-4 boundary points. There are exactly 4,095 such sets, with sizes 20 through 31.

For each set the script `shell_classification.py` minimizes

`D=3mM-4(a1*s1+a2*s2+a3*s3)`

subject to `a1>=m+1`, `a2-a1>=1`, `a3-a2>=1`, and `M>=a·x` at every maximal point of `T`. It calls the existing exact primal/dual verifier, so every reported optimum is verified by rational arithmetic; SciPy merely proposes primal and dual solutions.

Exactly seven shapes fail the sufficient inequality `D>=m(m-1)`:

| Shape | Size | Arithmetic exclusion |
|---|---:|---|
| `F_4` | 31 | Two triangular faces theorem |
| `F_4 - {(3,1,0)}` | 30 | Two triangular faces theorem |
| `F_4 - {(3,0,1)}` | 30 | Two triangular faces theorem |
| `F_4 - {(2,2,0)}` | 30 | Two triangular faces theorem |
| `F_4 - {(1,3,0)}` | 30 | Two triangular faces theorem |
| `F_4 - {(4,0,0)}` | 30 | Four mixed corners of the opposite full triangular face require distinct nonzero representatives on an axis having only three nonzero points |
| `F_4 - {(0,0,4)}` | 30 | Same counting obstruction |

The axis ordering here is the generator order `a1<a2<a3`; the LP asymmetry explains why coordinate permutations of a listed failure need not fail that relaxation. The family enumerated includes all coordinate permutations, so none is omitted.

The enumeration additionally checks all residue vectors compatible with the interior-corner equation `A+B+C=0 mod m`, without normalizing a residue to 1. All seven yield no residue bijection, consistent with the analytic exclusions.

**Corollary (computer-assisted through the exact LP enumeration).** Wilf holds whenever the preferred Apéry staircase lies strictly between `F_3` and `F_4`. The missing proof obligation for an unrestricted argument is to show that arbitrary geometrically failing shapes reduce to a finite classified family. This branch has not established such a reduction.

## Genuine-shape diagnostics

`search_geometric.py` generated 100,000 seeded proposals, including generators in a narrow interval far above the multiplicity, nearby arithmetic triples, and weights as large as twice the multiplicity squared. It produced 91,122 minimally four-generated numerical semigroups and 65,012 distinct preferred Apéry shapes. No ordered geometric LP failed for multiplicities 20 through 1,000.

The closest observed ratio was `D_LP/[m(m-1)]=4/3`, for the shape of `<25,129,130,134>`, whose relaxed optimum is `D=800`, at artificial weights `(26,27,28)` with `M=112`.

A separate seeded 30,000-proposal search at multiplicities 4 through 19 yielded 24,684 valid semigroups and 2,263 distinct shapes. Three shapes failed ordered geometry, at multiplicities 5, 7 and 8. These are diagnostics, not exhaustive classifications of those multiplicities.

## Abstract-shape diagnostics

`search_abstract_profiles.py` sampled lower ideals built from three arbitrary monotone coordinate-plane profiles and an optional full-support corner. Among 80,860 distinct shapes of size at least 20, 13 failed the unordered moment certificate and five failed an ordered certificate. The largest failing shape had size 30. This does not rule out unsampled failures of any larger size.

`unique_labels_m20.py` checked 13,104 shapes defined by pairwise linear bounds and a corner cap, with no failure found after imposing distinct integer labels in its bounded search. The universal distinct-label relaxation is nevertheless false: take `F_2` of size 10 and weights `(21,23,24)`. Its ten integer labels are distinct, but `M=48`, `Σ=340`, and `D=80<90`. Residue bijectivity still fails. Thus integer distinctness alone cannot replace arithmetic in a universal theorem.

## Files

- `two_triangular_faces.md`: full all-parameter structural proof.
- `shell_classification.py` and `shell_classification_results.json`: completed exact finite classification.
- `search_geometric.py` and `search_geometric_results.json`: completed large genuine-shape diagnostic.
- `search_small.py` and `search_small_results.json`: completed small genuine-shape diagnostic.
- `search_abstract_profiles.py` and `abstract_profiles_results.json`: completed arbitrary-profile diagnostic.
- `unique_labels.py`, `unique_labels_results.json`, `unique_labels_m20.py`, and `unique_labels_m20_results.json`: weaker integer-label relaxation checks.

No publication priority claim is made for the structural lemma or the finite classification.

## The local combinatorial deficit C

For each point `x∈T`, define `g(x)=max{|z|_1:z∈T,z>=x}`. For each coordinate line with top `t` and length `L`, set its local contribution to `L*(g(t)-|t|_1)`, and sum these contributions to obtain `C(T)`. Dynamic programming from higher to lower total degree computes every value with integers. For actual positive generator weights, `D>=a_min*C(T)`.

A seeded 20,000-proposal arbitrary-profile/cap search checked the conjectural inequality `9*C(T)>=m*(q-12)`, where `q` is the number of coordinatewise maxima. Of those proposals, 16,619 had `q>12`; no violation was found. The smallest ratio `9C/[m(q-12)]` was approximately 1.68610866 at `m=3405,q=57,C=28706`. This remains an unproved inequality.

The stronger proposed implication “no interior corner and q>=7 imply C>=m-1” is false. A sampled shape has `m=18,q=7,C=14`, described by xy row lengths `(5,4,3,2,1)`, xz heights `(3,1,1,1,1)`, yz heights `(3,2,1,1,1)`, and no cap.

Moreover the established double staircase

`T_R={(x,y,z):x+y<=R,x+z<=R,y*z=0}`

has `m=(R+1)^2`, `q=2R+1`, and `C=R(R+1)(R-1)/3`. At `R=4`, this gives `m=25,q=9,C=20<24`. This shape is realizable (after permuting coordinate axes it is the known shape of `<25,26,30,31>`), so the low value of C cannot itself be used as an arithmetic impossibility argument. Its Wilf inequality was already proved by the earlier weighted double-staircase estimate.

A further no-interior search restricted to `m>=85,q>=7` completed 100,000 proposals, with 86,797 meeting those conditions. None had `C<m-1`; the smallest observed ratio was `281/113≈2.48673`, at `m=114,q=14`. This is only a seeded diagnostic.

The corresponding C claim is also false for an existing full interior corner other than `(1,1,1)`: a shape with unique full corner `(1,2,1)` has `m=20,q=7,C=16<19`. Its coordinate-plane profiles are xy `(5,3,1)`, xz `(4,2,1)`, yz `(4,4,3,2,1)`, with that interior cap. The ordered geometric certificate nevertheless passes: `D_min=1104>380`, at `(a1,a2,a3,M)=(21,22,23,91)`. See `nonunit_corner_probe_results.json` for the full shape and exact dual. The targeted probe stopped after 6,321 proposals, of which 4,165 had an actual nonunit full minimal corner. All ten encountered C-failure shapes passed their ordered geometric LP.

## Additional analytic extension and independent audit

`general_interior_corner_bound.md` proves that for full corner `p=(r,s,t)` with `P=r+s+t`, each coordinate plane has at most `P-2` mixed corners, and the number of coordinatewise maximal points satisfies

`q <= r*(k_yz+1)+s*(k_xz+1)+t*(k_xy+1) <= P*(P-1)`.

This does not settle `P>=4`. The independent audit agent checked both this extension and the `(1,1,1)` theorem and reported no gap. The detailed primary audit is saved by that agent in `round2/audit/interior_corner_111_audit.md`.
