import sys,random,json,itertools,time
sys.path.insert(0,'prior/wilf_edim4_reassessment_checks_2026-09-05')
from wilf_reassessment import ordered_geometric_optimum,corners
rng=random.Random(517926)
def inv(T):
 q=C=0;g={}
 for x in sorted(T,key=sum,reverse=True):
  up=[tuple(v+(i==j) for i,v in enumerate(x)) for j in range(3)];sx=sum(x);gx=max([sx]+[g[y] for y in up if y in g]);g[x]=gx;q+=all(y not in T for y in up);C+=sum((x[j]+1)*(gx-sx) for j,y in enumerate(up) if y not in T)
 return q,C

def prof(a,b,mode):
 if mode:return [b]+sorted([rng.randint(1,b) for _ in range(a-1)],reverse=True)
 return [b]+sorted([max(1,min(b,int(b*(1-i/a))+rng.randint(-1,1))) for i in range(1,a)],reverse=True)
records=[];best=1e30;eligible=0;bad=[]
for i in range(20000):
 d=rng.randint(2,14);A,B,C=[max(2,d+rng.randint(-2,2)) for _ in range(3)];p=prof(A,B,i%3);q=prof(A,C,i%3);r=prof(B,C,i%3)
 cap=[rng.randint(1,max(1,n//2)) for n in [A,B,C]]
 if sum(cap)==3:continue
 T=frozenset((x,y,z) for x in range(A) for y in range(p[x]) for z in range(min(q[x],r[y])) if not all(a>=b for a,b in zip((x,y,z),cap)))
 if not all(tuple(v-(k==j) for k,v in enumerate(cap)) in T for j in range(3)):continue
 eligible+=1;m=len(T);qq,cc=inv(T);ratio=cc/(m-1)
 if ratio<best:
  best=ratio;rec={'i':i,'m':m,'q':qq,'C':cc,'ratio':ratio,'profiles':[p,q,r],'cap':cap};records.append(rec);print(json.dumps(rec),flush=True)
 if cc<m-1:
  rec={'i':i,'m':m,'q':qq,'C':cc,'ratio':ratio,'profiles':[p,q,r],'cap':cap}
  rec['T']=sorted(T);rec['ordered_LP']=ordered_geometric_optimum(T);bad.append(rec);print('C_FAILURE '+json.dumps(rec),flush=True)
  if m>=20:break
open('round2/arithmetic/nonunit_corner_probe_results.json','w').write(json.dumps({'proposals':i+1,'eligible':eligible,'records':records,'failures':bad},indent=2));print('FINAL',i+1,eligible,best,len(bad),flush=True)
