"""Rerun exact arithmetic checks and the stored six-point certificates.

This is not an exhaustive Wilf search, a formal proof assistant, or a replacement
for reviewing the analytic proofs and enumeration completeness arguments.
"""
from pathlib import Path
import json
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
CHECKERS = [
    'round2/sharp_stability/check_sharp_stability.py',
    'round2/amplification/check_general_dimension.py',
    'round2/sharp_stability/check_two_plane_family.py',
    'prior/wilf_edim4_six_point_verification_2026-09-05/verify_six_certificates.py',
]


def main():
    records = []
    for name in CHECKERS:
        path = ROOT / name
        start = time.monotonic()
        run = subprocess.run([sys.executable, str(path)], cwd=path.parent,
                             text=True, capture_output=True, check=True)
        records.append({'checker': name, 'exit_code': run.returncode,
                        'seconds': round(time.monotonic()-start, 3),
                        'result': json.loads(run.stdout)})
    endpoint = (100003)**3
    assert endpoint == 1000090002700027 < 6*(2*10**14)
    output = {'status': 'all exact checks passed',
              'scope': 'Analytic constants, example certificates, and stored six-point certificate soundness. Not unrestricted Wilf verification.',
              'specialized_endpoint': {'left': endpoint, 'right': 6*(2*10**14)},
              'checks': records}
    target = Path(__file__).with_name('continuation_verification.json')
    target.write_text(json.dumps(output, indent=2)+'\n')
    print(json.dumps({'status': output['status'],
                      'checkers': len(records), 'output': str(target)}))


if __name__ == '__main__':
    main()
