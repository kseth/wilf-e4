"""Exact checks of the proved two-plane family, independently via Dijkstra."""
from heapq import heappop, heappush
from pathlib import Path
import json


def apery(gens):
    m=gens[0]
    d=[None]*m;d[0]=0
    todo=[(0,0)]
    while todo:
        w,r=heappop(todo)
        if d[r]!=w:continue
        for a in gens[1:]:
            v=w+a;s=v%m
            if d[s] is None or v<d[s]:
                d[s]=v;heappush(todo,(v,s))
    assert None not in d
    return d


def main():
    rows=[]
    for N in range(2,31):
        m=N*N;gens=[m,m+1,m+N,m+N+1]
        d=apery(gens)
        labels={m*max(p,q)+p+N*q for p in range(N) for q in range(N)}
        assert set(d)==labels and len(labels)==m
        conductor=max(d)-m+1
        genus=sum(w//m for w in d)
        n=conductor-genus;W=4*n-conductor
        assert conductor==N*N*(N-1)
        assert 6*genus==N*(N-1)*(4*N+1)
        assert 6*n==N*(N-1)*(2*N-1)
        assert 3*W==N*(N-1)*(N-2)
        R=N-1
        T={(x,y,0) for x in range(N) for y in range(N-x)}
        T|={(x,0,z) for x in range(N) for z in range(N-x)}
        tops=[];C=0
        for x in T:
            is_max=True
            for j in range(3):
                y=list(x);y[j]+=1
                if tuple(y) not in T:
                    C+=(x[j]+1)*(R-sum(x))
                else:is_max=False
            if is_max:tops.append(x)
        assert len(T)==m and len(tops)==2*R+1
        assert 3*C==R*(R+1)*(R-1)
        rows.append(dict(N=N,m=m,q=len(tops),C=C,W=W))
    result={'rows':rows,'status':'All exact assertions passed.'}
    Path(__file__).with_name('two_plane_family_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':main()
