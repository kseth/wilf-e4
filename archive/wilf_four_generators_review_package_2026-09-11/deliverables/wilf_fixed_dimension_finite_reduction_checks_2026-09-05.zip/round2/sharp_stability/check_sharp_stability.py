"""Exact constants and finite counterexample checks; not a Wilf proof."""
from fractions import Fraction as F
from pathlib import Path
import json


def q(s):
    return F(str(s))


def main():
    eps = F(1, 10000)
    certificates = {
        "bootstrap_1": 6*q('.08')*q('.04')**2*q('.58'),
        "bootstrap_2": 6*q('.04')*q('.05')*q('.02')*q('.49'),
        "bootstrap_3": 6*q('.02')*q('.05')**2*q('.42'),
        "witness_1": 6*q('.16')*q('.06')**2*q('.31'),
        "witness_2": 6*q('.10')*q('.05')*q('.06')*q('.21'),
        "witness_3": 6*q('.04')*q('.07')**2*q('.1098'),
    }
    assert F(1,12)-eps/4 > q('.08')
    assert all(x > eps for x in certificates.values())

    p = (q('.5001'), q('.25'), q('.25'))
    pp = (p[1], p[0], p[2])
    b = (q('.25'),)*3
    assert sum(p)>1 and sum(pp)>1
    witnesses = [b]
    for point in (p, pp):
        for j in range(3):
            x=list(point); x[j]=q('.0001'); witnesses.append(tuple(x))
    for x in witnesses:
        x=sorted(x)
        assert x[0]<=q('.25') and sum(x[:2])<=q('.5') and sum(x)<=q('.7502')

    # A finite rational-cell downset disproving the proposed kappa_c>=1/3.
    radius, cap = 45, 5
    t=set()
    for x in range(radius+1):
        for y in range(radius+1-x):
            h=min(radius-x,radius-y)
            if x>cap and y>cap:
                h=min(h,cap)
            t.update((x,y,z) for z in range(h+1))
    m=len(t); sigma=sum(map(sum,t)); M=max(map(sum,t))
    assert (m,sigma,M)==(14871,505800,50)
    candidates=set()
    for x in t:
        for j in range(3):
            y=list(x); y[j]+=1; y=tuple(y)
            if y not in t: candidates.add(y)
    corners=[]
    for x in candidates:
        predecessors=[]
        for j in range(3):
            if x[j]:
                y=list(x); y[j]-=1; predecessors.append(tuple(y))
        if all(y in t for y in predecessors): corners.append(x)
    interior=[x for x in corners if all(x)]
    assert interior==[(6,6,6)]
    mu=(F(sigma,m)+F(3,2))/(M+3)
    kc=3-4*mu
    assert mu==F(352071,525442) and kc==F(84021,262721)<F(1,3)
    result={
        "continuous_gap":str(eps),
        "propagation_certificates":{k:str(v) for k,v in certificates.items()},
        "finite_counterexample_to_gap_one_third":{
            "definition":"x+y,x+z,y+z<=45; min(x,y,z)<=5",
            "m":m,"sigma":sigma,"M":M,"interior_corners":interior,
            "continuous_mu":str(mu),"continuous_kappa":str(kc),
        },
        "status":"All exact assertions passed; these checks do not prove unrestricted Wilf."
    }
    target=Path(__file__).with_name('sharp_stability_checks.json')
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
