# Structural C(T) attempt and an exact genuine two-plane family

## Definitions and the valid sufficient bound

For a finite lower ideal T in N^3, let

  h(x)=max{|z-x|_1:z in T, z>=x}.

For every coordinate line ell in T let t_ell be its top and L_ell its length. Define

  C(T)=sum_ell L_ell h(t_ell).

If all positive weights a_j are at least a_min, then

  M-w(t_ell)>=a_min h(t_ell),

and consequently D>=a_min C(T). For an Apéry ideal of size m, C(T)>=m-1 therefore proves Wilf, since a_min>=m+1 and

  D>=(m+1)(m-1)>=m(m-1).

No universal structural estimate that forces C(T)>=m-1 was proved in this continuation.

## A limited maximum-count lemma

Suppose T has at most one full-support minimal excluded point. Fix the first coordinate and let B,C be the lengths of the other two axes. If the full-support corner is (a,b,c), set

  t=min(max(B-b,0),max(C-c,0));

if there is no full-support corner, set t=0. Then the number q of maximal points satisfies

  q<=B+C+t.

Proof: write each first-coordinate slice as a fixed planar lower ideal intersected with a rectangle whose two side lengths decrease with the slice index. At index a, if present, additionally remove the upper rectangle y>=b,z>=c. Every maximal point disappears in the transition to the next slice. Except for the single corner transition, assign each disappearing maximal point to either an eliminated y index or an eliminated z index. Distinct planar maximal points have distinct y and distinct z coordinates, so assignments at a transition are injective; eliminated indices are never available again at a later transition. At most B+C such assignments occur. The exceptional removed maximal points have y>=b,z>=c, hence number at most t. This proves the claim.

This controls q by axis lengths but does not bound those lengths using C(T)/m. It does not prove the proposed stronger inequality 9C(T)>=m(q-12).

## A counterexample family to overly strong no-interior claims

For R>=1 define

  T_R={(x,y,z) in N^3:x+y<=R, x+z<=R, yz=0}.

This is the union of two planar degree-R triangles sharing the x axis. It has no full-support excluded corner because (0,1,1) is already excluded. Every maximal point has total degree R. Direct counting gives

  m=(R+1)^2,
  q=2R+1,
  C(T_R)=R(R+1)(R-1)/3.

For example R=4 gives m=25,q=9,C=20<m-1=24. Hence neither "no interior corner and q>=7" nor "no interior corner and m>=12" suffices to imply C>=m-1.

To verify the C formula, the x-coordinate fiber tops are maximal. At a point in the xy triangle with y>0, the missing z direction contributes the height R-x-y; the symmetric contribution arises from the xz triangle with z>0. Thus

  C=2(sum_{x+y<=R}(R-x-y)-sum_{x=0}^R(R-x))
   =2(R(R+1)(R+2)/6-R(R+1)/2).

## These shapes genuinely occur as Apéry ideals

They cannot be excluded using residue bijectivity alone. Let N=R+1>=2 and consider

  S_N=<N^2, N^2+1, N^2+N, N^2+N+1>.

Write m=N^2, a=m+N+1, b=m+1, c=m+N. All four generators lie in [m,2m), so the generating set is minimal. Since m and b are coprime, S_N is numerical.

The identity b+c=a+m shows that an Apéry factorization cannot have positive b and c coordinates simultaneously. A factorization with no such simultaneous occurrence can be represented by two integers p,q>=0 through

  x=min(p,q), y=max(p-q,0), z=max(q-p,0),

and has weight

  m max(p,q)+p+Nq.

For 0<=p,q<N these labels have all distinct residues p+Nq in [0,m), and the corresponding exponent set is exactly T_R.

They are the minimal labels in their residue classes. Indeed, any p,q outside this square has max(p,q)>=N. Write

  p+Nq=p0+Nq0+kN^2,

with 0<=p0,q0<N and k>=0. Its weight exceeds that of the square representative because

  max(p,q)+k>max(p0,q0).

A factorization containing both b and c first reduces by b+c=a+m, thereby decreasing its value by m while preserving its residue. A factorization containing the multiplicity is also not Apéry. These observations prove the claimed Apéry description.

## Exact invariants of the genuine family

The maximum Apéry element is a(N-1)=N^3-1. Summing over the N-by-N parameter square gives

  conductor = N^2(N-1),
  genus = N(N-1)(4N+1)/6,
  n = N(N-1)(2N-1)/6,
  W=4n-conductor=N(N-1)(N-2)/3>=0.

Thus these semigroups satisfy Wilf even in the small cases where their purely combinatorial C certificate fails. The actual differences between generator weights provide the missing contribution. Their density tends to 1/3 as N tends to infinity.

## Exact unresolved bottleneck

The proposed inequality

  9C(T)>=|T|(q-12)

for all one-interior-corner lower ideals was neither proved nor disproved here. Likewise the proposed size-only cutoff C(T)>=|T|-1 for |T|>=85 remains unproved. The limited slice-count lemma above does not bridge this gap. The two-plane family shows why a proof must retain either a quantitative moment estimate or the generator-weight information; the absence of an interior corner alone is insufficient at small sizes.
