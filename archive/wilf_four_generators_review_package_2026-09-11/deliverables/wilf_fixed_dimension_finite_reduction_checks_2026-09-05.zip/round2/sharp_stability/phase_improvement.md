# Sharper discrete phase estimate

Let T be a finite lower ideal in N^3 with positive weights u_j, normalized so that max_T u.x=1, and suppose that T contains all three unit vectors. Write

  kappa = 3 - 4 E[u.X], U = max u_j, v = min u_j.

Then

  U(1-7 kappa) <= (1+v)(4 kappa+2v).                 (P)

Thus, whenever kappa<1/7,

  U <= (1+v)(4 kappa+2v)/(1-7 kappa).

This replaces the earlier coarse phase bound U<=400 kappa+20v.

## Proof

Choose distinct coordinate directions j,k of weights U,v. This is possible even if all weights are equal. Let delta_j(x) denote the nonnegative deficit of the j-fiber top containing x. The coordinate-line identity gives

  E delta_j <= kappa,
  mu_k := E[v X_k] >= (1-3 kappa)/4.

Fix a k-fiber of length L. For t=0,...,L-1, its j-top deficits satisfy

  delta_j(t) >= [A-tv]_U,

where [.]_U is the representative in [0,U). Indeed the deficits differ modulo U by exactly -v between successive k-coordinate positions.

For each t and 0<=r<=v,

  [A-tv+r]_U <= [A-tv]_U+r <= delta_j(t)+r.

Integrating and summing gives, for one interval I of length h=Lv,

  integral_I [s]_U ds <= v sum_t delta_j(t)+Lv^2/2.  (1)

For every interval of length h, write h=qU+r, q>=0 an integer and 0<=r<U. Periodicity and the minimum integral over a remainder interval give

  integral_I [s]_U ds >= (qU^2+r^2)/2
                          >= h^2/[2(q+1)]
                          >= Uh^2/[2(h+U)].         (2)

The middle inequality is Cauchy--Schwarz on q copies of U and one copy of r. The first inequality holds because the q complete periods integrate to qU^2/2, while any arc of length r in the residue circle has integral at least r^2/2.

Combining (1)--(2),

  mean_fiber delta_j >= Uh/[2(h+U)]-v/2.

Every fiber satisfies v(L-1)<=1, so h<=1+v. Therefore

  mean_fiber delta_j >= UvL/[2(1+v+U)]-v/2.

Average over k-fibers with weights proportional to their lengths. Since v E L=2mu_k+v,

  E delta_j >= U(2mu_k+v)/[2(1+v+U)]-v/2
            = [2U mu_k-v(1+v)]/[2(1+v+U)].

Now E delta_j<=kappa and mu_k>=(1-3kappa)/4 imply

  4kappa(1+v+U) >= U(1-3kappa)-2v(1+v),

which rearranges to (P). No excluded-corner restriction or residue labeling is needed.

## A false continuous strengthening

The conjectural continuous strengthening kappa_c>=1/3 fails even within the one-interior-corner geometry. Let 0<p<=1/3, a=1-p, and

  K_p={x,y,z>=0: x+y,x+z,y+z<=a; min(x,y,z)<=p}.

Its maximum total coordinate is a+p=1. Its pair constraints are limits of finite unions of excluded pair orthants; the sole full-support excluded corner is (p,p,p). Strict/weak boundary conventions have no effect on volume or first moments.

Slice by the uniquely minimal coordinate r in [0,p]. Each of the three slices is a triangle of area (a-2r)^2/2, with conditional mean total coordinate 2a/3+5r/3. Thus

  E r = (a^2 p^2/2 -4a p^3/3+p^4)/(a^2 p-2a p^2+4p^3/3),
  mu = 2a/3+5 E r/3.

At p=1/10,

  E r=177/3860, mu=2611/3860, kappa_c=284/965<1/3.

Finite pair-orthant approximations converge in volume and first moment, so the failure is also realized in the exact finite-corner class after sufficiently fine approximation. An explicit finite rational-cell certificate is given by the accompanying checker.
