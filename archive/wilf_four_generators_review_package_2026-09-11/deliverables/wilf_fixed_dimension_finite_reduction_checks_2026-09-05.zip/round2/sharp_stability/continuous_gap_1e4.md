# Continuous one-corner gap at least 1/10000

## Statement

Let K be a bounded positive-volume downset in the nonnegative orthant, with maximum total coordinate at most one. Suppose its complement is a finite union of closed upper orthants with vertices supported on at most two coordinates, together with at most one vertex supported on all three coordinates. Then

  kappa_c := 3 - 4 E_K(x+y+z) >= 1/10000.

All decimals below are exact rational numbers. This strengthens the preceding 1/1000000 bound; it does not prove Wilf's conjecture.

## Identities used

Write V=vol(K), and H_j(y) for the coordinate-j fiber endpoint. The coordinate-fiber moment identity gives

  kappa_c V = J_1+J_2+J_3,
  J_j=integral H_j(y)(1-sum(y)-H_j(y))dy >=0.

Since K lies in the unit simplex, V<=1/6. Therefore any lower bound J_j>=B implies kappa_c>=6B.

Slicing by the minimum coordinate r, and using the two-dimensional moment inequality in each translated slice, gives

  E_K(x+y+z) <= 2/3 + E_K min(x,y,z).

## Initial cube and bootstrap

Suppose kappa_c<1/10000. Then

  E min(x,y,z) >= 1/12-kappa_c/4 > .08.

Some point of K consequently has all coordinates greater than .08, so K contains [.0,.08]^3.

We claim q=(.16,.16,.16) belongs to K. First force membership of v1=(.26,.04,.04). If omitted, integrate x-fibers over y,z in [.04,.08]. They have H_x>=.08 by the initial cube and H_x<=.26 by omission. Their top deficits are at least 1-.26-.08-.08=.58. Thus

  kappa_c >= 6(.08)(.04)^2(.58) = .00044544 > .0001,

a contradiction. Hence v1 belongs.

Next force v2=(.21,.21,.02). If omitted, integrate y-fibers over x in [.21,.26], z in [.02,.04]. Membership of v1 gives H_y>=.04; omission gives H_y<=.21; top deficits are at least 1-.26-.21-.04=.49. Thus

  kappa_c >= 6(.04)(.05)(.02)(.49) = .0001176 > .0001.

Finally, if q were omitted, integrate z-fibers over x,y in [.16,.21]. Membership of v2 gives H_z>=.02, omission gives H_z<=.16, and top deficits are at least 1-.21-.21-.16=.42. Thus

  kappa_c >= 6(.02)(.05)^2(.42) = .000126 > .0001.

Therefore q belongs to K, and the downset contains [.0,.16]^3.

## Seven forced witnesses

The following propagation argument works in any permutation of the coordinates. Let q satisfy

  q1<=.25, q1+q2<=.5, q1+q2+q3<=.7502,

with nonnegative coordinates. Set

  v1=(q1+.12,.10,.10),
  v2=(q1+.07,q2+.07,.04).

If v1 were omitted, integrate x-fibers over y,z in [.10,.16]. Their heights are at least .16 and their top deficits are at least 1-q1-.12-.32>=.31. Therefore

  kappa_c >= 6(.16)(.06)^2(.31) = .00107136 > .0001.

So v1 belongs. If v2 were omitted, integrate y-fibers over x in [q1+.07,q1+.12], z in [.04,.10]. Their heights are at least .10 and their top deficits are at least 1-q1-q2-.12-.07-.10>=.21. Therefore

  kappa_c >= 6(.10)(.05)(.06)(.21) = .000378 > .0001.

So v2 belongs. If q were omitted, integrate z-fibers over x in [q1,q1+.07], y in [q2,q2+.07]. Their heights are at least .04 and their top deficits are at least 1-sum(q)-.14>=.1098. Therefore

  kappa_c >= 6(.04)(.07)^2(.1098) = .0001291248 > .0001.

Thus q belongs.

Now take p=(.5001,.25,.25), p'=(.25,.5001,.25), and b=(.25,.25,.25). Both p,p' lie outside the unit simplex. The three points obtained from p by replacing one coordinate by .0001, the three analogous points from p', and b all satisfy the propagation conditions after ordering their coordinates increasingly. Hence all seven belong to K.

Any excluded-orthant vertex below p must have full support: otherwise it also lies below one of p's three witnesses. The same applies to p'. The at-most-one-full-support-vertex assumption therefore forces the same vertex below both p,p', hence below their coordinatewise minimum b. This contradicts b's membership.

Therefore kappa_c>=1/10000, as claimed.
