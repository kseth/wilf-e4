# Literature comparison for the fixed-embedding-dimension reduction

**Checked 5 September 2026.** Targeted searches with two search engines and
inspection of the primary sources below did not locate a theorem asserting
either (i) Wilf for all sufficiently large multiplicities at each fixed
embedding dimension, or (ii) only finitely many Wilf counterexamples at each
fixed embedding dimension. This is a limited literature check, not a claim
of publication priority or proof that no such result exists.

## 1. Statements that must be distinguished

| Source | Established statement relevant here | Distinction from our proposed fixed-e conclusion |
| --- | --- | --- |
| Zhai (2011), Theorem 2 | For every fixed `e` and every `epsilon>0`, all but finitely many semigroups of embedding dimension `e` satisfy `n/c>1/e-epsilon`. | This is an approximation from below. It permits infinitely many actual counterexamples approaching `1/e`. |
| Moscariello–Sammartano (2015), Theorem 1 | Fix `rho=ceil(m/e)`; sufficiently large `m` satisfies Wilf if every prime divisor of `m` is at least `rho`. | The fixed parameter is `rho`, not `e`. Their explicit lower bound on `m` grows on the order of `rho^4`; substitution `rho≈m/e` does not produce an eventual theorem for fixed `e`. |
| Hellus–Rechenauer–Waldi (2021), Proposition | A universal density bound `n/c>=2/(e^2-e+2)`; also `n/c>1/6` when `e=4` and `n/c>1/10` when `e=5`. | These are below the Wilf threshold for `e>=4`, and do not give fixed-e finiteness. |
| Bruns–García-Sánchez–O'Neill–Wilburne (2020) | An algorithm deciding Wilf for a specified multiplicity by integer feasibility in finitely many polyhedra. | This fixes `m` and does not bound all multiplicities at a specified `e`. Finite polyhedral descriptions do not themselves assert finitely many offending semigroups. |
| Chatterjee–Narula (May 2026), publisher abstract | Improves the Moscariello–Sammartano result, replacing the prime-divisor restriction by `gcd(m,a_1)=1` and sharpening its size bound. | The abstract explicitly retains fixed `rho=ceil(m/e)`; no unconditional fixed-e eventual theorem is stated there. Full text was not available through the retrieved publisher page. |

### Zhai's explicit question

In Section 5, Question 1 of [1], Zhai defines

\[
F(M,k)=\inf\{n(S)/c(S):e(S)=k,\ m(S)>M\}
\]

and asks for the limit as `M` tends to infinity, including whether it equals
`1/k`. The positive gap derived in `general_dimension.md` would imply that
this limit is strictly greater than `1/k` for every `k>=3`; it does not
determine the exact value of the limit. This is an implication of our
argument, not a result attributed to Zhai.

Zhai's equality family with fixed `m=e` and unbounded conductor does not
contradict the multiplicity-asymptotic gap: that family never has unbounded
multiplicity.

### Other meanings of asymptotically true

The combination of Eliahou's `c<=3m` theorem with Zhai's asymptotic counting
by genus proves density one of Wilf semigroups when ordered by genus. The
introduction to Marashdeh's August 2026 paper [6] expressly uses this
counting interpretation. A density-one theorem allows infinitely many
counterexamples and is a different assertion from eventual truth at fixed
embedding dimension.

## 2. Standard infinite-family constructions checked

### Dilatation

Barucci–Strazzanti [7] considers

`T={0} union {s+a:s in S, s>0}`,

for admissible nonnegative `a`. In their notation multiplicity is `e` and
embedding dimension is `nu`; translating to ours, Proposition 2.1 gives

\[
m(T)=m(S)+a,\quad e(T)=e(S)+a,\quad
c(T)=c(S)+a,\quad n(T)=n(S).
\]

Thus

\[
W(T)=W(S)+a(n(S)-1).
\]

This both changes embedding dimension and makes the Wilf number
nondecreasing. Proposition 2.7 establishes preservation of Wilf's inequality
in the positive direction. It supplies no counterexample-preserving
amplification at fixed embedding dimension.

### Shifting all generators

O'Neill–Pelayo [8] studies

`M_n=<n,n+r_1,...,n+r_k>`

with the offsets fixed. Corollary 4.6 establishes Wilf for sufficiently large
shifts (the stated threshold is `n>r_k^2`), with the Wilf number eventually
quasiquadratic. Thus a universal additive-shift amplification preserving a
negative Wilf number cannot exist. These fixed-offset families do not cover
arbitrary semigroups with only embedding dimension fixed: their generator
spread is an additional fixed parameter.

### Multiples with prescribed quotient

Ojeda–Rosales [9] supplies an explicit family `Delta_d(a)` with
`e(Delta_d(a))=e(Delta)+d-1` and proves preservation of Wilf's inequality.
This construction increases embedding dimension. Their rank-one families
have form `<x>+d Delta`; if `x` is already a minimal generator of `Delta`,
this is precisely the cyclic inflation studied in `amplification_analysis.md`.
If `x in Delta` is not minimal, the other scaled minimal generators remain
minimal and `x` adds one generator, so the embedding dimension increases.

No inspected standard construction provides the needed implication that one
counterexample produces counterexamples of unbounded multiplicity at the
same embedding dimension.

## 3. Primary references

1. A. Zhai, *An asymptotic result concerning a question of Wilf*,
   arXiv:1111.2779 (2011), Theorems 1–2 and Section 5 Question 1.
   https://arxiv.org/pdf/1111.2779
2. A. Moscariello and A. Sammartano, *On a conjecture by Wilf about the
   Frobenius number*, Math. Z. 280 (2015), 47–53, Theorem 1.
   https://doi.org/10.1007/s00209-015-1412-0
   Author-deposited full text:
   https://re.public.polimi.it/retrieve/e0c31c0f-b141-4599-e053-1705fe0aef77/On%20a%20conjecture%20of%20Wilf%20about%20the%20Frobenius%20number.pdf
3. M. Hellus, A. Rechenauer and R. Waldi, *A lower bound for the Wilf
   density, deduced from a result of Zhai*, arXiv:2107.06752v2 (2021).
   https://arxiv.org/pdf/2107.06752
4. W. Bruns, P. A. García-Sánchez, C. O'Neill and D. Wilburne,
   *Wilf's conjecture in fixed multiplicity*, IJAC 30 (2020), 861–882.
   https://arxiv.org/pdf/1903.04342
5. T. Chatterjee and P. Narula, *A note on Wilf's Conjecture*,
   Semigroup Forum, published 22 May 2026.
   https://doi.org/10.1007/s00233-026-10640-8
6. M. F. Marashdeh, *An upper bound for the type of a numerical semigroup,
   and a reduction of Wilf's conjecture*, arXiv:2608.12531v1 (2026).
   https://arxiv.org/html/2608.12531v1
7. V. Barucci and F. Strazzanti, *Dilatations of numerical semigroups*,
   Semigroup Forum 98 (2019), preprint arXiv:1710.07586,
   Propositions 2.1 and 2.7.
   https://arxiv.org/pdf/1710.07586
8. C. O'Neill and R. Pelayo, *Apéry sets of shifted numerical monoids*,
   Adv. Appl. Math. 97 (2018), 27–35, Corollary 4.6.
   https://arxiv.org/pdf/1708.09527
9. I. Ojeda and J. C. Rosales, *On Numerical Semigroups with Fixed
   Quotient*, arXiv:2605.14775v1 (2026), Proposition 3.2 and Section 4.3.
   https://arxiv.org/html/2605.14775v1

## 4. Retrieval references for the root agent

The root must open a source itself before citing these tool references.

- Zhai: `turn533195view0`, `turn742899view0`.
- Moscariello–Sammartano: `turn295443view0`, full text `turn359050view1`.
- Density bound: `turn764085view0`.
- Fixed multiplicity: `turn764085view2`, `turn340188view2`.
- Chatterjee–Narula: `turn411034view0`.
- Marashdeh: `turn764085view1`, `turn340188view3`.
- Dilatation: `turn440111view2`.
- Shifted monoids: `turn411034view1`.
- Fixed quotient: `turn162546view0`.
