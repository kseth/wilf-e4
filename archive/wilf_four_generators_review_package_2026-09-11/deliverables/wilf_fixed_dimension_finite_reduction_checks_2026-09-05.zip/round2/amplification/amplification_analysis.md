# Amplification and descent audit

## 1. Cyclic inflation strictly increases the Wilf number

Let `S=<b_0,b_1,b_2,b_3>` have embedding dimension four and multiplicity
`m=min b_i`. Choose one generator `a=b_j`, and let `q>=2` satisfy
`gcd(q,a)=1`. Put

`S_q=<a,q b_i (i!=j)>`.

The displayed generating set is minimal. Indeed, a decomposition of `qb_i`
would have its coefficient of `a` divisible by `q`; division by `q` would
decompose the original minimal generator `b_i`. A decomposition of `a` by
the other new generators contradicts `gcd(q,a)=1`. The exact identity is

\[
W_4(S_q)=qW_4(S)+(q-1)(a-1).
\]

The chosen unscaled generator may be the multiplicity. The identity does not
require either of the other displayed generators to be the multiplicity: for
any one such generator `b`,

\[
\operatorname{Ap}(S_q,qb)
=\bigsqcup_{i=0}^{q-1}\bigl(ia+q\operatorname{Ap}(S,b)\bigr).
\]

To see this, reduce the coefficient of `a` modulo `q`. Distinct summands have
distinct residues modulo `q`; inside one summand, Apéry representatives are
distinct modulo `qb`. Minimality follows by reducing the coefficient of `a`
modulo `q` in any putative smaller representative. The maximum and sum of this
set give

\[
c(S_q)=q c(S)+(q-1)(a-1),\qquad
g(S_q)=q g(S)+\frac{(q-1)(a-1)}2.
\]

The lower-ideal inequality gives `W_4(S)>=-(m-1)`. In fact, for four distinct
minimal generators,

\[
W_4(S)\ge -(m-2).
\tag{1}
\]

Here is the strictness argument. Write the three nonmultiplicity generator
weights as `u_1,u_2,u_3`, and use the preferred Apéry lower ideal `T` containing
the three unit vectors. In the identity

\[
D=\sum_\ell L_\ell(M-w(t_\ell))\ge0,
\]

equality would mean that every nonempty coordinate line has its top at weight
`M`. Fix distinct directions `i,j`. The direction-`j` lines through `0` and
`e_i` would then imply that `u_i` is a positive integer multiple of `u_j`.
Interchanging `i,j` makes `u_j` a positive integer multiple of `u_i`. Thus all
three weights would be equal, a contradiction. Hence `D>0`; since
`mW_4=D-m(m-1)` and `W_4` is an integer, (1) follows.

Therefore every cyclic inflation preserving embedding dimension four obeys

\[
\boxed{W_4(S_q)-W_4(S)
=(q-1)(W_4(S)+a-1)\ge q-1>0.}
\tag{2}
\]

This applies when the choice of unscaled generator changes at every step.
Starting with a hypothetical counterexample of Wilf number `-r`, a chain of
such inflations can remain a counterexample for at most `r-1` steps; more
precisely the sum of their `q_i-1` must be at most `r-1`. So this entire class
of constructions cannot produce counterexamples of arbitrarily large
multiplicity. With a fixed unscaled generator `a`, the simpler additional
obstruction is `m(S_q)<=a`.

There is also a stronger multiplicity obstruction. Write `W_4(S)=-r<0` and
suppose the lift is still a counterexample, with `W_4(S_q)=-r'<0`. If
`a>=qm`, then

`r'=qr-(q-1)(a-1)<=q(m-2)-(q-1)(qm-1)<0`,

a contradiction. Hence the new multiplicity is exactly `m'=a`. Consequently

\[
\begin{aligned}
m'+r'-(m+r)
&=(q-1)r-(q-2)a+q-1-m\\
&\le(q-1)(r-m+1)\\
&\le-(q-1).
\end{aligned}
\]

Thus `m+|W_4|` strictly decreases along every counterexample-preserving
cyclic inflation. Every negative semigroup reachable by any chain of these
operations has multiplicity smaller than `m+r<=2m-2` of the initial
semigroup. Repeatedly changing the untouched generator cannot evade the
obstruction.

This is an obstruction to an amplification strategy, not a proof of Wilf.
It explains why the previously verified cyclic-inflation descent cannot be
reversed to combine directly with the eventual multiplicity theorem.

## 2. All generators of any remaining counterexample lie below its conductor

This exclusion uses the known cases `c<=3m` and `m<=19`; it makes no claim of
novelty relative to the literature.

Suppose `S=<m,a,b,d>` and `d>=c`. In the Apéry exponent ideal `T`, the third
coordinate occurs only at `e_3`: any addition of a generator to `d` exceeds
`M=c+m-1`, as does `2d` since `c>=m` and `d>m`. Consequently

`T=T_0 disjoint-union {e_3}`,

where `T_0` is a planar lower ideal of cardinality `m-1`. The planar
lower-ideal inequality yields

\[
\sum_{T_0}w\le\frac23(m-1)M.
\]

Since `d<=M`, it follows that

\[
D=3mM-4\sum_Tw\ge\frac{m-4}{3}M.
\]

If `c>3m`, integrality gives `M>=4m`. For `m>=13`,

\[
D\ge\frac{4m(m-4)}3\ge m(m-1),
\]

and hence `W_4>=0`. The remaining smaller multiplicities are already covered
by the known `m<=19` result. Thus any counterexample remaining after the
published small-conductor and small-multiplicity exclusions satisfies

\[
\boxed{m<a<b<d<c.}
\]

## 3. Semigroup-tree steps do not currently furnish a uniform descent

If a minimal generator `x>=c` is removed and the resulting semigroup still
has embedding dimension four, then its new conductor is `x+1` and

\[
W_4(S\setminus\{x\})=W_4(S)+3(x-c)-1.
\]

Only removal of `x=c` decreases the Wilf number. Section 2 shows that any
remaining counterexample has no generator at or above the conductor, so this
kind of first descent step is unavailable on every remaining candidate.

Conversely, adding the Frobenius number `c-1` has no general fixed-embedding-
dimension guarantee. For `c>m+1`, the new element is a new minimal generator;
the only old minimal generator which could cease to be minimal is `c+m-1`.
Indeed an old minimal generator is at most `c+m-1`; a decomposition involving
one copy of `c-1` can therefore use only the old positive element `m`, and a
decomposition involving two copies would exceed that bound. By Section 2 a
remaining counterexample has largest generator below `c`, so adjoining its
Frobenius number raises its embedding dimension from four to five. This
blocks the most immediate ancestor-based descent as well.

## 4. Status

No counterexample-preserving amplification with unbounded multiplicity was
found. The strict monotonicity in (2) rules out all repeated cyclic inflation
schemes, including those which change the untouched generator between steps.
The all-left-generators exclusion also prevents immediate semigroup-tree
descent or ascent from preserving embedding dimension four.
