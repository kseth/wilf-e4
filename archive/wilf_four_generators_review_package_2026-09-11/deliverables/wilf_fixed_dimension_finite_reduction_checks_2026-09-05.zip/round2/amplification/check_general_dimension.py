"""Exact checks of stated constants and finite simplex counts, not a Wilf search."""
from fractions import Fraction as F
from math import comb, factorial
from pathlib import Path
import json

results = []
for d in range(2, 31):
    h = F(1, 8*d)
    r = F(1, 16*d*d*(d+1))
    t = F(1, 2*d*(d+1))
    delta = factorial(d)*h*r**d
    P = 1+32*d*(d-1)*(d+1)**2
    Q = 4*d*(d-1)*(d+1)
    eta = delta/(2*P)
    H = F((d-1)*P, 1)/delta
    B_unrounded = (d+H)**d/factorial(d)
    B = (B_unrounded.numerator+B_unrounded.denominator-1)//B_unrounded.denominator
    assert delta < F(1,2*d)
    assert (d+1)*r <= t
    assert d*(d+1)*r == h/2
    assert 2*Q <= (d-1)*P
    assert eta < F(1,2*d)
    assert eta*H == F(d-1,2)
    assert Q/H <= delta/2
    assert factorial(d)*B >= (d+H)**d
    alpha = F(1,2*d)
    beta = F(1,2)+F(1,4*d)
    p = [alpha+beta, *([alpha]*(d-1))]
    q = [alpha, alpha+beta, *([alpha]*(d-2))]
    assert sum(p) == sum(q) == 1+F(1,4*d)
    assert sum(min(x,y) for x,y in zip(p,q)) == F(1,2)
    for x in (p,q):
        for j in range(d):
            witness = x.copy()
            witness[j] = h
            assert sum(witness) <= 1-h
    for R in range(2, 31):
        m = comb(d+R,d)
        E = comb(d+R-1,d)+d*comb(d+R-2,d-1)
        claimed = F((d-1)*(R-1),R)*comb(d+R-2,d-1)
        assert E-m == claimed > 0
    if d <= 8:
        results.append({'d':d, 'embedding_dimension':d+1,
                        'delta':str(delta), 'P':P, 'Q':Q,
                        'threshold_B':str(B), 'threshold_digits':len(str(B))})

result = {'status':'all exact checks passed', 'dimensions_checked':[2,30],
          'simplex_radii_checked':[2,30], 'constants':results}
Path(__file__).with_name('general_dimension_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
