"""Exact diagnostic checks; these finite checks do not prove Wilf."""
import importlib.util
import json
from math import gcd
from pathlib import Path
from random import Random

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location(
    'wilf_work', ROOT / 'prior/wilf_edim4_verification_2026-09-05/wilf_work.py')
work = importlib.util.module_from_spec(spec)
spec.loader.exec_module(work)
rng = Random(20260905)
checked = lifts = all_left_exclusions = 0
examples = []
fixtures = [[4,5,6,7], [5,6,7,9], [13,14,15,77], [23,24,25,252]]
while checked < 200:
    if fixtures:
        gens = fixtures.pop(0)
        m = gens[0]
    else:
        m = rng.randrange(4, 65)
        gens = [m, *sorted(rng.sample(range(m+1, 6*m), 3))]
    source = work.inspect(gens, verify=False)
    if source is None:
        continue
    checked += 1
    assert source['W'] >= -(m-2)
    for j, a in enumerate(gens):
        for q in (2, 3, 5):
            if gcd(q, a) != 1:
                continue
            target_gens = [a if i == j else q*b for i, b in enumerate(gens)]
            target = work.inspect(target_gens, verify=False)
            assert target is not None
            assert target['c'] == q*source['c']+(q-1)*(a-1)
            assert 2*target['g'] == 2*q*source['g']+(q-1)*(a-1)
            assert target['W'] == q*source['W']+(q-1)*(a-1)
            assert target['W']-source['W'] >= q-1
            lifts += 1
    if gens[-1] >= source['c']:
        ap = work.apery(gens)
        T = [x for w, x in ap[2]]
        assert [x for x in T if x[2]] == [(0, 0, 1)]
        M = source['c']+m-1
        D = m*source['W']+m*(m-1)
        assert 3*D >= (m-4)*M
        all_left_exclusions += 1
        if len(examples) < 3:
            examples.append(source)

result = {'seed': 20260905, 'semigroups_checked': checked,
          'cyclic_lifts_checked': lifts,
          'right_generator_shape_checks': all_left_exclusions,
          'right_generator_examples': examples,
          'status': 'all exact identities and inequalities passed'}
out = Path(__file__).with_name('amplification_checks.json')
out.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='right_generator_examples'}))
