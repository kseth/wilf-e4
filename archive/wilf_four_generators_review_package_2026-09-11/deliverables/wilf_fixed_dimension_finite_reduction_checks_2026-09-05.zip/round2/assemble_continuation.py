"""Assemble the audited research continuation; no claim of a full Wilf proof."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'deliverables' / 'wilf_fixed_dimension_finite_reduction_2026-09-05.md'

INTRO = r'''# Wilf research continuation: finite reduction and new four-generator classes

**5 September 2026. Research manuscript.**

The unrestricted conjecture is not proved or disproved by this manuscript.
The work completes several subarguments and identifies a finite region that
has not been eliminated. Independent adversarial checks within this research
session found no gap in the analytic theorems below; that is not external
peer review or a claim of publication priority.

## Results established in this continuation

For a numerical semigroup let \(m\) be the multiplicity, \(c\) the conductor,
\(e\) the embedding dimension, \(n=|S\cap[0,c)|\), and \(W_e=en-c\).

1. **Four generators, large multiplicity:**
   \[
   \boxed{m\ge2\times10^{14}\quad\Longrightarrow\quad W_4>0.}
   \]
   The proof is analytic. It replaces the previous \(10^{27}\) cutoff.
2. **Every fixed embedding dimension:** there is an explicit \(B_{e-1}\)
   above which \(W_e>0\), and an explicit upper bound on every generator
   in any remaining counterexample. Consequently only finitely many possible
   counterexamples remain at each fixed \(e\). This does not give a finite
   bound uniform over all embedding dimensions.
3. **Interior corner \((1,1,1)\):** a residue-bijective Apéry staircase
   with this minimal excluded point has at most six coordinatewise maxima.
   Hence its semigroup satisfies Wilf, by the previously completed six-point
   theorem. The new structural proof is analytic; this Wilf corollary retains
   the earlier theorem's finite computational dependency.
4. **A generator criterion:** if a nonmultiplicity minimal generator \(A\)
   satisfies \(m\mid2A\), then Wilf holds. More generally, if its first
   critical multiple is \(aA=bm\), Wilf holds for
   \(m\ge16a^3-2\). The exponent-two corollary also uses the six-point
   theorem; the parameter cutoff uses the analytic slab theorem.

Part I gives the complete analytic fixed-dimension proof, including an
independent conductor bound. Part II proves the sharper four-generator
cutoff. Part III gives the new residue argument. Part IV records what is
still missing and distinguishes failed auxiliary claims from counterexamples
to Wilf.

The accompanying verification archive contains the source notes, independent
audits, exact checkers and outputs, and the prior computational dependencies.

---

# Part I. Explicit finite reduction at every fixed embedding dimension

'''

SUMMED = r'''
## Summing the two phase inequalities

Use \(d=3\), \(u_i=a_i/M\), \(v=\min u_i\), \(U=\max u_i\),
\(s=u_1+u_2+u_3\), and \(\kappa=D/(mM)\). Choose an index \(k\)
of minimum weight. Write \(\bar\delta_j=\mathbb E\delta_j\).
The preceding sawtooth proof works for each \(j\ne k\), giving
\[
2\bar\delta_j(1+v+u_j)\ge2u_j\mu_k-v(1+v).
\]
Summing both inequalities, and using nonnegativity of every
\(\bar\delta_j\), gives
\[
(s-v)\mu_k\le(1+v+U)(\kappa-\bar\delta_k)+v(1+v).
\]
The exact identity \(\mu_k=(1+\kappa)/4-\bar\delta_k\) yields
\[
\frac{(s-v)(1+\kappa)}4
\le(1+v+U)\kappa+v(1+v)
 +\bar\delta_k[(s-v)-(1+v+U)].
\]
The bracket equals the middle weight minus \(1+v\), hence is
nonpositive: every normalized weight is at most one because the unit
vectors belong to the staircase. Discard that term and use \(U\le s-2v\).
Rearrangement gives the useful bound
\[
\boxed{s(1-3\kappa)\le4\kappa+5v-3\kappa v+4v^2.}
\tag{S1}
\]

Suppose, for contradiction, that \(W_4\le0\). The Apéry identity gives
\[
\kappa=\frac{W_4+m-1}{M}\le\frac{m-1}{M}<\frac{a_{\min}}M=v.
\]
For \(v<1/3\), the quotient on the right of (S1), after division by
\(1-3\kappa\), is strictly increasing in \(\kappa\): its derivative
has numerator \(4+12v+12v^2>0\). Therefore
\[
s<\frac{9v+v^2}{1-3v}.
\]
The continuous thickening has
\(\kappa_c=(\kappa+s)/(1+s)\). This expression is increasing in
both variables for \(\kappa<1\), so
\[
\boxed{\kappa_c<\frac{2v(5-v)}{1+6v+v^2}<10v.}
\tag{S2}
\]

On the other hand,
\[
m\le\binom{\lfloor1/v\rfloor+3}{3}
\le\frac{(1/v+3)^3}{6}.
\]
If \(m\ge2\times10^{14}\), the exact integer inequality
\[
(100003)^3=1000090002700027
 <1200000000000000=6(2\times10^{14})
\]
forces \(v<1/100000\). Equation (S2) then gives
\(\kappa_c<1/10000\), contradicting the continuous lemma.
This proves \(W_4>0\) throughout the stated tail, including the exclusion
of equality there. The proof uses no enumeration of numerical semigroups.

'''

REMAINING = r'''
---

# Part IV. The remaining proof obligation

The prior analytic four-generator conductor reduction establishes
\[
W_4<0\quad\Longrightarrow\quad
M\le m(m-2),\qquad c\le m^2-3m+1,\qquad a_3\le m(m-2).
\]
Its full proof is included in the archive as
`dependencies/wilf_edim4_global_finite_reduction_2026-09-05.md`.
It treats full weighted staircases analytically and counts the line slack
created by low-weight excluded corners in all other cases. This sharper
bound is separate from the general conductor lemma in Part I.

Combining it with Part II and the published verification through multiplicity
19 leaves the necessary counterexample region
\[
\boxed{
20\le m<2\times10^{14},\qquad
m<a_1<a_2<a_3\le m(m-2),\qquad
c\le m^2-3m+1.
}
\]
The generators must be minimal and have greatest common divisor one. The
six-point theorem additionally forces at least seven final-window Apéry
points. Part III excludes the interior corner \((1,1,1)\).

**No theorem or completed enumeration here proves that this finite region is
empty. No numerical semigroup with negative Wilf number was found.**
The missing step is a universal inequality or an exhaustive certificate for
the surviving smaller-multiplicity staircases. Finiteness alone supplies
neither. The upper bound is much too large for a naive loop over generators.

## Other completed structural work

The archive includes full proofs of the following reductions.

- For an interior minimal excluded point \(p=(r,s,t)\), put \(P=r+s+t\).
  Each coordinate plane has at most \(P-2\) mixed minimal excluded points,
  and the whole staircase has at most \(P(P-1)\) coordinatewise maxima.
  This recovers the six-maxima bound at \(P=3\), but does not close
  \(P\ge4\).
- If the least multiple of some nonmultiplicity generator \(A\) that is
  representable by the other generators is \(aA=bm\), the staircase has
  **no** full-support minimal excluded point. This includes the secondary
  class in Chomicz's terminology. Absence of an interior corner does not
  force at most six final-window points.
- The secondary class has an exact description in terms of two matching
  quotients of two-generated semigroups, with additional membership
  implications stated in `round2/type/secondary_structure_report.md`.
  This does not yet give the conductor/genus estimate needed for Wilf.

## Failed closing arguments, with concrete certificates

1. **A stronger continuous gap of \(1/3\) is false.** The finite lower ideal
   \[
   T=\{(x,y,z)\in\mathbb N^3:x+y,x+z,y+z\le45,
                         \min(x,y,z)\le5\}
   \]
   has one interior corner \((6,6,6)\). Its normalized rectangular
   thickening has
   \(\kappa_c=84021/262721<1/3\). This disproves that auxiliary
   geometric claim; it is not a numerical-semigroup counterexample.
2. **Uniform inflation does not propagate a counterexample.** Keeping one
   generator \(a\) and multiplying the other three by \(q\), with
   \(\gcd(a,q)=1\), gives
   \[
   W'=qW+(q-1)(a-1).
   \]
   This moves the Wilf number upward. The exact analysis also excludes
   amplification through repeated such lifts while changing the retained
   generator. An individual four-generator counterexample would disprove
   the overall conjecture, but it would not automatically disprove every
   larger embedding-dimension case.
3. **The forest overlap certificate is not universal.** For
   \(S=\langle175,185,201,202\rangle\), the tested sufficient forest
   certificate is \(-9\), while the actual Wilf number is \(862\).
   Thus that certificate cannot close all remaining cases.
4. **Secondary does not imply small final window.**
   \(\langle1558,1599,1675,2546\rangle\) is secondary and has 12
   final-window points, conductor 62204, \(n=27157\), and \(W_4=46424\).
   It also disproves using the new no-interior theorem to infer the
   six-point hypothesis.

These failures are preserved so that later work does not silently reinstate
an invalid lemma.

## Exact computations and their scope

A complete finite classification covered all 4,095 lower ideals strictly
between the degree-three and degree-four coordinate-face staircases.
Seven fail the ordered geometric relaxation; residue arguments exclude all
seven. Each LP value was checked with rational primal and dual certificates.
This is a complete result for the specified family, not for all staircases.

A separate seeded diagnostic produced 91,122 minimally four-generated
semigroups and 65,012 distinct Apéry shapes at multiplicities 20 through
1,000. None failed the ordered geometric sufficient bound. The random and
targeted diagnostics are evidence for further conjectures, not proof
dependencies of Parts I or II. The archive identifies exhaustive runs and
nonexhaustive searches separately in their individual reports.

## Relation to primary literature

- A. Zhai, *An asymptotic result concerning a question of Wilf*,
  [arXiv:1111.2779](https://arxiv.org/abs/1111.2779). Lemma 3 is the
  weighted lower-ideal inequality underlying the line identity. Theorem 2
  establishes an approximate lower density bound \(n/c>1/e-\varepsilon\)
  outside a finite set, for fixed \(e\) and fixed \(\varepsilon>0\).
  That statement allows infinitely many violations tending to \(1/e\);
  it does not itself establish the finite-counterexample conclusion of
  Part I.
- M. Hellus, A. Rechenauer and R. Waldi, *Variants on a question of Wilf*,
  [arXiv:1804.06141](https://arxiv.org/abs/1804.06141), Proposition 2.6.
  The full-support corner restriction is established background; the short
  residue proof is restated in Part I.
- W. Bruns, P. A. García-Sánchez, C. O'Neill and D. Wilburne,
  [arXiv:1903.04342](https://arxiv.org/abs/1903.04342), and J. Kliem and
  C. Stump, *A new face iterator for polyhedra and more general finite locally
  branched lattices*,
  [arXiv:1905.01945](https://arxiv.org/abs/1905.01945), supply the published
  small-multiplicity verification through 19 used above.
- K. Chomicz, *The type and cardinality of minimal presentations of numerical
  semigroups with embedding dimension four*,
  [arXiv:2609.04000v1](https://arxiv.org/html/2609.04000v1), provides the
  primary/secondary classification used in the supplementary structural
  investigation. It does not settle Wilf in embedding dimension four.

A targeted primary-source comparison found no matching fixed-embedding-
dimension finiteness theorem. That search does not establish novelty; the
proofs and their correctness are the claims being presented for review.
'''


def section(path, drop_title=False):
    text = (ROOT / path).read_text()
    return text.split('\n', 1)[1].lstrip() if drop_title else text


def main():
    assert (100003)**3 < 6 * (2 * 10**14)
    general = section('round2/amplification/general_dimension.md', True)
    general = general.replace("the root agent's difference-set exclusion", "the difference-set exclusion")
    general = general.replace('This argument was supplied by the root agent and independently checked here.',
                              'The following argument was independently checked during this continuation.')
    # Its numbering is local to Part I. The four-generator cutoff in Part II
    # supersedes the deliberately coarse d=3 specialization of B_d.
    continuous = section('round2/sharp_stability/continuous_gap_1e4.md')
    phase = section('round2/sharp_stability/phase_improvement.md')
    phase = phase.split('## A false continuous strengthening')[0]
    corner = section('round2/arithmetic/interior_corner_111.md', True)
    critical = section('round2/type/secondary_structure_report.md')
    critical = critical[critical.index('## 1. Pure critical pairs'):]
    critical = critical.split('## 2. Exact characterization')[0]
    text = (INTRO + general + '\n---\n\n'
            '# Part II. Four generators: the cutoff 2 × 10¹⁴\n\n'
            + continuous + '\n' + phase + SUMMED
            + '\n---\n\n# Part III. The interior-corner (1,1,1) class\n\n'
            + corner + '\n## A second generator-based class\n\n' + critical
            + '\nIn particular, if a nonmultiplicity minimal generator A satisfies '
              'm | 2A, its first critical exponent is exactly two: A itself is '
              'not representable by the other generators, while 2A is a '
              'multiple of m. The exponent-two corollary therefore applies.\n'
            + '\nThe slab theorem used here is included in the archive as '
              '`boundary/slab_theorem.md`.\n'
            + REMAINING)
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text(text)
    print(f'{OUT}: {len(text.encode())} bytes, {len(text.split())} words')


if __name__ == '__main__':
    main()
