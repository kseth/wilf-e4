# Verification package: Wilf, embedding dimension four

This package proves the finite part of the partial theorem:

> A minimally four-generated numerical semigroup satisfies Wilf's inequality if its Apéry set has at most five elements in `[c,c+m)`.

It does **not** prove or disprove Wilf's conjecture for unrestricted embedding dimension four. Read `wilf_edim4_progress_2026-09-05.md` for the analytic reductions, assumptions, and remaining gap.

Requirements: Python 3. No third-party Python packages are required.

Run:

```bash
python verify_final_window.py
```

This regenerates the finite classification from scratch, checks every residue-bijective exception at every cut, asserts the theorem's finite claims, and writes `verification-results.json`. The retained `verification-run.log` and JSON were generated on 5 September 2026.

Optional identity diagnostics:

```bash
python wilf_work.py --random 3000
```

The random checks are implementation diagnostics, not a proof of the general conjecture.

The two C++ sources are alternate implementations used during cross-checking. `enumerate_compressed.cpp` accepts the number of antichain points as its first argument and emits the negative compressed shapes as JSON. `check_residue_labels.cpp` takes a number of ideals, then for each ideal its cardinality and that many integer triples; it emits all bijective residue labelings. The latter is for cardinalities at most 64, and was used here only up to 38.

`negative_compressed_6.json` is a diagnostic dataset beyond the proved theorem. Its presence does not imply that six-point final windows have been settled.
