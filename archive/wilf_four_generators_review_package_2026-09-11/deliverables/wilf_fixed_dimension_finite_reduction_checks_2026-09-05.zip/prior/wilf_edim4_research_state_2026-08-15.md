---
title: "Wilf's Conjecture in Embedding Dimension Four"
subtitle: "Comprehensive Research State, Verification Ledger, Failed Routes, and Current Handoff"
author: "Research synthesis for Karthik Sethuraman"
date: "15 August 2026"
lang: en-US
---

> **Current outcome.** We do not yet have a proof or a counterexample to Wilf's conjecture in embedding dimension four. We do have exact reductions from Wilf to a three-dimensional Apéry-staircase boundary inequality, several additional project theorems and infinite subcases, substantial exact finite evidence, a large catalog of explicit counterexamples to overstrong intermediate statements, and a sharply localized remaining theorem involving the maximal Apéry elements in the final interval of length $m$.

> **Primary current target.** With the notation developed below, the remaining line-based theorem is
> $$
> \Delta_Z\le B_{\mathrm{off}}+\sum_{\ell\in\mathscr D}s_\ell.
> $$
> Through an exact identity, this is equivalent to $W(S)\ge0$. The cases $|Z|=1$ and $|Z|=2$ are proved. The unresolved regime has $|Z|\ge3$.

# Contents

1. Purpose, scope, and status discipline  
2. Executive summary  
3. Problem statement, notation, and current literature status  
4. Exact Apéry-staircase and coordinate-boundary reductions  
5. Translation permutations, carries, and the strong modular route  
6. The minimal exact reflection-carry identity  
7. Final-window localization and the current open theorem  
8. Project theorems and closed subfamilies  
9. Conflict-graph and polyhedral program  
10. Weight-one planar program  
11. Erosion, coheight, and shape program  
12. Computational evidence and reproducibility ledger  
13. Failed routes and explicit obstructions  
14. Current unknowns and recommended next proof program  
15. Related work and how it enters this project  
16. Project artifacts and cold-start instructions  
Appendices: notation, claim ledger, explicit witnesses, and verification commands

# 1. Purpose, scope, and status discipline

This document is a self-contained handoff for continued work on Wilf's conjecture in embedding dimension four. It consolidates:

- the original offline-agent checkpoint dated 6 August 2026;
- the subsequent exact derivations and proof attempts in this research thread;
- the archived Markdown notes, scripts, and verification logs now present in `/mnt/data`;
- a literature refresh performed on 15 August 2026.

The original checkpoint's bottom line was explicit: no proof and no counterexample had been found, but the problem had been reduced to a three-dimensional Apéry-staircase boundary problem with substantial computational evidence. That remains the honest global outcome. The later work significantly sharpens the reduction and proves several new structural results, but does not yet close the full case.

## 1.1 Status labels used throughout

| Label | Meaning |
|---|---|
| **Published input** | A theorem or computation taken from the cited literature. Exact hypotheses must still be checked in the primary source before publication. |
| **Project theorem** | A proof derived in the project notes or this thread. It has not been peer reviewed; important claims should be independently audited before submission. |
| **Computer-assisted project theorem** | An analytic reduction plus a finite exhaustive verification in a fully specified finite range. |
| **Finite computation** | Exact or randomized evidence in a stated range; never an infinite proof. |
| **Conjecture / open lemma** | A statement supported by evidence but not proved. |
| **Failed route** | A strengthening or proof mechanism refuted by an explicit example, or proved too weak to imply the target. |
| **Provisional dialogue result** | An argument given during the thread but not yet written as a standalone archived note or independently audited. |

## 1.2 Notation warning

Embedding dimension is denoted by $e$. After separating the multiplicity, an $e$-generated semigroup is represented by a lower ideal in dimension $d=e-1$. Thus the target case is

$$
e=4,\qquad d=3.
$$

The phrase "dimension four" in informal discussion means embedding dimension four, not a four-dimensional staircase.

# 2. Executive summary

## 2.1 The exact foundational chain

Let

$$
S=\langle m,a_1,a_2,a_3\rangle
$$

be minimally four-generated. Choose one preferred factorization of every element of $\operatorname{Ap}(S,m)$ using $a_1,a_2,a_3$, with a multiplicative monomial-order tie-break. The exponent vectors form a finite lower ideal

$$
T\subseteq\mathbb N^3,\qquad |T|=m.
$$

Define the actual label

$$
w(x)=a_1x_1+a_2x_2+a_3x_3,
$$

and put

$$
M=\max_{x\in T}w(x),\qquad \Sigma=\sum_{x\in T}w(x).
$$

The first exact identity is

$$
\boxed{mW=m(3M-m+1)-4\Sigma.}
$$

Define the coordinate-boundary deficit

$$
D=3mM-4\Sigma.
$$

Then

$$
\boxed{D=mW+m(m-1).}
$$

Therefore

$$
\boxed{W\ge0\iff D\ge m(m-1).}
$$

This equivalence is the nonnegotiable foundation. Every successful proof architecture must establish the missing modular boundary slack $m(m-1)$.

## 2.2 The stronger modular route

Write $A_j\equiv a_j\pmod m$, with $1\le A_j<m$, and define

$$
K=\sum_{x\in T}\lfloor\frac{A\cdot x}{m}\rfloor.
$$

For a cyclic cut $f$, define the cut load $\mathcal H_f$ from the three coordinate sawtooth functions. The exact modular identity is

$$
\boxed{R_f=m(m-1)+m(\mathcal H_f-K).}
$$

Thus the all-cuts inequality

$$
\mathcal H_f\ge K
$$

would prove Wilf, but it is stronger than needed. It remains unproved and has extensive finite evidence.

## 2.3 The minimal exact semigroup route

Later work returned to the actual, unreduced Apéry labels. Let

$$
q(x)=\lfloor\frac{w(x)}m\rfloor,
\qquad
\ell(x)=\lfloor\frac{M-w(x)}m\rfloor.
$$

Reflect $x$ in each coordinate line and define the nonnegative reflection capacities $\gamma_j(x)$. Define the mixed-coordinate carry

$$
\lambda(x)=
\lfloor
\frac{[A_1x_1]_m+[A_2x_2]_m+[A_3x_3]_m}{m}
\rfloor,
\qquad
\Lambda=\sum_x\lambda(x).
$$

The exact identity is

$$
\boxed{W=\sum_{x\in T}\sum_{j=1}^3\gamma_j(x)-\Lambda.}
$$

This is not a strengthening: proving total reflection capacity at least total mixed-carry demand is exactly Wilf.

## 2.4 The strongest current localization

Regroup the reflection-carry identity coordinate line by coordinate line. For a coordinate line $\ell$, let $L_\ell$ be its length, $t_\ell$ its top, and write

$$
M-w(t_\ell)=mh_\ell+\beta_\ell,
\qquad 0\le\beta_\ell<m.
$$

Then

$$
\boxed{
 mW=\binom m2+
 \sum_{j=1}^3\sum_{\ell\parallel e_j}
 \left[mL_\ell h_\ell+mC_{A_j}(L_\ell,\beta_\ell)-R_{A_j}(L_\ell)\right].
}
$$

Every line with $h_\ell\ge1$ contributes at least

$$
m+\binom{L_\ell}{2}>0.
$$

Hence all possible negativity is localized to the maximal Apéry elements in the final window

$$
Z=\{t\in T:0\le M-w(t)<m\}.
$$

An exact regrouping gives

$$
\boxed{
 mW=B_{\mathrm{off}}+\sum_{\ell\in\mathscr D}s_\ell-\Delta_Z,
}
$$

where $B_{\mathrm{off}}\ge0$ is unused residue mass, all deep-line scores $s_\ell$ are strictly positive, and $\Delta_Z$ is a weighted repeated-axis-prefix debt among the points of $Z$.

The cases $|Z|=1$ and $|Z|=2$ are proved. The full case is now equivalent to

$$
\boxed{
\Delta_Z\le B_{\mathrm{off}}+\sum_{\ell\in\mathscr D}s_\ell
\qquad(|Z|\ge3).
}
$$

This is the current primary open theorem.

## 2.5 Overall assessment

The problem is conceptually much narrower than at the beginning: the unresolved obstruction is a weighted overlap phenomenon for at least three near-maximum, coordinatewise maximal Apéry points. However, the repeated failure of broader intermediate theorems shows that "one final lemma" can still contain the essential difficulty of Wilf's conjecture. The current reduction is exact and useful; the final weighted charging theorem is not yet known.

# 3. Problem statement, notation, and current literature status

## 3.1 Numerical-semigroup notation

A numerical semigroup is a cofinite additive submonoid $S\subseteq\mathbb N$. Write

| Symbol | Definition | Meaning |
|---|---|---|
| $m$ | smallest positive element of $S$ | multiplicity |
| $e$ | number of minimal generators | embedding dimension |
| $F$ | largest integer not in $S$ | Frobenius number |
| $c$ | $F+1$ | conductor |
| $g$ | number of nonnegative integers not in $S$ | genus |
| $L$ | elements of $S$ from $0$ up to the conductor | left elements; $n=|L|=c-g$ |
| $t$ | number of pseudo-Frobenius elements | type |

Wilf's conjecture is

$$
\boxed{en\ge c.}
$$

At $e=4$,

$$
W=4n-c=3c-4g,
$$

so the target is $4g\le3c$.

## 3.2 Apéry formulas

The Apéry set with respect to $m$ is

$$
\operatorname{Ap}(S,m)=\{w\in S:w-m\notin S\}.
$$

It has one element in every residue class modulo $m$. If

$$
M=\max\operatorname{Ap}(S,m),\qquad
\Sigma=\sum_{w\in\operatorname{Ap}(S,m)}w,
$$

then

$$
M=c+m-1,
\qquad
g=\frac\Sigma m-\frac{m-1}{2}.
$$

These formulas are the bridge from semigroup invariants to the three-dimensional staircase moments.

## 3.3 Literature status refreshed 15 August 2026

A targeted arXiv and primary-source refresh found no proof of Wilf's conjecture in embedding dimension four.

- Bacher's version 6, dated 5 August 2026, explicitly describes Wilf's conjecture as still open and lists the classical verified regimes, including $e\le3$, $c\le3m$, at most twelve left elements, and multiplicity at most nineteen [R1].
- Chomicz's April 2026 paper gives a general geometric procedure for computing Apéry sets of four-generated semigroups and applies it to specific families; it does not prove Wilf for all embedding-dimension-four semigroups [R2].
- Marashdeh's preprint submitted 12 August 2026 proves a new type bound and reduces Wilf to another inequality; it does not close the conjecture [R3].

This is a dated search statement, not a permanent guarantee. Any publication should repeat the search immediately before claiming novelty or open status.

## 3.4 Published exclusion region for a hypothetical counterexample

Combining the literature summarized in the original checkpoint, a counterexample at $e=4$ must satisfy at least the following conditions within the scope of the cited results.

| Necessary condition | Complementary case known to satisfy Wilf |
|---|---|
| $m\ge20$ | Multiplicity $m\le18$ is covered by Bruns et al.; multiplicity $19$ by Kliem--Stump [R4, R5]. |
| $c>3m$ | Eliahou's depth/conductor result covers $c\le3m$ [R6]. |
| $n\ge13$ | Semigroups with at most twelve left elements are covered [R7]. |
| $g\ge101$ | Wilf verified through genus $100$ [R8]. |
| largest primitive greater than 60 | Fixed-maximum-primitive verification through $60$ [R9]. |
| type $t\ge4$ | $c\le(t+1)n$ gives Wilf when $t\le3$ [R10]. |
| not nearly Gorenstein | Four-generated nearly Gorenstein semigroups have type at most three [R11]. |
| not generalized arithmetic sequence | Covered by Sammartano's class results [R12]. |
| negative Eliahou number | The Wilf number dominates the Eliahou number in the relevant decomposition [R6, R13]. |

The project also proved a new necessary arithmetic condition for a minimal-multiplicity counterexample: for every pair $i\ne j$,

$$
\boxed{\gcd(m,a_i,a_j)=1.}
$$

This follows from the cyclic-inflation descent theorem in Section 8.5.

# 4. Exact Apéry-staircase and coordinate-boundary reductions

## 4.1 Selected factorizations form a lower ideal

For each Apéry element, choose the least factorization by $a_1,a_2,a_3$ under a fixed multiplicative monomial order. The selected exponent vectors form a finite lower ideal

$$
T\subseteq\mathbb N^3,
\qquad |T|=m.
$$

The label map

$$
w(x)=a_1x_1+a_2x_2+a_3x_3
$$

is a bijection from $T$ to $\operatorname{Ap}(S,m)$. Its integer labels are distinct, and their residues are $0,1,\ldots,m-1$.

The lower-ideal property follows from Apéry minimality and the multiplicative tie-break: if $y\le x\in T$ were not selected in the expected way, replacing the factorization of $y$ inside that of $x$ would contradict the selected factorization of $x$.

## 4.2 Exact moment equation

Using the Apéry formulas,

$$
\boxed{mW=m(3M-m+1)-4\Sigma.}
$$

Equivalently,

$$
\boxed{4\Sigma\le m(3M-m+1)}
$$

is exactly Wilf for $e=4$.

## 4.3 Exact coordinate-boundary identity

Partition $T$ into lines parallel to each coordinate direction. A line $\ell$ parallel to $e_j$ has length $L$, base coordinate $0$, and top $t_\ell$. The labels form an arithmetic progression, so

$$
Lw(t_\ell)=\sum_{x\in\ell}w(x)+a_j\binom L2.
$$

Define

$$
D_j=\sum_{\ell\parallel e_j}L\bigl(M-w(t_\ell)\bigr).
$$

Summing over lines and then coordinates gives

$$
\boxed{
D=\sum_{j=1}^3D_j=3mM-4\Sigma.
}
$$

Combining with the moment equation yields

$$
\boxed{D=mW+m(m-1).}
$$

Every term in $D$ is nonnegative, which recovers the generic weighted-lower-ideal bound $4\Sigma\le3mM$. Wilf requires the additional modular correction $m(m-1)$.

## 4.4 Translation permutations and top-to-base carries

Because the labels form a complete residue system, each coordinate induces a permutation $T_j:T\to T$ satisfying

$$
w(T_jx)\equiv w(x)+a_j\pmod m.
$$

At an interior point, $T_jx=x+e_j$. At a line top, $T_j$ wraps to the base of another line. If $\sigma_j(\ell)$ is the next base, define

$$
\kappa_\ell=
\frac{w(t_\ell)+a_j-w(\sigma_j(\ell))}{m}.
$$

Apéry minimality implies $\kappa_\ell\ge0$. The carries telescope:

$$
\boxed{\sum_{\ell\parallel e_j}\kappa_\ell=a_j.}
$$

More precisely, on every translation cycle, the line lengths sum to $m/\gcd(a_j,m)$ and the carries sum to $a_j/\gcd(a_j,m)$. This simultaneous three-direction structure is a likely source of the final weighted charging theorem.

## 4.5 Positive polynomial factorization

Let

$$
\mathcal A(z)=\sum_{x\in T}z^{w(x)},
\qquad
[m]_z=1+z+\cdots+z^{m-1}.
$$

Residue completeness gives

$$
\mathcal A(z)=[m]_zP_S(z),
$$

where $P_S$ is the semigroup polynomial. Linewise telescoping yields

$$
[a_j]_zP_S(z)=
\sum_{\ell\parallel e_j}
 z^{w(\sigma_j(\ell))}
 \left(1+z^m+\cdots+z^{m(\kappa_\ell-1)}\right).
$$

Differentiation at $z=1$ gives a positive carry identity. Used one coordinate at a time, however, this route gives only

$$
4g\le3c+a_j-1,
$$

which is short of Wilf by $a_j-1$. No valid three-coordinate cancellation has yet been extracted.

# 5. Translation permutations, carries, and the strong modular route

## 5.1 Modular lower ideals

Temporarily forget Apéry minimality. Let $T\subseteq\mathbb N^3$ be a full-dimensional lower ideal of size $m$, and let $1\le A_j<m$ be such that

$$
\phi(x)=A\cdot x\pmod m
$$

is a bijection onto $\mathbb Z/m\mathbb Z$.

For a cut $f$, define the least-residue height

$$
h_f(x)=[f-A\cdot x]_m
$$

and the least-residue boundary sum

$$
R_f=\sum_{x\in T}\sum_{j=1}^3h_f(p_jx),
$$

where $p_jx$ is the top of the $j$-line through $x$.

The modular boundary conjecture is

$$
R_f\ge m(m-1)
$$

for every $f$. For a genuine Apéry staircase at $f\equiv M\pmod m$, the actual boundary dominates $R_f$, so this conjecture implies Wilf. It is stronger than Wilf and may remain true even beyond Apéry-minimal staircases.

## 5.2 Exact cyclic reduction

Let $u_j(r)$ be the $j$th coordinate of the unique point of residue $r$. Define

$$
\mathcal H_f=\sum_{j=1}^3\sum_{s=1}^{A_j}u_j(f+s)
$$

cyclically, and

$$
K=\sum_{x\in T}\lfloor\frac{A\cdot x}{m}\rfloor.
$$

A linewise summation-by-parts calculation gives

$$
\boxed{R_f=m(m-1)+m(\mathcal H_f-K).}
$$

Thus the strong modular conjecture is exactly

$$
\boxed{\mathcal H_f\ge K.}
$$

Only the cut corresponding to $M$ is needed for Wilf, but all tested modular ideals satisfy the stronger all-cuts assertion.

## 5.3 Sawtooth recurrence

Let $c_j(r)$ be the weighted indicator that the residue-$r$ point is a $j$-line top, and put $C(r)=\sum_jc_j(r)$. Then

$$
c_j(r)=1+u_j(r)-u_j(r+A_j).
$$

Writing $G_f=\mathcal H_f-K$ gives

$$
G_f-G_{f-1}=3-C(f),
\qquad
\sum_fG_f=\binom m2.
$$

Arbitrary nonnegative loads $C$ with total $3m$ can produce negative antiderivatives. A proof must use the compatibility of all three sawtooth sequences with one common lower ideal.

## 5.4 Circular arcs, residual intervals, and a corrected covering interpretation

Each coordinate contribution can be represented by cyclic intervals. The original checkpoint suggested partitioning the original arc multiset into $K$ complete covers. That interpretation is false.

A genuine counterexample to the partition statement is

$$
S=\langle7,13,44,50\rangle,
\qquad A=(1,6,2),
$$

with staircase

$$
T=\{0,e_1,e_3,e_2,2e_2,3e_2,4e_2\}.
$$

Here $K=6$ and

$$
\mathcal H=(12,11,10,6,7,8,9),
\qquad
G=(6,5,4,0,1,2,3).
$$

The inequality holds, but the original arcs cannot be partitioned into six full covers.

The corrected residual-interval decomposition removes complete turns within coordinate-line suffixes. It produces an exact identity

$$
\mathcal H_f-K=d_f(\mathscr J)-\Lambda_{
m mixed},
$$

where $\mathscr J$ is a structured family of residual top intervals and $\Lambda_{\mathrm{mixed}}$ is the mixed-coordinate carry count. This remains a useful conceptual model, but the universal residual matching theorem is unproved.

## 5.5 A small rigorous subcase

A discussion-stage argument proves the strong cyclic inequality when $K\le1$. Define

$$
z_f(x)=\lceil\frac{A\cdot x-f}{m}\rceil.
$$

If $\mathcal H_f=0$, the nonnegative edge increments of $z_f$ vanish on every cover edge, so $z_f$ is constant on the connected lower ideal and equals zero at the origin. Hence every quotient $\lfloor A\cdot x/m\rfloor$ is zero, so $K=0$. Therefore $K\ge1$ implies $\mathcal H_f\ge1$, and $K\le1$ implies $\mathcal H_f\ge K$.

This proof should be moved into a standalone note before external use.

# 6. The minimal exact reflection-carry identity

The strong modular conjecture is attractive but unnecessarily strong. The actual semigroup labels retain extra multiples of $m$ that can pay a negative least-residue slack.

## 6.1 Quotients and left-element capacity

For $x\in T$, define

$$
q(x)=\lfloor\frac{w(x)}m\rfloor,
\qquad
\ell(x)=\lfloor\frac{M-w(x)}m\rfloor.
$$

Then

$$
g=\sum_xq(x),
\qquad
n=\sum_x\ell(x),
\qquad
W=3n-g.
$$

Write

$$
q_j(x)=\lfloor\frac{a_jx_j}{m}\rfloor,
\qquad
\alpha_j(x)=[A_jx_j]_m.
$$

The mixed carry is

$$
\lambda(x)=
\lfloor
\frac{\alpha_1(x)+\alpha_2(x)+\alpha_3(x)}m
\rfloor,
$$

and

$$
q(x)=q_1(x)+q_2(x)+q_3(x)+\lambda(x).
$$

Let

$$
Q=\sum_{x,j}q_j(x),
\qquad
\Lambda=\sum_x\lambda(x).
$$

Then

$$
\boxed{g=Q+\Lambda.}
$$

## 6.2 Reflection capacity

Let $\rho_j(x)$ be reflection of $x$ in its coordinate-$j$ line. Define

$$
\gamma_j(x)=\ell(\rho_jx)-q_j(x).
$$

If $p_jx$ is the line top, then

$$
w(\rho_jx)=w(p_jx)-a_jx_j,
$$

so $\gamma_j(x)\ge0$.

Since each $\rho_j$ is a permutation of $T$,

$$
\sum_{x,j}\gamma_j(x)=3n-Q.
$$

Combining with $W=3n-g$ and $g=Q+\Lambda$ gives the exact identity

$$
\boxed{
W=\sum_{x\in T}\sum_{j=1}^3\gamma_j(x)-\Lambda.
}
$$

This is the minimal sufficient chain: Wilf is exactly total reflection capacity at least total mixed-carry demand. A pointwise inequality is false; redistribution must be global.

## 6.3 Coheight-corrected cyclic criterion

A separate exact lower bound is useful. Let $u$ be the maximum-label point, $f=A\cdot u\pmod m$, and let $C(x)$ be the coordinate-top load. Let

$$
h(x)=\max_{v\ge x,\ v\text{ maximal}}|v-x|_1,
\qquad
H(T)=\sum_xC(x)h(x).
$$

Then

$$
M-w(x)\ge[f-A\cdot x]_m+mh(x).
$$

Summing gives

$$
D\ge m(m-1)+m(H(T)+G_f),
$$

where $G_f=\mathcal H_f-K$. Therefore it is enough to prove

$$
G_f\ge-H(T).
$$

Since linewise winding yields $G_f\ge-\Lambda$, the mixed-carry inequality $\Lambda\le H(T)$ is sufficient. This is weaker than the all-cuts modular conjecture.

# 7. Final-window localization and the current open theorem

This section records the strongest current endpoint.

## 7.1 Exact coordinate-line score

For a coordinate-$j$ line $\ell$, write

$$
M-w(t_\ell)=mh_\ell+\beta_\ell,
\qquad 0\le\beta_\ell<m.
$$

Define

$$
R_A(L)=\sum_{k=0}^{L-1}[kA]_m
$$

and

$$
C_A(L,\beta)=
|\{0\le k<L:[kA]_m+\beta\ge m\}|.
$$

Then

$$
\boxed{
 mW=\binom m2+
 \sum_{j=1}^3\sum_{\ell\parallel e_j}
 \bigl[mL_\ell h_\ell+mC_{A_j}(L_\ell,\beta_\ell)-R_{A_j}(L_\ell)\bigr].
}
$$

The formula follows by summing reflection capacity on each line and using residue completeness to express $m\Lambda$ through the coordinate marginals.

## 7.2 Deep lines are strictly profitable

The residues $0,A_j,\ldots,(L_\ell-1)A_j$ are distinct because the corresponding axis points belong to $T$. Hence

$$
R_{A_j}(L_\ell)\le
\frac{(L_\ell-1)(2m-L_\ell)}2.
$$

If $h_\ell\ge1$, the line score is at least

$$
\boxed{m+\binom{L_\ell}{2}>0.}
$$

Define

$$
Z=\{t\in T:0\le M-w(t)<m\}.
$$

Every line that can contribute negatively has its top in $Z$, and every $t\in Z$ is coordinatewise maximal.

## 7.3 Exact repeated-axis formula

For $t\in Z$, put $\beta_t=M-w(t)$. For direction $j$ and level $k\ge1$, define

$$
r_{j,k}=[kA_j]_m,
$$

$$
z_{j,k}=|\{t\in Z:t_j\ge k\}|,
$$

and

$$
c_{j,k}=|\{t\in Z:t_j\ge k,\ \beta_t+r_{j,k}\ge m\}|.
$$

The nonzero axis-prefix residues $r_{j,k}$ are pairwise distinct across all directions and levels that occur. Let $B_{\mathrm{off}}$ be the sum of nonzero residues not used by any such axis prefix. Let $\mathscr D$ be the coordinate lines whose tops lie outside $Z$, and let $s_\ell$ be their exact positive scores.

Then

$$
\boxed{
 mW=B_{\mathrm{off}}+\sum_{\ell\in\mathscr D}s_\ell-\Delta_Z,
}
$$

where

$$
\boxed{
\Delta_Z=
\sum_{j=1}^3\sum_{k\ge1}
\bigl[(z_{j,k}-1)r_{j,k}-mc_{j,k}\bigr].
}
$$

Interpretation:

- the universal $\binom m2$ pays one copy of every used axis-prefix residue;
- $(z_{j,k}-1)r_{j,k}$ is the debt from repeated copies shared by several points of $Z$;
- $mc_{j,k}$ records residual wrap crossings that compensate the repetitions;
- $B_{\mathrm{off}}$ is unused residue budget;
- all lines outside the final window contribute positive margin.

## 7.4 Closed cases

Define the repeated-prefix count

$$
E_Z=\sum_{j,k}\max\{z_{j,k}-1,0\}
=\sum_{t\in Z}|t|_1-\sum_{j=1}^3\max_{t\in Z}t_j.
$$

Let $D_Z$ be the number of deep lines. Since $\Delta_Z\le(m-1)E_Z$ and every deep line contributes at least $m$,

$$
E_Z\le D_Z\quad\Longrightarrow\quad W\ge0.
$$

If $|Z|=1$, there are no repetitions, so Wilf holds.

If $|Z|=2$, a projection-union argument for the two incomparable maximal boxes proves

$$
D_Z\ge E_Z+1.
$$

Therefore

$$
\boxed{|Z|\le2\Longrightarrow W\ge0,}
$$

with strict positivity in the two-point case.

## 7.5 Exact remaining theorem

The unresolved line-based theorem is

$$
\boxed{
\Delta_Z\le B_{\mathrm{off}}+\sum_{\ell\in\mathscr D}s_\ell
\qquad(|Z|\ge3).
}
$$

Through the exact identity above, this is equivalent to $W\ge0$ in the remaining regime.

A surviving counterexample would need:

- at least three maximal Apéry elements strictly above $M-m$ and at most $M$;
- heavy overlap among their three families of axis prefixes;
- more repeated prefix incidences than deep lines;
- few residual crossings $c_{j,k}$;
- little unused residue mass outside the axis-prefix residues;
- unusually short or sparse deep lines despite the large overlapping maximal boxes.

The likely missing mechanism is a weighted charging theorem using the coordinate translation cycles: every repeated axis-prefix debt should force either a deep line or a wrap crossing, with controlled multiplicity. No valid global rule has yet been found.

# 8. Project theorems and closed subfamilies

## 8.1 Rectangular staircases

For a box

$$
T=I_1\times I_2\times I_3,\qquad |I_j|=n_j,
$$

reflection pairs labels to $M$, so $\Sigma=mM/2$. The desired centroid inequality follows, with equality only when $M=m-1$.

## 8.2 Almost-symmetric semigroups at $e=4$

Using Nari's Apéry pairing and Moscariello's type bound $t\le3$, the project proves the complete sorted-Apéry outer-prefix chain for every almost-symmetric four-generated semigroup. This includes Wilf as the final step. The deduction is new to the project but rests on published inputs [R14, R15].

## 8.3 Double-staircase family

For $s\ge2$ and $h\ge1$, define

$$
S_{s,h}=\langle s^2,\ hs^2+1,\ hs^2+s,\ hs^2+s+1\rangle.
$$

The project proves the exact Apéry staircase and computes

$$
c=hs^2(s-1),
$$

$$
g=\frac{hs(s-1)(4s+1)}6,
$$

$$
n=\frac{hs(s-1)(2s-1)}6,
$$

$$
W=\frac{hs(s-1)(s-2)}3\ge0.
$$

Equality occurs exactly at $s=2$.

## 8.4 One-partial-layer theorem

For lower ideals

$$
T=\Delta_{d-1}\cup U,
\qquad U\subseteq\{x:|x|_1=d\},
$$

a weighted-shadow analysis plus exact finite verification in degrees $d\le4$ and an analytic argument for $d\ge5$ proves the relevant erosion/coheight inequality. The retained verifier checks $33{,}864$ top-layer subsets. This is a computer-assisted project theorem, not a proof of the full modular case.

## 8.5 Cyclic-inflation descent

Let

$$
S'=\langle n,a,b_2,\ldots,b_{e-1}\rangle,
$$

$$
S=\langle qn,a,qb_2,\ldots,qb_{e-1}\rangle,
\qquad \gcd(a,q)=1.
$$

The project proves the exact product formula

$$
\operatorname{Ap}(S,qn)=
\bigsqcup_{i=0}^{q-1}
\bigl(ia+q\operatorname{Ap}(S',n)\bigr).
$$

Consequently

$$
W_4(S)=qW_4(S')+(q-1)(a-1).
$$

This settles every quotient in which only one nonmultiplicity generator remains active. A minimal-multiplicity counterexample must satisfy

$$
\gcd(m,a_i,a_j)=1\qquad(i\ne j).
$$

The retained script reverified three fixed examples and 250 seeded random inflation instances during this synthesis.

## 8.6 Final-window size at most two

The final-window line reduction proves the new infinite class

$$
|Z|\le2\quad\Longrightarrow\quad W\ge0.
$$

This is currently the newest closed semigroup class in the primary proof route.

# 9. Conflict-graph and polyhedral program

This program studies the stronger modular inequality $G_f=\mathcal H_f-K\ge0$.

## 9.1 Exact stable-transversal model

For a candidate point $p$, let $B(p)$ be its principal box. A point is admissible when the residue map is injective on $B(p)$. Define a conflict graph whose vertices are admissible points and whose edges join points whose two principal boxes disagree on a shared residue.

**Project theorem.** Modular lower ideals are exactly stable sets meeting each residue class exactly once. Thus the conflict graph describes the exact integer hull after intersecting the stable-set polytope with the residue equations.

A useful corollary is that all clique inequalities, together with the residue equations, already imply downward closure.

## 9.2 Rational points and graph coloring

For a rational clique-feasible point, clear denominators and blow up every candidate into a clique of twins. The point is an average of modular lower ideals if and only if the blow-up graph is colorable with the denominator number of colors.

This converts fractional nonintegrality into a graph-coloring obstruction.

## 9.3 Half-integral dichotomy

Every $\{0,1/2,1\}$-valued feasible point is either:

1. the average of two actual modular lower ideals, if its half-support conflict graph is bipartite; or
2. cut off by an odd-cycle inequality.

This completely explains the first negative relaxation at

$$
m=17,\quad A=(1,8,11),\quad f=14,
$$

whose LP optimum is $-1/2$ and integer optimum is $0$.

A single explicit conflict triangle raises the LP optimum to zero.

## 9.4 Exact scaling of the fractional obstruction

The $m=17$ obstruction scales to

$$
m=17q,\qquad A=(1,8q,11q),\qquad f=15q-1,
$$

with raw LP optimum $-q/2$ and integer optimum $0$. The same lifted triangle removes the entire gap. Hence the raw LP has an unbounded integrality gap and cannot support a universal bound such as LP optimum greater than $-1$.

## 9.5 Higher denominators

The full clique relaxation is not half-integral. Genuine thirds vertices occur at $m=14$ and $m=17$. They satisfy all odd-cycle inequalities but violate rank-two stable-set inequalities. Thus:

- triangles do not describe the integer hull;
- cliques plus odd cycles do not describe the integer hull;
- the general stable-set polytope is more complicated than the Wilf objective appears to require.

Nevertheless, every negative Wilf relaxation in the retained targeted test set becomes nonnegative after a small number of conflict-clique cuts. One instance at $m=46$ moves directly to the exact integer optimum $2$.

## 9.6 Status of this route

The attractive conjecture is objective-specific: the Wilf coefficient vector may lie in the dual cone generated by residue equations and conflict cliques even though the full polytope is nonintegral. This remains unproved. It is a viable secondary route because it has exact dual certificates and infinite certificate-lifting families, but it presently asks for a stronger modular theorem than the final-window semigroup route.

# 10. Weight-one planar program

Assume one reduced weight is one:

$$
A=(1,a,b).
$$

Write the staircase as vertical columns

$$
T=\{(k,y,z):0\le k<\ell(y,z)\}.
$$

## 10.1 Column interval tiling

Each column occupies the residue interval

$$
[ay+bz]_m,\ [ay+bz]_m+1,\ldots,[ay+bz]_m+\ell(y,z)-1.
$$

These nonwrapping intervals partition all $m$ residue classes. This converts the three-dimensional residue condition into a planar plane-partition tiling.

## 10.2 Concavity and block boundaries

The cyclic slack $G_f$ is discretely concave inside every vertical residue block. Hence its minimum occurs at a block boundary.

## 10.3 Exact binary carry factorization

At the origin boundary, the floor sum splits into pure one-dimensional parts, each nonnegative by floor superadditivity, plus a binary two-coordinate carry

$$
\varepsilon(y,z)=
\lfloor\frac{[ay]_m+[bz]_m}{m}\rfloor.
$$

For every Ferrers slice, an exact identity expresses the slack as

$$
\text{row-end inversions}+\text{column-end inversions}-\text{mixed carries}.
$$

The same holds at every column-boundary cut.

## 10.4 Proved harmless regimes

- slices with at most two rows or at most two columns;
- all vertical levels above the bottom quarter, because four disjoint columns would otherwise exceed total size $m$.

## 10.5 Open weight-one theorem

The remaining statement is a capacitated Hall matching between mixed-carry tokens and row/column inversion tokens. It remains unproved. This route is more specialized than the current final-window theorem but may offer a tractable laboratory for the needed global charging mechanism.

# 11. Erosion, coheight, and shape program

## 11.1 Residue-depth lower bound

For the maximum-label point $u$, define the linear residue distance

$$
\rho(x)=[A\cdot(u-x)]_m.
$$

A pointwise estimate gives

$$
M-w(x)\ge\rho(x)+mh(x).
$$

After weighting by the coordinate-top load $C(x)$,

$$
D\ge mH(T)+\sum_xC(x)\rho(x).
$$

Replacing the actual linear residue permutation by the unrestricted rearrangement minimum gives

$$
D\ge mH(T)+R_C(T).
$$

This is useful but can be too weak because not every permutation of the residues is realizable by one linear form.

## 11.2 Erosion hierarchy

Let

$$
\Delta_p=\{z\in\mathbb N^3:|z|_1\le p\},
$$

$$
E_p(T)=\{y:y+\Delta_p\subseteq T\}.
$$

Residue completeness implies

$$
|\Delta_p-E_p(T)|\le m
$$

for every $p\ge1$. These are exact necessary shape conditions.

## 11.3 First erosion is insufficient

The 80-point shape

$$
T=\Delta_5\cup\{(x,y,0):6\le x+y\le8\}
$$

satisfies the first erosion with equality but violates the proposed coheight/rearrangement bound. The second erosion excludes it. Hence any erosion-only proof must be multiscale.

## 11.4 Full erosion hierarchy is still insufficient without linear residue structure

The 68-point lower ideal

$$
T_{\mathrm{bad}}=\Delta_4\cup
\{x:|x|_1\in\{5,6\},\ x_1x_2x_3=0\}
$$

satisfies every erosion inequality but has

$$
68H(T_{\mathrm{bad}})+R_C(T_{\mathrm{bad}})=4467<4488=68(68-2).
$$

It cannot admit a residue-bijective linear labeling modulo $68$; parity already gives the obstruction. This explicitly refutes the pure shape-only stability theorem and shows that quotient/Fourier balance is essential.

## 11.5 Status of this route

The one-partial-layer class is closed, and the erosion formulas remain useful diagnostics. The full shape-only architecture is not viable. Any revival must retain the actual linear residue classes, for example through divisor-level balanced rearrangement or Fourier constraints. The final-window line route already retains that arithmetic more directly and is currently preferable.

# 12. Computational evidence and reproducibility ledger

No finite computation proves the conjecture. The value of the computations is to validate identities, expose equality and near-equality structures, and refute proposed intermediate lemmas quickly.

## 12.1 Original semigroup search ledger

The original checkpoint reports:

| Search domain | Reported result |
|---|---|
| $19\le m\le40$, other proposed generators $\le3m$ | 817,916 proposed sets; 644,256 minimally four-generated semigroups; no negative Wilf number. Reproducible from the original repository. |
| largest generator $\le200$ | 40,256,202 exact $e=4$ semigroups; no counterexample. Historical driver not retained in the uploaded files. |
| largest generator $\le100$ | 1,954,692 exact $e=4$ semigroups; no sorted-prefix failure. Historical driver not retained. |
| random minimal quadruples, $m\le1000$ | 1,290,021 samples; no sorted-prefix failure. Seed/driver not retained. |
| semigroup tree through genus 30 | 7,438 $e=4$ semigroups; agreement with bounded enumeration. Historical driver not retained. |

## 12.2 Original modular-lower-ideal ledger

| Search domain | Reported result |
|---|---|
| full-dimensional $d=3$, $m\le12$, weights $\le30$ | 429,882 ideal/weight cases; no prefix, centroid, or modular-boundary failure. |
| non-Apéry-minimal transversals in that box | 351,330; no failure. |
| deduplicated reduced structures, weights $\le15$, every cut | 15,912 structures; no $\mathcal H_f-K<0$. |
| random full-dimensional ideals, $m\le24$, weights up to $10^9$ | 10,000 samples; no relevant failure. |
| seeded-growth modular ideals, $10\le m\le250$ | 19,387 samples; no all-cuts failure. |

For the 15,912 deduplicated structures, the distribution of the minimum cyclic slack was

| $\min_f(\mathcal H_f-K)$ | 0 | 1 | 2 | 3 | 4 |
|---|---:|---:|---:|---:|---:|
| number of structures | 5,076 | 4,458 | 4,638 | 1,668 | 72 |

The original checkpoint cautions that several historical drivers and raw outputs were not committed. Those counts are checkpointed reports, not all one-command reproducible artifacts.

## 12.3 Later archived verification scripts rerun for this synthesis

The following were rerun successfully on 15 August 2026:

| Artifact | Rerun result |
|---|---|
| `verify_wilf_boundary_stability_obstruction.py` | Reproduced the 68-point shape obstruction, all erosion counts, parity obstruction, and exhaustive nonexistence of a residue-bijective weight triple; **PASS**. |
| `verify_wilf_residue_aware_descent.py` | Verified three fixed and 250 seeded random cyclic-inflation identities. |
| `verify_wilf_one_partial_layer.py` | Enumerated all 33,864 finite top-layer subsets, checked the analytic $d=5$ case, and excluded $d\ge6$ under the stated erosion hypothesis; **PASS**. |
| `verify_wilf_conflict_progress.py` | Rechecked stable-transversal audit, two thirds vertices, rank-two violations, certificate lifting, and nine Wilf-objective cases; all requested checks passed. |
| `verify_wilf_greedy_attack.py` | Rechecked the $m=17$ fractional optimum $-1/2$, integer optimum $0$, explicit triangle witnesses, and strengthened optimum $0$. |
| `verify_wilf_reflection_line.py` | Rechecked the reflection-carry and line identities on four fixed semigroups, including $\langle30,63,85,86\rangle$. |

Representative reflection-line output:

| Semigroup generators beyond $m$ | $m$ | $W$ | $\Lambda$ | total reflection capacity | $|Z|$ |
|---|---:|---:|---:|---:|---:|
| $(8,9,11)$ | 7 | 6 | 0 | 6 | 3 |
| $(11,13,16)$ | 10 | 19 | 0 | 19 | 3 |
| $(14,17,19)$ | 10 | 20 | 4 | 24 | 3 |
| $(63,85,86)$ | 30 | 105 | 14 | 119 | 7 |

## 12.4 Dialogue-reported extensions without retained complete drivers

The thread also reported several larger exact scans, including complete or targeted scans through moduli in the twenties and selected instances through $m=64$. These consistently found negative raw relaxations but no negative integer modular ideals; conflict cliques repaired the listed Wilf objectives. Because a complete driver and raw record were not retained for every reported extension, these should be treated as research-log evidence rather than archival reproducibility claims.

# 13. Failed routes and explicit obstructions

The project has gained considerable value from identifying false or insufficient intermediate statements. These should not be retried without a genuinely new hypothesis.

| Failed route | What failed | Explicit witness or reason |
|---|---|---|
| Original arcs partition into $K$ full covers | Stronger than the cut-load inequality and false even for a genuine semigroup. | $S=\langle7,13,44,50\rangle$ has $K=6$ and nonnegative slack, but no six-cover partition. |
| Down-closedness plus distinct integer labels | Does not force the modular correction. | Five-point lower ideal with labels $0,5,3,2,4$ violates the Wilf-shaped moment inequality because $0$ and $5$ collide modulo $5$. |
| Pointwise winding charging | A point's quotient demand need not be paid by its own three line-top increments. | $S=\langle19,20,25,27\rangle$, point $(0,0,3)$. |
| Pointwise reflection charging | A mixed carry may have no local reflection capacity at the same point. | Small $m=5$ modular example from the lift-cone attack. |
| Matching only within the same coordinate line | Global cross-line reassignment is necessary. | Same small modular examples; exact maximum same-line profit is insufficient. |
| Raw LP optimum always greater than $-1$ | False with an unbounded scaling family. | $m=17q$, $A=(1,8q,11q)$ has LP optimum $-q/2$ and integer optimum $0$. |
| Triangle inequalities describe the integer hull | False. | Triangle-free half-integral 5-cycle examples and higher-denominator vertices. |
| Cliques plus odd cycles describe the integer hull | False. | Genuine thirds vertices at $m=14$ and $m=17$ violate rank-two inequalities while satisfying odd-cycle inequalities. |
| Every winding level is separately nonnegative | False; only cumulative suffixes may be nonnegative. | $m=6$, $A=(1,5,2)$ has first layer $-1$ and later compensating layers. |
| Pure Ferrers floor-Euler inequality | Modular separation is essential. | Triangular Ferrers board with $m=10$, $a=b=5$ gives total $-1$. |
| First erosion alone implies the coheight bound | False. | The 80-point simplex-plus-planar-cap shape passes $p=1$ but fails the target; $p=2$ excludes it. |
| Full erosion hierarchy plus shape alone | False. | The 68-point $T_{\mathrm{bad}}$ passes all erosions but fails the shape bound; parity rules out a modular labeling. |
| Incomplete residue-injective ideals support deletion induction | False; incomplete ideals can carry genuine debt. | Reported failures at $m=20$ and $m=16$ in the affine floor-Euler program. |
| Unweighted partial cycle expansion $B-N\le m-|T|$ | Counts both carry orientations and is false. | An 18-point ideal modulo $20$, $A=(1,4,9)$, has $B-N=3>2$, but $\Lambda_A=0$. |
| Forward-ray cycle-to-component theorem | Underlying partial-transversal inequality is false. | Same 18-point example; forward rays cover all 20 residues but the conjectured edge bound asks for 21. |
| Pure rank order or $P_k$ without actual gaps | Additivity and residue constraints are essential. | Small full-dimensional lower ideals admit bad abstract linear extensions not realizable by suitable additive complete residues. |
| One-coordinate semigroup-polynomial argument | Leaves an unavoidable $a_j-1$ error term. | Gives $4g\le3c+a_j-1$, not $4g\le3c$. |
| Uniform factor-selection capacity four | Endpoint-load approach breaks on unique quadratic factorizations. | $S=\langle100,101,103,107\rangle$. |
| Pointwise outer-Apéry pair bounds | Cumulative inequalities can hold while individual increments fail. | $S=\langle6,37,38,53\rangle$. |
| Maximum residue or maximal point is always extremal | False empirically. | In thousands of modular structures, the maximum residue often was not a minimizer, and minimizers often were not maximal-point residues. |
| Coheight-only multiscale boundary estimate | Coordinate-vertex erosion can grow too fast and must be paid by residue or rearrangement information. | Single high-degree coordinate vertex defeats the proposed weighted local inequality. |

## 13.1 Lessons from the failed routes

Three principles recur:

1. **Do not discard residue completeness.** Plain lower-ideal geometry is too weak.
2. **Do not count all cycles.** Only the arithmetic orientation corresponding to mixed carries threatens the chosen cyclic direction.
3. **Do not demand pointwise payment.** Every viable identity exhibits global redistribution across points, lines, levels, or residue classes.
4. **Do not enlarge the theorem casually.** The exact semigroup target has repeatedly survived after natural partial-ideal or shape-only strengthenings failed.

# 14. Current unknowns and recommended next proof program

## 14.1 Primary unknown: final-window weighted overlap

The current exact theorem is

$$
\Delta_Z\le B_{\mathrm{off}}+\sum_{\ell\in\mathscr D}s_\ell.
$$

The proof should use the three coordinate translation permutations to turn a repeated final-window axis prefix into one of the following resources:

- a deep line, whose score is at least $m+\binom{L}{2}$;
- a residual crossing counted by $mc_{j,k}$;
- an unused residue in $B_{\mathrm{off}}$.

The difficulty is multiplicity control: a single deep line or crossing cannot be charged arbitrarily many times.

## 14.2 Recommended manual program

### Step 1: independently audit the final-window identity

Re-derive the reflection-carry identity and the regrouping into $B_{\mathrm{off}}$, deep-line scores, and $\Delta_Z$ from first principles. Check sign conventions and the assertion that all occurring nonzero axis residues are globally distinct.

### Step 2: classify the equality and near-equality geometry

Enumerate or reason about final-window antichains $Z$ with

$$
E_Z>D_Z.
$$

The cases $|Z|\le2$ are closed. For $|Z|=3$, classify coordinate support patterns, box-union projections, and possible values of the gaps $\beta_t$. A complete $|Z|=3$ theorem is a plausible next milestone.

### Step 3: exploit translation cycles residue by residue

For each repeated axis residue $r_{j,k}$, follow the $A_j$-translation cycle starting at the corresponding axis point. Determine whether multiple final-window occurrences force:

- a wrap before returning to the axis chain;
- a line top outside $Z$;
- or a residue outside the union of all axis-prefix sets.

Seek a laminar or uncrossing structure among these paths.

### Step 4: retain weights, not just counts

A count inequality such as $E_Z\le D_Z$ is sufficient but not necessary. The exact debt weights repetitions by $r_{j,k}$ and subtracts $m$ for crossings. A successful theorem may pair large residues with guaranteed crossings and leave only small residues to be paid by deep-line count.

### Step 5: use the quadratic deep-line margin

Each deep line supplies at least

$$
m+\binom{L}{2},
$$

not merely $m$. Long lines may pay concentrated repeated-prefix debt. Any charging scheme should exploit this quadratic bonus.

### Step 6: integrate the cyclic-inflation descent

Before treating a configuration as primitive, quotient by every divisor of $m$. Rank-one quotient cases already descend. This may reduce the difficult overlap theorem to pairwise-primitive residue data.

### Step 7: keep stronger routes as diagnostics, not obligations

Use conflict-clique LP duals, weight-one planar inversions, and the all-cuts modular slack to discover local certificates. Do not require their full conjectures unless the final-window route stalls.

## 14.3 Secondary open routes

1. **Strong modular theorem:** prove $\mathcal H_f\ge K$ for all cuts. Very clean, extensively tested, but stronger than Wilf.
2. **Objective-specific conflict-clique theorem:** prove nonnegativity of the Wilf coefficient vector over the conflict-clique relaxation. Polyhedrally concrete, but still stronger than the exact semigroup theorem.
3. **Weight-one carry-inversion matching:** a specialized two-dimensional Hall theorem.
4. **Sorted-Apéry outer-prefix majorization:** independent numerical-order route; proved for almost-symmetric $e=4$ but open generally.
5. **Kunz-cone direct optimization:** best disproof lane if one wishes to search for an actual Wilf counterexample rather than break a strengthening.

## 14.4 What would be conclusive

Any proof of the final-window overlap inequality is conclusive because it enters an exact identity for $mW$. No additional conjecture or asymptotic argument is needed.

A counterexample to that overlap inequality would be an actual four-generated semigroup with $W<0$, provided all objects arise from a genuine Apéry staircase. By contrast, a counterexample to the stronger modular or polyhedral conjectures would only redirect the proof search.

# 15. Related work and how it enters this project

The following references are the most relevant external inputs. Version and status information was refreshed on 15 August 2026 where noted.

| Ref. | Work | Role in this project |
|---|---|---|
| [R1] | A. Bacher, *Families of Eliahou semigroups linked to Farey intervals*, arXiv:2604.25051v6 (5 Aug 2026) | Current open-status context; Eliahou-semigroup families; summary of verified regimes. |
| [R2] | K. Chomicz, *On numerical semigroups with embedding dimension four*, arXiv:2604.25653 (2026) | General geometric method for four-generated Apéry sets. Supports the geometry but does not prove Wilf. |
| [R3] | M. F. Marashdeh, *An upper bound for the type of a numerical semigroup, and a reduction of Wilf's conjecture*, arXiv:2608.12531v1 (12 Aug 2026) | Very recent type bound and independent reduction of Wilf; useful comparison, not a closure of $e=4$. |
| [R4] | W. Bruns, P. A. García-Sánchez, C. O'Neill, D. Wilburne, *Wilf's conjecture in fixed multiplicity*, arXiv:1903.04342 | Polyhedral/Kunz verification through multiplicity 18. |
| [R5] | J. Kliem, C. Stump, *A new face iterator...*, arXiv:1905.01945; Discrete Comput. Geom. (2022) | Extends fixed-multiplicity verification to $m=19$. |
| [R6] | S. Eliahou, *Wilf's conjecture and Macaulay's theorem*, JEMS 20 (2018) | Covers important conductor/depth regimes; inspires Hilbert-function and shadow arguments. |
| [R7] | S. Eliahou, D. Marín-Aragón, *On numerical semigroups with at most 12 left elements*, arXiv:2006.01480 | Excludes $n\le12$. |
| [R8] | M. Delgado, S. Eliahou, J. Fromentin, *A verification of Wilf's conjecture up to genus 100*, arXiv:2310.07742 | Excludes genus at most 100. |
| [R9] | M. Delgado, N. Kumar, *Algorithms for numerical semigroups with fixed maximum primitive*, arXiv:2512.23891 | Verifies Wilf for maximum primitive at most 60. |
| [R10] | R. Fröberg, C. Gottlieb, R. Häggkvist, *On numerical semigroups*, Semigroup Forum 35 (1986/87) | Classical $e=3$ and type inequality $c\le(t+1)n$. |
| [R11] | A. Moscariello, F. Strazzanti, *Nearly Gorenstein vs almost Gorenstein affine monomial curves*, arXiv:2003.05391 | Type bound for four-generated nearly Gorenstein semigroups. |
| [R12] | A. Sammartano, *Numerical semigroups with large embedding dimension satisfy Wilf's conjecture*, Semigroup Forum 85 (2012) | Large embedding dimension and generalized arithmetic-sequence classes. |
| [R13] | S. Eliahou, *A graph-theoretic approach to Wilf's conjecture*, Electron. J. Combin. 27 (2020) | Factorization/depth graph framework; motivates graph-theoretic capacity ideas. |
| [R14] | F. Nari, *Symmetries on almost symmetric numerical semigroups*, arXiv:1111.6211 | Apéry pairing used in the almost-symmetric prefix theorem. |
| [R15] | A. Moscariello, *On the type of an almost Gorenstein monomial curve*, arXiv:1507.05949 | Type at most three for the relevant almost-symmetric four-generated case. |
| [R16] | M. Hellus, A. Rechenauer, R. Waldi, *Variants on a question of Wilf*, arXiv:1804.06141 | Weighted lower ideals, periodic lattice tilings, exterior corners, double-staircase geometry. |
| [R17] | M. Dhayni, *Wilf's conjecture for numerical semigroups*, arXiv:1610.08726 | Numerical-order Apéry inequalities; relevant to the sorted-prefix route. |
| [R18] | N. Kaplan, *Counting numerical semigroups*, J. Pure Appl. Algebra 216 (2012) | Residue-indexed Kunz coordinate pairings; useful but distinct from numerical-order statistics. |
| [R19] | L. Casabella, M. D'Anna, P. A. García-Sánchez, *Apéry sets and the ideal class monoid of a numerical semigroup*, arXiv:2302.09647 | Min-plus/ideal operations on Apéry sets. |
| [R20] | A. Zhai, *An asymptotic result concerning a question of Wilf*, arXiv:1111.2779 | Weighted-lower-ideal context and asymptotic background. |

## 15.1 External reference links

- [R1] <https://arxiv.org/abs/2604.25051>
- [R2] <https://arxiv.org/abs/2604.25653>
- [R3] <https://arxiv.org/abs/2608.12531>
- [R4] <https://arxiv.org/abs/1903.04342>
- [R5] <https://arxiv.org/abs/1905.01945>
- [R6] <https://arxiv.org/abs/1703.01761>
- [R7] <https://arxiv.org/abs/2006.01480>
- [R8] <https://arxiv.org/abs/2310.07742>
- [R9] <https://arxiv.org/abs/2512.23891>
- [R12] <https://arxiv.org/abs/1111.1863>
- [R13] <https://arxiv.org/abs/1909.03699>
- [R14] <https://arxiv.org/abs/1111.6211>
- [R15] <https://arxiv.org/abs/1507.05949>
- [R16] <https://arxiv.org/abs/1804.06141>
- [R17] <https://arxiv.org/abs/1610.08726>
- [R19] <https://arxiv.org/abs/2302.09647>
- [R20] <https://arxiv.org/abs/1111.2779>

# 16. Project artifacts and cold-start instructions

## 16.1 Core research notes

| File | Contents |
|---|---|
| `research-checkpoint.md` | Original 6 Aug 2026 self-contained handoff: literature frontier, exact Apéry/boundary/cyclic identities, searches, subcases, and failed routes. |
| `wilf-final-window-line-reduction.md` | Current primary exact reduction; deep-line positivity; final-window overlap formula; proof for $|Z|\le2$; exact remaining theorem. |
| `wilf-reflection-carry-line-reduction.md` | Earlier reflection-carry and coordinate-line reduction; axis-overlap criteria. |
| `wilf-residue-aware-descent.md` | Coheight-corrected cyclic criterion and cyclic-inflation descent theorem. |
| `wilf-conflict-graph-progress.md` | Stable-transversal characterization, clique formulation, half-integral theorem, thirds vertices, certificate lifting. |
| `wilf-greedy-attack.md` | First fractional obstruction, explicit triangle, scaling theorem, winding filtration. |
| `wilf-weight-one-carry-reduction.md` | Vertical-column tiling, planar carry factorization, and weight-one matching target. |
| `wilf-erosion-layer-progress.md` | Homogeneous layer/erosion analysis and one-partial-layer theorem. |
| `wilf-boundary-stability-obstruction.md` | Explicit 68-point obstruction to the pure shape-only stability theorem. |

## 16.2 Verification scripts

| Script | Purpose |
|---|---|
| `verify_wilf_reflection_line.py` | Checks the exact reflection-carry and line identities on fixed semigroups. |
| `verify_wilf_residue_aware_descent.py` | Checks cyclic-inflation Apéry products and invariant formulas. |
| `verify_wilf_conflict_progress.py` | Checks stable-transversal examples, thirds vertices, clique/rank constraints, lifting, and target LP/IP cases. |
| `verify_wilf_greedy_attack.py` | Checks the $m=17$ fractional obstruction, triangle witnesses, and exact rational optima. |
| `verify_wilf_one_partial_layer.py` | Exhaustive finite verification for the one-partial-layer theorem. |
| `verify_wilf_boundary_stability_obstruction.py` | Checks the 68-point erosion obstruction and parity nonmodularity. |
| `verify_wilf_weight_one.py` | Checks identities in the weight-one planar reduction. |
| `optimize_lifts.py` | Optimizes unreduced generator lifts in the three-variable lift-cone exploration. |
| `find_pointwise_reflection_failure.py` | Produces a small failure of pointwise reflection charging. |

## 16.3 Suggested cold start

1. Read Sections 4, 6, and 7 of this handoff.
2. Re-run:

```bash
python verify_wilf_reflection_line.py
python verify_wilf_residue_aware_descent.py
python verify_wilf_conflict_progress.py
python verify_wilf_greedy_attack.py
python verify_wilf_one_partial_layer.py
python verify_wilf_boundary_stability_obstruction.py
```

3. Independently rederive the exact final-window identity.
4. Start with the first unresolved combinatorial case $|Z|=3$.
5. Preserve complete residue and Apéry-minimality information; do not induct through arbitrary partial ideals without a new invariant.

# Appendix A. Compact claim ledger

## A.1 Published inputs

- Wilf for embedding dimension at most three.
- Fixed multiplicity through nineteen.
- The $c\le3m$, $n\le12$, genus $\le100$, and maximum primitive $\le60$ regimes.
- Type inequality $c\le(t+1)n$.
- Generalized arithmetic-sequence and large-embedding-dimension classes.
- Apéry/Selmer formulas.
- Periodic lattice-fundamental-domain interpretation of Apéry staircases.
- Almost-symmetric Apéry pairing and type bound at $e=4$.

## A.2 Durable project theorems

- Selected Apéry factorizations form a three-dimensional lower ideal.
- Exact moment equation and coordinate-boundary identity.
- Translation permutations and carry sums.
- Positive carry polynomial factorization.
- Exact modular/cyclic identities.
- Stable-transversal characterization and clique-implies-downward-closure theorem.
- Rational blow-up coloring/decomposition theorem.
- Half-integral odd-cycle dichotomy.
- Exact scaling theorem for the $m=17$ fractional obstruction.
- Cyclic-inflation Apéry product and Wilf descent.
- One-partial-layer theorem.
- Reflection-carry identity $W=\Gamma-\Lambda$.
- Exact coordinate-line and final-window formulas.
- Wilf for $|Z|\le2$.
- Rectangular, almost-symmetric, and double-staircase subfamilies.

## A.3 Computer-assisted project theorems

- One-partial-layer finite cases $d\le4$ with analytic closure for larger $d$ under the stated erosion hypothesis.
- Exact rational certificates for selected conflict-clique instances and their lifted families.

## A.4 Principal conjectures still open

- Final-window weighted overlap theorem for $|Z|\ge3$.
- Strong modular cyclic inequality $\mathcal H_f\ge K$.
- Objective-specific conflict-clique nonnegativity theorem.
- Weight-one carry-inversion matching theorem.
- Sorted-Apéry outer-prefix majorization in general.

## A.5 Statements explicitly refuted

- Original $K$-cover partition of the arcs.
- Raw LP lower bound greater than $-1$.
- Triangle or odd-cycle description of the integer hull.
- Separate nonnegativity of every winding layer.
- First-erosion or full-erosion shape-only closure.
- Unweighted partial cycle expansion and forward-ray theorem.
- Pointwise and same-line carry payment.
- Several simple sorted-order and factor-capacity shortcuts.

# Appendix B. Notation dictionary

| Symbol | Meaning |
|---|---|
| $m$ | multiplicity; also $|T|$ |
| $e$ | embedding dimension; target $e=4$ |
| $T$ | selected three-dimensional Apéry lower ideal |
| $w(x)$ | actual label $a_1x_1+a_2x_2+a_3x_3$ |
| $M$ | maximum Apéry label |
| $\Sigma$ | sum of Apéry labels |
| $W$ | Wilf number $4n-c$ at $e=4$ |
| $D$ | actual boundary deficit $3mM-4\Sigma$ |
| $A_j$ | reduced generator $a_j\bmod m$ |
| $K$ | total reduced-label quotient sum |
| $\mathcal H_f$ | cyclic cut load |
| $G_f$ | cyclic slack $\mathcal H_f-K$ |
| $p_jx$ | top of the coordinate-$j$ line through $x$ |
| $\rho_jx$ | reflection of $x$ in its coordinate-$j$ line |
| $\lambda(x)$ | mixed-coordinate carry at $x$ |
| $\Lambda$ | total mixed-carry demand |
| $\gamma_j(x)$ | reflection capacity |
| $C(x)$ | coordinate-top load at $x$ |
| $h(x)$ | coheight to a maximal point |
| $H(T)$ | coheight-weighted top load |
| $Z$ | final-window maximal set $0\le M-w(t)<m$ |
| $L_\ell$ | length of a coordinate line |
| $h_\ell,\beta_\ell$ | quotient and remainder of $M-w(t_\ell)$ by $m$ |
| $R_A(L)$ | sum of coordinate residues $[kA]_m$ along a line |
| $C_A(L,\beta)$ | residual crossings on a line |
| $\Delta_Z$ | repeated-axis-prefix debt in the final window |
| $B_{\mathrm{off}}$ | unused nonzero residue mass outside final-window axis prefixes |
| $s_\ell$ | exact positive score of a deep line |

# Appendix C. Key explicit witnesses

## C.1 False original cover partition

$$
S=\langle7,13,44,50\rangle,
\quad A=(1,6,2),
$$

$$
T=\{0,e_1,e_3,e_2,2e_2,3e_2,4e_2\},
$$

$$
K=6,
\quad
\mathcal H=(12,11,10,6,7,8,9),
\quad
G=(6,5,4,0,1,2,3).
$$

The cyclic inequality holds, but the original arcs cannot be split into six full covers.

## C.2 First negative LP

$$
m=17,\quad A=(1,8,11),\quad f=14.
$$

Raw LP optimum $-1/2$, integer optimum $0$. The conflict triangle is

$$
(0,0,3),\quad(0,2,1),\quad(5,0,0).
$$

Its clique inequality raises the relaxation to zero.

## C.3 Pure shape obstruction

$$
T_{\mathrm{bad}}=\Delta_4\cup\{x:|x|_1\in\{5,6\},\ x_1x_2x_3=0\},
\quad |T_{\mathrm{bad}}|=68.
$$

It satisfies all erosion inequalities but violates the unrestricted shape bound by $21$. No linear residue bijection modulo $68$ exists; parity already rules it out.

## C.4 False unweighted partial-cycle theorem

For $m=20$, $A=(1,4,9)$, the 18-point lower ideal listed in the research log has residues missing only $15$ and $16$, but

$$
B-N=3>2=m-|T|,
\qquad
\Lambda_A=0.
$$

It demonstrates that all Hasse cycles cannot be charged; only the arithmetic carry orientation matters.

# Appendix D. Immediate next questions

1. Can the $|Z|=2$ projection argument be generalized to $|Z|=3$ using inclusion-exclusion for three maximal boxes, while preserving a useful weighted bound?
2. Does every repeated final-window axis residue determine a canonical translation-cycle path ending at a unique deep line or crossing?
3. Can large residue debts be paired first with crossing terms, leaving only a count-level debt small enough for deep lines?
4. Does pairwise primitivity $\gcd(m,a_i,a_j)=1$ force a useful expansion property for the axis-prefix residue sets?
5. Can the exact conflict-clique dual certificates be interpreted directly as local proofs of the final-window overlap inequality?
6. Is there a minimal-counterexample argument showing $|Z|=3$ or bounding the coordinate support pattern of $Z$?
7. Can Chomicz's relation geometry or Hellus--Rechenauer--Waldi exterior-corner constraints be translated into bounds on $z_{j,k}$ and $c_{j,k}$?

# Final handoff

The best current starting point is not the original all-cuts arc-cover conjecture. It is the exact line identity in Section 7. A new proof should work directly with the final-window antichain $Z$, the repeated axis-prefix debt $\Delta_Z$, the deep-line margins $s_\ell$, and the unused residue mass $B_{\mathrm{off}}$. The first new theorem to seek is the complete $|Z|=3$ case. Every proposed strengthening should be tested immediately against the explicit failures cataloged in Section 13.
