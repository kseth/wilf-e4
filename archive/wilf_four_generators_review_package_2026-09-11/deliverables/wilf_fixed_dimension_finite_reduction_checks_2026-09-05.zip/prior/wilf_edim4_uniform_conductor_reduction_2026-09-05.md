# Wilf in embedding dimension four: a uniform conductor reduction

**Date:** 5 September 2026.  
**Status:** A reduction for every possible four-generator counterexample, not a proof or disproof of unrestricted Wilf. The quadratic bound below uses the computer-assisted six-point theorem from the preceding checkpoint. A weaker cubic bound is proved analytically, without that input. Priority has not been established.

## 1. The result and the remaining gap

Let
\[
S=\langle m,a,b,d\rangle,\qquad m<a<b<d,
\]
be a numerical semigroup with this minimal generating set. Write
\[
c=\text{conductor}(S),\qquad n=|S\cap[0,c)|,\qquad W=4n-c.
\]

**Theorem A.** Using the six-point theorem proved in the preceding checkpoint,
\[
\boxed{W<0\ \Longrightarrow\ c\le m^2-3m+1.} \tag{A}
\]
Moreover, all three nonmultiplicity generators of a counterexample satisfy
\[
\boxed{m<a<b<d\le m(m-2).} \tag{B}
\]
Equivalently, every minimally four-generated numerical semigroup with
\(c>m^2-3m+1\) satisfies Wilf's inequality. There is no restriction on multiplicity, type, number of maximal Apéry elements, or final-window size in this assertion.

This gives an explicit finite box of generators to check **for each fixed multiplicity**. It does not give a bound on multiplicity. Consequently it does not produce one finite verification of the whole four-generator conjecture. A proof is still required for the unbounded family of boxes (B).

The mechanism is a dichotomy. Either the preferred Apéry staircase omits an exponent of weight at most its maximum, and that omission forces at least one full maximum's worth of slack in Zhai's inequality; or it omits no such exponent, in which case residue injectivity forces at most six maximal points. The latter case is already covered by our six-point theorem.

**Analytic fallback, independent of the six-point input.** For \(m\ge5\), we also prove
\[
\boxed{W<0\ \Longrightarrow\ c\le m(m-2)(m-3)-m+1.} \tag{C}
\]
The proof is included in Section 6. Thus the existence of a uniform polynomial conductor bound here does not depend entirely on the earlier finite enumeration.

## 2. Apéry coordinates and the exact slack identity

Let \(\operatorname{Ap}(S,m)=\{s\in S:s-m\notin S\}\). For each Apéry element choose its lexicographically least factorization in \(a,b,d\), and let \(T\subset\mathbb N^3\) be the resulting exponent set. Then

- \(T\) is a finite lower ideal, \(|T|=m\), and \(0,e_1,e_2,e_3\in T\);
- \(w(x)=ax_1+bx_2+dx_3\) labels its points bijectively modulo \(m\);
- \(M:=\max_T w=c+m-1\).

For completeness, downward closure follows as follows. A divisor of an Apéry factorization is itself Apéry, since otherwise adding the remaining factors would make the original element minus \(m\) belong to \(S\). A nonpreferred divisor factorization could also be replaced to give a lexicographically smaller factorization of the original element. Minimal generation puts the three unit vectors in \(T\).

Set
\[
\Sigma=\sum_{x\in T}w(x),\qquad D=3mM-4\Sigma.
\]
Partition \(T\), separately in each coordinate direction, into nonempty coordinate lines. Write \(L_\ell\) for a line's length and \(t_\ell\) for its top. Then
\[
\boxed{D=\sum_\ell L_\ell\bigl(M-w(t_\ell)\bigr).} \tag{1}
\]
All summands are nonnegative. To verify the identity, on a line parallel to coordinate \(j\), the top weight is twice the mean contribution from coordinate \(j\), plus the unchanged contributions from the other coordinates. Summing \(L_\ell w(t_\ell)\) over the three directions therefore gives \(4\Sigma\).

The Apéry genus formula \(g=\Sigma/m-(m-1)/2\), with \(n=c-g\), gives
\[
\boxed{mW=D-m(m-1).} \tag{2}
\]
This identity also fixes the integer endpoint in (A): if \(W<0\), then \(W\le-1\), so
\[
D\le m(m-2). \tag{3}
\]

The underlying weighted lower-ideal inequality is Zhai's Lemma 3 [1]. We use its slack explicitly, rather than treating mere strictness as sufficient for Wilf.

## 3. A missing exponent forces quantitative slack

Call a coordinatewise minimal element of \(\mathbb N^3\setminus T\) a *minimal excluded point*. The following statement is purely geometric; it does not require Apéry realizability.

**Lemma 1.** Suppose some \(x\notin T\) has \(w(x)\le M\). Then
\[
\boxed{D\ge M.} \tag{4}
\]
More generally, if \(H\) minimal excluded points have weight at most \(M\), then \(D\ge HM\).

**Proof.** Choose a minimal excluded point \(p\le x\), so \(w(p)\le M\). For each \(j\) with \(p_j>0\), the point \(p-e_j\) is the top of a coordinate line of length \(p_j\). The next point is \(p\), which is excluded. The selected lines contribute
\[
\begin{aligned}
\sum_{j:p_j>0}p_j\bigl(M-w(p-e_j)\bigr)
&=|p|_1\bigl(M-w(p)\bigr)+w(p)\\
&=M+(|p|_1-1)\bigl(M-w(p)\bigr)\\
&\ge M.
\end{aligned}
\]
All other terms in (1) are nonnegative. Different minimal excluded points cannot select the same line in a fixed direction: they would agree in the other coordinates and hence be comparable. Lines in different directions are separate summands in (1). Thus the same argument adds over all \(H\) points. \(\square\)

The lemma holds verbatim in \(\mathbb N^r\) for
\[
D_r=r|T|M-(r+1)\sum_Tw,
\]
because the same line identity holds in every dimension.

Absence of such a missing exponent is equivalent to
\[
\boxed{T=\{x\in\mathbb N^3:w(x)\le M\}.} \tag{5}
\]
Indeed, if an omitted point had weight at most \(M\), a minimal excluded point below it would also have weight at most \(M\). We call (5) a full weighted staircase.

## 4. Full weighted Apéry staircases have at most six maximal points

We first record precisely what residue injectivity supplies. For a minimal excluded point \(p\), let \(q\in T\) be the representative of its residue. Then
\[
\operatorname{supp}(p)\cap\operatorname{supp}(q)=\varnothing. \tag{6}
\]
Otherwise, for a shared coordinate \(j\), the distinct points \(p-e_j,q-e_j\in T\) would have equal residues. Similarly, two distinct minimal excluded points with intersecting supports have different residues. In particular, there is at most one minimal excluded point with all coordinates positive, and its representative is zero. This is the relevant content of Hellus–Rechenauer–Waldi, Proposition 2.6 [2]; the short arguments above establish the specialization needed here.

**Lemma 2.** Let (5) hold, let \(a\le b\le d\), and suppose the labels on \(T\) are bijective modulo \(|T|\). If \(T\) contains all three unit vectors, its projection onto coordinates 2 and 3 is one of the following:

1. the union of the two axes, with coordinate heights \((h_2,h_3)=(1,1)\) or \((2,1)\); or
2. \(\{(y,z)\in\mathbb N^2:y+z\le2\}\).

In particular, \(T\) has at most six maximal points.

**Proof.** Put
\[
h_2=\lfloor M/b\rfloor,\qquad h_3=\lfloor M/d\rfloor.
\]
Both are positive. For each \(1\le y\le h_2\), the point
\[
p_y=\left(\left\lfloor\frac{M-by}{a}\right\rfloor+1,\ y,\ 0\right)
\]
is minimal excluded. Its first-coordinate predecessor has weight at most \(M\). Its second-coordinate predecessor also has weight at most \(M\), because \(b\ge a\). Both its positive coordinates are indeed positive, since \(by\le M\).

By (6), the representatives of these \(h_2\) points lie on the third axis. They are distinct, so
\[
h_2\le h_3+1. \tag{7}
\]

If \(M<b+d\), the projection contains no point with both coordinates positive. Also \(M<b+d\le2d\), so \(h_3=1\), and (7) gives \(h_2\le2\). This is alternative 1 and gives at most four columns.

Now suppose \(M\ge b+d\). Then
\[
p=\left(\left\lfloor\frac{M-b-d}{a}\right\rfloor+1,1,1\right)
\]
is an interior minimal excluded point. Its representative is zero, and its support intersects that of every \(p_y\). Consequently none of the \(p_y\) can use the zero residue, which strengthens (7) to
\[
h_2\le h_3. \tag{8}
\]
If \(M\ge2b+d\), the analogous point with last two coordinates \((2,1)\) would be a second interior minimal excluded point. Therefore
\[
M<2b+d\le3d,
\]
and \(h_3\le2\). On the other hand, \(M\ge b+d\ge2b\) gives \(h_2\ge2\). Combining with (8),
\[
h_2=h_3=2.
\]
Thus \(2d\le M<3b\). Every two-coordinate point of total degree at most two has weight at most \(2d\), and every point of total degree at least three has weight at least \(3b\). The projection is exactly the six-point triangle in alternative 2.

Finally, each maximal point of \(T\) must be the top of its first-coordinate column. There are at most six such columns. \(\square\)

The proof only bounds the six-column alternative; it does not assert that this alternative is realizable. An exploratory search described in Section 8 found no realization in its finite range. Excluding that alternative is unnecessary for Theorem A.

## 5. Completion of the quadratic reduction

The earlier checkpoint proves the following input, including its finite enumeration and exact certificates:
\[
\left|\operatorname{Ap}(S,m)\cap[c,c+m)\right|\le6
\quad\Longrightarrow\quad W\ge0. \tag{Six}
\]
Every exponent representing an Apéry element in \([c,c+m)\) is maximal in \(T\): its deficit from \(M=c+m-1\) is less than \(m\), whereas adding any nonmultiplicity generator increases weight by more than \(m\).

Assume \(W<0\). If (5) held, Lemma 2 would give at most six maximal points and hence at most six final-window points, contradicting (Six). Therefore a missing exponent of weight at most \(M\) exists. Lemma 1 and (3) give
\[
M\le D\le m(m-2).
\]
Since \(c=M-m+1\), this proves (A). Each generator \(a,b,d\) labels a unit vector in \(T\), so it is at most \(M\), proving (B). \(\square\)

This is the sole use of the computer-assisted input. Lemmas 1 and 2, and the deduction after (Six), are analytic and have no search cutoff.

## 6. An independent analytic cubic bound

The following argument does not use (Six).

**Lemma 3.** A finite lower ideal \(U\subset\mathbb N^r\) has every coordinate-line top maximal if and only if
\[
U=\Delta_R:=\{x:|x|_1\le R\}
\]
for some \(R\).

**Proof.** If \(x\in U\), \(x_i>0\), and \(j\ne i\), then \(x-e_i+e_j\in U\). Otherwise \(x-e_i\) would be a \(j\)-line top which is not maximal, since its successor \(x\) is in \(U\). These unit transfers connect all nonnegative integer vectors of each fixed total degree. Starting from a point of maximum degree \(R\) obtains that whole degree layer, and downward closure obtains every lower layer. The converse follows directly for \(\Delta_R\). \(\square\)

**Lemma 4.** Suppose a finite lower ideal \(U\subset\mathbb N^r\) contains all unit vectors and is not a full standard simplex. For positive weights \(v_j\), let \(v_j=\beta\) be a minimum weight and let \(h\) be the height of its coordinate axis in \(U\). If \(s=|U|\), then
\[
\boxed{D_r\ge\frac{M}{h}\ge\frac{M}{s-r}.} \tag{9}
\]

**Proof.** Write \(\delta=M-h\beta\ge0\). The origin line in direction \(j\) contributes \((h+1)\delta\) to the slack identity. By Lemma 3 there is a nonmaximal line top \(t\). Some successor \(t+e_k\) belongs to \(U\), so its gap is at least \(v_k\ge\beta\).

If this is the same origin line, \(\delta\ge\beta\), and
\[
D_r\ge(h+1)\delta\ge h\beta+\delta=M.
\]
Otherwise it is a distinct line, whose length is at least one, giving
\[
D_r\ge(h+1)\delta+\beta.
\]
Since \(h\ge1\), multiplying by \(h\) gives \(hD_r\ge\delta+h\beta=M\). Finally, the \(h+1\) axis points and the other \(r-1\) unit vectors are distinct, so \(s\ge h+r\). \(\square\)

For a genuine four-generator Apéry staircase with \(m\ge5\), the simplex alternative cannot occur. For \(R\ge3\), the three permutations of \((R-1,1,1)\) are distinct interior minimal excluded points, contradicting (6). For \(R=2\), the size is ten. If its labels were bijective modulo ten, the four residues \(0,a,b,d\) would have all ten unordered sums of two residues, with repetition, distinct. It follows that their twelve ordered nonzero differences are distinct: an equality of differences gives an equality of unordered pair sums, forcing the original ordered pairs to coincide. There are only nine nonzero residues modulo ten, a contradiction. The remaining simplex \(R=1\) has \(m=4\).

Applying (9) therefore gives the unconditional inequality
\[
\boxed{D\ge\frac{c+m-1}{m-3},\qquad
W\ge\frac{c+m-1}{m(m-3)}-(m-1)\quad(m\ge5).} \tag{10}
\]
For a counterexample, (3) now implies (C). When \(m=4\), \(T=\{0,e_1,e_2,e_3\}\), and directly
\[
W=2d-a-b-3\ge0
\]
because the generators are distinct integers with \(a<b<d\).

## 7. What happened to descent, and what this does not settle

The elementary proposal to lower generators by subtracting another generator does not provide an unconditional monotone descent. For example,
\[
S=\langle93,132,433,457\rangle,
\quad c=2409,\quad n=906,\quad W=1215.
\]
Each of the six single pair-subtraction moves retains four minimal generators, but produces Wilf numbers \(1710,1614,1355,1395,1734,1254\). Subtracting the multiplicity from all three other generators gives \(1524\). All increase \(W\).

These examples refute the unconditional monotonicity assertion. They do **not** refute a descent that is proved only under \(W<0\): the displayed source has positive Wilf number. No such counterexample-preserving descent with established terminal cases has been proved here.

The completed reduction now leaves this precise target:
\[
\begin{gathered}
\text{For every }m,\text{ every minimal }\langle m,a,b,d\rangle
\text{ with }m<a<b<d\le m(m-2),\\
\text{and with a missing exponent below the Apéry maximum, show }4n\ge c.
\end{gathered}
\]
Known cases, including (Six) and the preceding column theorem, can remove further semigroups from these boxes. They do not remove all of them. A multiplicity bound or a uniform inequality on the remainder is still missing.

The stronger geometric claim \(D\ge M\) for every nonsimplex lower ideal in \(\mathbb N^3\), with arbitrary positive weights, was explored but has **not** been proved. Theorem A does not assume it. Nor do we assume that an interior excluded point forces semigroup type at most three; \(\langle51,55,126,172\rangle\) is an explicit counterexample to that auxiliary assertion, with type five and interior excluded point \((2,1,1)\).

## 8. Verification and provenance

`wilf_uniform_reduction.py` supplies standard-library, exact-integer diagnostics. The recorded run passed:

- 3,916 weight/ideal combinations on all 979 nonempty lower ideals in \(\{0,1,2\}^3\);
- 3,949 minimally four-generated semigroups from 5,000 seeded proposals, checking the slack identity, the support restrictions, and the full-weighted classification when applicable;
- independent bounded membership counts for the first 100 accepted samples and the small named fixtures;
- full-weighted examples in the family
  \[
  \langle7q,\ 7q+1,\ q(7q+3),\ q(14q+5)\rangle
  \]
  for \(q=2,3,10,31,100\), including the identity \(M=21q^2-1\);
- sharp geometric hole fixtures \(\Delta_R\setminus\{(R,0,0)\}\), with equal weights and \(D=M=R\).

These are diagnostics for the written analytic proofs, not their logical basis. In particular, a sample containing no Wilf counterexample cannot by itself verify a statement about every counterexample.

`full_weighted_search.cpp` separately examined 878,136 full weighted staircases in the possible six-column alternative, for integer weights \(1\le a\le b\le d\le100\), \(\gcd(a,b,d)=1\), and actual maximum \(2d\le M<\min(3b,2b+d)\). None had labels bijective modulo its size. This does not eliminate that alternative beyond the stated finite search, and is not used in the proof.

The archive includes the complete preceding six-point verification package as a dependency. Its recorded proof enumeration and exact checks are documented there; they are not replaced by the random tests in this note. The stored certificate checker was rerun for this reduction.

## 9. Relation to the literature

Zhai explicitly proposed studying the deviation from equality in the weighted lower-ideal inequality [1, concluding remarks]. Lemma 4 gives one quantitative deviation bound, and Lemma 1 extracts a larger bound from a missing exponent. The restriction on supports is established prior work [2]. Decidability at fixed multiplicity is also prior work: Bruns, García-Sánchez, O'Neill and Wilburne give a Kunz-polyhedron algorithm [3]. Thus fixed-multiplicity decidability itself is not a novelty claim here. The particular explicit quadratic cutoff (A) has been derived in this checkpoint; our targeted literature search did not establish its priority.

The August 2026 type-based reduction [4] expressly leaves Wilf unresolved. Its redundancy inequality and our conductor reduction do not supply a missing unrestricted proof simply by being combined. We have not obtained a proof or disproof of the four-generator conjecture.

### References and dependencies

1. A. Zhai, *An asymptotic result concerning a question of Wilf*, arXiv:1111.2779. Lemma 3 and Section 5. https://arxiv.org/pdf/1111.2779
2. M. Hellus, A. Rechenauer, R. Waldi, *Variants on a question of Wilf*, arXiv:1804.06141. Proposition 2.6. https://arxiv.org/pdf/1804.06141
3. W. Bruns, P. A. García-Sánchez, C. O'Neill, D. Wilburne, *Wilf's conjecture in fixed multiplicity*, International Journal of Algebra and Computation 30 (2020), 861–882. https://www.home.uni-osnabrueck.de/wbruns/brunsw/pdf-article/S021819672050023X-1.pdf
4. M. F. Marashdeh, *An upper bound for the type of a numerical semigroup, and a reduction of Wilf's conjecture*, arXiv:2608.12531v1 (12 August 2026). https://arxiv.org/pdf/2608.12531
5. Our preceding checkpoint, `wilf_edim4_six_point_and_column_theorems_2026-09-05.md`, Theorem A and its bundled finite verification. This is a research dependency from this conversation, not a published external theorem.
