"""Reproduce the bounded diagnostic of the ordered geometric certificate.

This is a finite test, not a proof outside the specified generator range.
Each LP optimum is verified with exact primal and dual rational certificates.
"""
import argparse
import json
from itertools import combinations
from pathlib import Path
from wilf_work import apery
from wilf_reassessment import ordered_geometric_optimum


def scan(lo,hi,multiplier,output):
    seen={};failures=[];count=0
    for m in range(lo,hi+1):
        for a in combinations(range(m+1,multiplier*m),3):
            data=apery((m,*a))
            if data is None:continue
            count+=1
            t=frozenset(x for w,x in data[2])
            if t in seen:continue
            r=ordered_geometric_optimum(t);seen[t]=r
            if not r['sufficient']:
                failures.append(dict(gens=(m,*a),shape=sorted(t),lp=r))
                print('FAIL',json.dumps(failures[-1]),flush=True)
                break
        if failures:break
        print('done multiplicity',m,'semigroups',count,'shapes',len(seen),flush=True)
    result=dict(semigroups=count,shapes=len(seen),range_m=[lo,hi],
        generator_range=f'm<a1<a2<a3<{multiplier}m',completed_m=m,
        stopped_at_first_failure=bool(failures),failures=failures)
    Path(output).write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--min-m',type=int,default=20)
    p.add_argument('--max-m',type=int,default=40)
    p.add_argument('--multiplier',type=int,default=2)
    p.add_argument('--output',default='ordered-shape-search-20-40.json')
    a=p.parse_args()
    scan(a.min_m,a.max_m,a.multiplier,a.output)
