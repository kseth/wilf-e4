"""Exact diagnostics accompanying the reassessment, not a global Wilf proof.

The infinite-family proofs are in the accompanying Markdown note. This script
checks their formulas and fixed witnesses with integer/rational arithmetic.
No third-party packages are needed unless --lp is supplied.
"""
from fractions import Fraction as Q
from itertools import product, combinations
from collections import defaultdict
from pathlib import Path
import argparse
import json

from wilf_work import apery, inspect, projection_score
from wilf_reassessment import (corners, reconstruct, audit_semigroup,
                               projected_grid_witness)


def double_shape(s):
    return {x for x in product(range(s), repeat=3)
            if sum(x) <= s-1 and x[0]*x[1] == 0}


def three_face_shape(d):
    return {x for x in product(range(d+1), repeat=3)
            if sum(x) <= d and 0 in x}


def label_collisions(t,a):
    labels=defaultdict(list)
    for x in sorted(t):
        labels[sum(v*w for v,w in zip(a,x)) % len(t)].append(x)
    return {r:xs for r,xs in labels.items() if len(xs)>1}


def main(lp=False):
    # Constants in the analytic six-point finite-reduction theorem.
    column_max=max(sum(c)-max(c) for c in product(range(6),repeat=6)
                   if set(c)==set(range(max(c)+1)))
    assert column_max==10
    initial_E_max=3*column_max
    max_insertions=initial_E_max-1
    final_E_max=initial_E_max+5*max_insertions
    projection_total_max=18+final_E_max-1
    assert (initial_E_max,max_insertions,final_E_max,projection_total_max)==(30,29,175,192)
    assert 512**2==(projection_total_max//3)**3
    for b in range(1,7):
        for p,q in product(range(7),repeat=2):
            if b>(p+1)*(q+1):continue
            if b==6 and {p,q}=={1,2}:continue  # Forbidden projection grid.
            assert p+q+3-b>=1
    for h in range(5):
        z={(i,j,h+3-i-j) for i in range(2) for j in range(3)}
        assert projected_grid_witness(z)
        stretched={(2+4*x,3+7*y,5+3*z) for x,y,z in z}
        assert projected_grid_witness(stretched)

    double=[]
    for s in range(2,31):
        t=double_shape(s);m=len(t)
        P=s*(s-1)*(s+1)//6
        Qz=s*(s-1)*(2*s-1)//6
        lam=s*(s-1)*(s-2)//3
        assert m==s*s
        assert [sum(x[j] for x in t) for j in range(3)]==[P,P,Qz]
        assert 3*m*(s-1)-4*(2*P+Qz)==lam
        claimed=Q((s-1)*(s-2)*(s-3),3)
        assert lam*(m+3)+12*P-m*(m-1)==m*claimed
        a=(m+1,m+s,m+s+1)
        data=apery((m,*a))
        assert data is not None
        assert {x for w,x in data[2]}==t
        r=inspect((m,*a))
        assert r['W']==lam and r['W']>=claimed
        assert r['k']==2*s-1
        assert projection_score(set(map(tuple,r['Z'])),t)==-(s-1)*(s-2)
        assert reconstruct(t) is not None
        double.append(dict(s=s,m=m,k=r['k'],W=r['W'],Phi=r['F'],
                           arbitrary_weight_lower_bound=str(claimed)))

    # The paper proves impossibility for every d>=2; these check its formulas.
    three=[]
    for d in range(2,17):
        t=three_face_shape(d);m=len(t)
        assert m==1+3*d*(d+1)//2
        cc=corners(t)
        assert [p for p in cc if all(p)]==[(1,1,1)]
        assert reconstruct(t) is not None
        heads=sorted(p for p in cc if p[0]>0 and p[1]>0 and p[2]==0)
        assert heads==[(i,d+1-i,0) for i in range(1,d+1)]
        N=d*(d+1)//2
        assert sum(p[0] for p in heads)==sum(p[1] for p in heads)==N
        assert 6*N==2*m-2
        assert (0,0,2) in t
        coordinate_sums=[sum(x[j] for x in t) for j in range(3)]
        assert coordinate_sums==[d*(d+1)*(2*d+1)//6]*3
        three.append(dict(d=d,m=m,full_support_corner=[1,1,1],
                          pair_corner_count=len(heads),pair_coordinate_sum=N))

    # Independent bounded enumeration illustrating the proven family exclusion.
    modular_checks=[]
    for d in (2,3,4):
        t=three_face_shape(d);m=len(t);attempts=0;feasible=[]
        for a,b in combinations(range(1,m),2):
            c=(-a-b)%m
            if c<=b:continue
            attempts+=1
            if not label_collisions(t,(a,b,c)):feasible.append((a,b,c))
        assert not feasible
        modular_checks.append(dict(d=d,m=m,sorted_triples_with_zero_sum=attempts,
                                   feasible_count=0))

    t=three_face_shape(3);a=(30,32,33);m=len(t)
    weights=[sum(v*w for v,w in zip(a,x)) for x in t]
    M=max(weights);sigma=sum(weights);D=3*m*M-4*sigma
    assert (m,M,sigma,D)==(19,99,1330,323)
    assert Q(D-m*(m-1),m)==-1
    assert sum(a)%m==0 and 3*a[0]%m==a[2]%m
    genuine=audit_semigroup((19,*a),lp=lp)
    assert genuine['W']==69
    false_obstruction=dict(m=m,weights=a,M=M,Sigma=sigma,D=D,
        required_D=m*(m-1),formal_W=-1,collisions=label_collisions(t,a),
        genuine_semigroup_W=genuine['W'])

    old={x for x in product(range(7),repeat=3)
         if sum(x)<=4 or (sum(x) in (5,6) and 0 in x)}
    interior=[x for x in corners(old) if all(x)]
    assert len(old)==68 and len(interior)==6 and reconstruct(old) is None

    # Even a genuine staircase can fail a relaxation of its weight constraints.
    small=audit_semigroup((5,6,8,9),lp=lp)
    assert small['W']==4
    if lp:
        assert small['ordered_geometric']['D_min']=='16'
        assert small['ordered_geometric']['margin']=='-4'
        assert small['ordered_geometric']['weights']==['6','11','12']

    output=dict(six_point_bound=dict(compressed_E_max=initial_E_max,
                max_negative_insertions=max_insertions,final_E_max=final_E_max,
                projection_total_max=projection_total_max,multiplicity_max=512),
                double_staircase=double,three_face_exclusion=three,
                bounded_modular_checks=modular_checks,
                false_obstruction=false_obstruction,
                old_68_point_obstruction=dict(m=68,interior_corners=interior),
                genuine_shape_relaxation_failure=small)
    Path('reassessment-exact-checks.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(dict(status='PASS',double_family_instances=len(double),
                         three_face_formula_instances=len(three),
                         bounded_modular_checks=modular_checks,
                         lp_checked=lp,global_Wilf_proof=False)),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--lp',action='store_true')
    args=parser.parse_args()
    main(args.lp)
