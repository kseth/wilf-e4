# Reassessment checks for Wilf in embedding dimension four

Read `wilf_edim4_reassessment_2026-09-05.md` for the mathematical statements and proofs.
This package does not prove or disprove unrestricted Wilf. In particular, it does
not claim that the complete six-point final-window case has been verified.

The new analytic theorem says that any six-point failure of the projection count
criterion has multiplicity at most 512. Its proof uses the forbidden projection
grid and finite Loomis–Whitney inequality; it does not depend on an enumeration
of all six-point shapes.

Run the exact diagnostic fixtures with Python's standard library:

```bash
python verify_reassessment.py
```

For the optional LP checks, install SciPy in your chosen Python environment, then:

```bash
python verify_reassessment.py --lp
python wilf_reassessment.py --random 500 --pair-shapes 500
```

SciPy proposes LP solutions. The code independently verifies the primal and dual
solutions using `fractions.Fraction`; every reported optimum has exact feasibility,
dual-sign, stationarity, and matching-objective checks. Numeric solver output is
never accepted as a certificate without those checks.

To reproduce the exhaustive bounded diagnostic of 82,036 semigroups and 29,633
preferred shapes:

```bash
python scan_ordered_shapes.py --min-m 20 --max-m 40 --multiplier 2
```

This covers exactly `20 <= m <= 40` and `m < a1 < a2 < a3 < 2m`. It says nothing
about other ranges. The script stops at the first failure if one is found.

The small genuine-shape failure of the ordered LP can be reproduced with:

```bash
python scan_ordered_shapes.py --min-m 4 --max-m 25 --multiplier 3 --output ordered-shape-search.json
```

It stops at the shape of `<5,6,8,9>`. The bad LP weights are fictitious labels of
that shape; the semigroup itself satisfies Wilf.

The pair-shape sample in `reassessment-results.json` is exploratory. Its largest
observed failure is not a size cutoff. For example, the three-face shape with
`d=6` has 64 points and also fails the normalized geometric criterion, while the
note proves that no member of that entire shape family is residue-bijective.

`negative_compressed_6.json` and `enumerate_compressed.cpp` are retained from the
preceding research phase as starting data for a future six-point verification.
They are not inputs to the new multiplicity-bound proof. To regenerate the seeds:

```bash
c++ -O3 -std=c++17 enumerate_compressed.cpp -o enumerate_compressed
./enumerate_compressed 6 > negative_compressed_6.json
```

The stored file has 2,264 negative compressed antichains. The new projected-grid
filter excludes 11 of them. Arbitrarily discarding other unrealizable compressed
shapes would require a proof that the reason for exclusion survives stretching.

`wilf_work.py` supplies the exact Apéry calculations from the previous checkpoint.
`reassessment-exact-checks.json` and `reassessment-results.json` store results;
the corresponding run logs record successful completion. The geometric scan's
summary is in `ordered-shape-search-20-40.json`.

`reassessment-SHA256SUMS.json` records the hashes of all other package members.
