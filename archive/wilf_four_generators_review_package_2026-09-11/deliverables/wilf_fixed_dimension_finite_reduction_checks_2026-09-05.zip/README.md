# Wilf research continuation: verification package

The unrestricted four-generator conjecture remains unresolved by this work.
The main manuscript is deliverables/wilf_fixed_dimension_finite_reduction_2026-09-05.md.

## Recheck exact arithmetic and the stored finite certificates

Extract this archive, enter its top directory, and run:

    python3 round2/verify_continuation.py

This uses the Python standard library. It checks the continuous proof's exact
constants, general-dimension constants and simplex counts, the genuine
two-plane example family, and the soundness of the stored six-point modular
and rational LP certificates. It does not prove enumeration completeness or
replace review of the analytic arguments. The recorded run passed all four
checkers; its output is round2/continuation_verification.json.

## Proof dependencies

- Parts I and II of the manuscript are analytic. Audits are in round2/audit.
- The two new six-maxima corollaries use the earlier complete six-point
  theorem. Its proof, enumeration, certificates and full regeneration script
  are in prior/wilf_edim4_six_point_verification_2026-09-05. Full regeneration
  requires Python, SciPy and a C++17 compiler; follow its README-six-point.md.
- The sharper four-generator conductor bound is in
  dependencies/wilf_edim4_global_finite_reduction_2026-09-05.md.
- The critical-exponent cutoff uses boundary/slab_theorem.md.
- Original checkpoints and the reassessment utilities needed by diagnostic
  scripts are retained under prior. Historical claims are superseded where
  the main manuscript explicitly says so.

## Scope of other programs

round2/arithmetic/shell_classification.py is an exhaustive classification of
one explicitly specified 4,095-shape family. Its LP optima are checked using
rational certificates. It is not a classification of all Apéry staircases.
Other search programs are seeded diagnostics; successful samples are not
proofs of universal statements. They may require SciPy and must be run from
this archive's top directory unless their individual notes say otherwise.

round2/assemble_continuation.py regenerates the main manuscript from its
component notes. The archive also retains false proposed lemmas and their
counterexamples so they are not inadvertently reused as proof steps.

SHA256SUMS.json records each other archive member's content hash.
