from itertools import product
h=[[6,5,4],[5,3,3],[4,3,0]]
T=[(x,y,z) for x in range(3) for y in range(3) for z in range(h[x][y])]
m=len(T)
zs=[v for v in T if all(tuple(v[j]+(j==i) for j in range(3)) not in T for i in range(3))]
print(m,zs)
sol=[]
for A,C in product(range(1,m),repeat=2):
 B=(-A-3*C)%m
 if len({(A*x+B*y+C*z)%m for x,y,z in T})==m: sol.append((A,B,C))
print('solutions',sol[:20],len(sol))
