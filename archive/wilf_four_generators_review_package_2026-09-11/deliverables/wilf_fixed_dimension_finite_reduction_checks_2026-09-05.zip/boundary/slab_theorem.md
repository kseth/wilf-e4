# A slab bound and finite reduction for every fixed compressed staircase

Research note, 5 September 2026. This is a proved sufficient criterion and a finite reduction under fixed combinatorial shape. It does not prove unrestricted Wilf. No literature-priority claim is made.

## 1. Setup

Let `d=e−1≥2`, and let `T⊂N^d` be any finite lower ideal, with positive weights `a_1,…,a_d`. Write

\[
m=|T|,\quad w(x)=a\cdot x,\quad M=\max_Tw,\quad
D=d mM-(d+1)\sum_Tw.
\]

For coordinate direction `j`, let
\[
D_j=\sum_{\ell\parallel e_j}|\ell|\,[M-w(t_\ell)].
\]
The coordinate-line identity gives `D=Σ_jD_j`, with every `D_j≥0`.

If `T` is a preferred Apéry staircase of a minimally e-generated numerical semigroup with multiplicity `m`, then `a_j≥m+1`, and
\[
mW_e=D-\frac{d-1}{2}m(m-1).
\]
All geometric inequalities below precede, and do not require, residue bijectivity.

## 2. Exact decomposition into slabs

Fix a coordinate `i` with weight `b=a_i`. Write the nonempty nested slices perpendicular to it as `F_z`. Partition them into maximal consecutive runs of identical slices. A run is described by

- initial level `r`;
- length `L≥1`;
- the common `(d−1)`-dimensional lower ideal `F`, of size `A`.

Let `v` denote the weight in the other coordinates, and put
\[
M_F=\max_Fv,\quad\Sigma_F=\sum_Fv,\quad
\delta_F=(d-1)AM_F-d\Sigma_F\ge0,
\]
\[
g_F=M-M_F-b(r+L-1)\ge0.
\]
The nonnegativity of `δ_F` is the coordinate-line identity in dimension `d−1`. The last slice of the run contains a point of weight `M_F+b(r+L−1)`, proving `g_F≥0`.

At slice `r+s`, the sum of all coordinate-line contributions in the directions other than `i` is
\[
(d-1)A[M-b(r+s)]-d\Sigma_F
=\delta_F+(d-1)A g_F+(d-1)Ab(L-1-s).
\]
Summing `s=0,…,L−1` and then the runs gives the exact identity
\[
\boxed{D-D_i=\sum_{\text{runs}}\left[
L\delta_F+(d-1)ALg_F+\frac{d-1}{2}AbL(L-1)\right].}
\]
Define
\[
P_i=\sum_{\text{runs}} A L(L-1).
\]
Every omitted term is nonnegative, so
\[
\boxed{D-D_i\ge\frac{d-1}{2}a_iP_i.}\tag{1}
\]
Summing over all `i`, each `D_j` occurs exactly `d−1` times on the left. Therefore
\[
\boxed{2D\ge\sum_{i=1}^d a_iP_i.}\tag{2}
\]

## 3. Wilf consequences

For an Apéry staircase, equation (1) implies
\[
mW_e\ge\frac{d-1}{2}\left[(m+1)P_i-m(m-1)\right].
\]
Thus `P_i≥m−2` implies Wilf: the displayed bound gives `mW_e≥−(d−1)`, and `m≥d+1` excludes a negative integer `W_e`. Also, `P_i≥m−1` implies `W_e≥1`, and `P_i≥m` implies `W_e≥d−1=e−2`.

A direction with projection size `A` and shortest column length `h` has an initial run of length `h`. Consequently
\[
\boxed{Ah(h-1)\ge m-2\quad\Longrightarrow\quad W_e\ge0.}\tag{3}
\]
This strengthens the checkpoint's sufficient criterion `2A(h−1)≥m`. For `h≥2`, `h(h−1)≥2(h−1)`, and improvement is strict for `h>2`. The new required bottom thickness grows like the square root of the mean column length. The full statistic `P_i` also uses runs above the bottom, and so handles long insertions on proper subsets of columns.

In dimension four, (2) additionally gives
\[
\boxed{\sum_{i=1}^3 a_iP_i\ge2m(m-1)\quad\Longrightarrow\quad W_4\ge0.}\tag{4}
\]

## 4. Every fixed compressed shape admits a finite reduction

For each coordinate `i`, take the distinct values `z_i+1` at the coordinatewise maximal points `z` of `T`, together with zero. These partition the coordinate range into consecutive intervals. Every Cartesian product of these intervals lies either entirely in `T` or entirely outside it, since `T` is the union of the boxes `[0,z]`.

These coordinate intervals are exactly the constant-slice runs used above. Indeed, a maximal point `z` forces a change after slice `z_i`, because its projection is present there and cannot be present at `z_i+1`. Conversely any slice change has a disappearing projected point; extend its top to a maximal point, whose `i`-coordinate must equal that top level.

Call each occupied Cartesian product a cell, and let `K` be the number of occupied cells. Replacing each interval by one coordinate level gives a compressed lower ideal with `K` points. Its pattern remains fixed under arbitrary positive integer changes to all interval lengths.

For a cell with side lengths `L_1,…,L_d`, let `v=∏_iL_i` be its volume. The slab definition gives exactly
\[
\sum_iP_i=\sum_{\text{cells}}v\left(\sum_iL_i-d\right).\tag{5}
\]

For positive integer lengths,
\[
\boxed{v\left(2d+1-\sum_iL_i\right)\le2^d.}\tag{6}
\]
To prove this, write `Σ_iL_i=d+r`. For `r≥d+1` the left side is nonpositive. For `0≤r≤d`, integer balancing gives `v≤2^r`: the maximum product consists of `r` lengths equal to 2 and the remaining lengths equal to 1. The left side is therefore at most `(d+1−r)2^r≤2^d`, the last inequality being `u+1≤2^u` for `u=d−r≥0`.

Summing (6) and using (5) proves
\[
\boxed{\sum_iP_i\ge(d+1)m-2^dK.}\tag{7}
\]
Combining with (2) and `a_i≥m+1`,
\[
\boxed{mW_e\ge m^2+d m-2^{d-1}K(m+1).}\tag{8}
\]
In particular:

1. If `m≥2^(d−1)K`, then `W_e≥d−1`.
2. If `m≥2^(d−1)K−d+1`, then the right side of (8) is at least `−(d−1)`. Since `m≥e=d+1` and `mW_e` is an integer multiple of `m`, a negative Wilf number is impossible.

Hence
\[
\boxed{e=4,\quad m\ge4K-2\quad\Longrightarrow\quad W_4\ge0.}\tag{9}
\]
For each fixed compressed pattern, a counterexample therefore requires `m≤4K−3`. There are only finitely many positive integer interval lengths producing that many points; consequently arbitrary simultaneous coordinate stretches reduce to finitely many actual lower ideals.

If there are `q` maximal points, each coordinate has at most `q` intervals, so `K≤q^d`. In dimension four this gives the coarse necessary condition `m≤4q^3−3` for a counterexample. This counts all maximal points of the selected factorization staircase. It neither bounds that number universally nor equates it with numerical-semigroup type or the final-window cardinality.

## 5. Exact examples separating the criteria

### Stronger initial-run criterion

For `S=⟨23,98,258,272⟩`, exact preferred Apéry computation gives `c=838`, `W=670`.

| Direction weight | Projection size A | Shortest length h | Old 2A(h−1) | New Ah(h−1) |
| --- | ---: | ---: | ---: | ---: |
| 98 | 5 | 3 | 20 | 30 |
| 258 | 17 | 1 | 0 | 0 |
| 272 | 13 | 1 | 0 | 0 |

The old criterion fails in every direction. The new criterion succeeds in the 98 direction.

### Runs above the bottom

For `S=⟨27,232,302,314⟩`, exact preferred Apéry computation gives `c=1764`, `W=1560`.

| Weight | A | h | Old 2A(h−1) | New bottom Ah(h−1) | Full P_i |
| --- | ---: | ---: | ---: | ---: | ---: |
| 232 | 14 | 1 | 0 | 0 | 0 |
| 302 | 10 | 2 | 20 | 20 | 32 |
| 314 | 11 | 1 | 0 | 0 | 48 |

Both bottom criteria fail in all directions. In the 314 direction, the slice runs `(r,L,A)` are `(0,1,11)` and `(1,4,4)`, giving `P_i=48≥27`. This illustrates the additional gain from a long run on a proper subset of columns.

These examples demonstrate a stronger criterion relative to the checkpoint; they are not claimed as semigroups previously unknown to satisfy Wilf.

## 6. Verification and remaining limitation

`slab_bound.py` verifies the exact decomposition, its inequalities, and the Apéry moment formula by integer arithmetic. The initial run checked 300 random lower ideals in dimensions 3, 4, and 5, together with 25 minimally four-generated semigroups, producing ten examples where the old theorem fails in all axes and the new theorem succeeds. These computations are checks of an analytic proof, not proof of a universal conclusion.

The finite reduction applies after fixing the compressed staircase pattern. The number and structure of compressed patterns remain unbounded. In particular, shapes whose slices change at every level can have `P_i=0`. Bounding the remaining compressed patterns or controlling their moment slack still requires a new argument.

Independent audit: the full-weighted agent checked the slab decomposition, compressed-cell identity, discrete product bound, and integer endpoint. The weaker single-direction threshold `P_i≥m−2` was added following that audit.

## 7. A seven-point zero-insertion family is arithmetically impossible

This secondary lemma illustrates why the lattice condition remains useful beyond six points. For each integer `t≥0`, consider the height array

\[
\begin{pmatrix}
t+6&t+5&t+4\\
t+5&t+3&t+3\\
t+4&t+3&0
\end{pmatrix}.
\]

The resulting lower ideal has `m=8t+33` points, one interior minimal excluded point `(1,1,t+3)`, and seven maximal points. Their two-coordinate projection has maxima 2 and 2, so translating all seven maximal points by one in the height direction changes the projection-count score by `2+2+3−7=0`.

Nevertheless no member of this infinite family admits residue-bijective linear labels modulo its size. Suppose the coordinate residues are `A,B,C`. The two mixed minimal corners in the `xz` plane are `(1,0,t+5)` and `(2,0,t+4)`. Their representatives lie on the y-axis, are distinct, and cannot be zero: both corner supports intersect that of the interior corner, whose representative must be zero. They therefore represent a permutation of the only two nonzero y-axis points. Summing gives

\[
3A+(2t+9)C\equiv3B\pmod m.
\]

The symmetric `yz` argument gives
\[
3B+(2t+9)C\equiv3A\pmod m.
\]

Adding and doubling implies `(8t+36)C≡0`. Since `m=8t+33`, this gives `3C≡0`. But `0` and `3e_z` both lie in the ideal, contradicting residue injectivity.

This generalizes a specific obstruction beyond the six-point argument, using the same saturated-axis-permutation mechanism as the checkpoint's three-face exclusion. It is not required for the slab theorem.
