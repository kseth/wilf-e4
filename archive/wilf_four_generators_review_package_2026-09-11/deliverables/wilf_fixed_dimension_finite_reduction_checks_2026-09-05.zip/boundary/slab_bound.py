from heapq import heappop,heappush
from itertools import combinations
from collections import defaultdict
from random import Random
import json

def apery(m,a):
 d=len(a);N=10**30;dist=[N]*m;fac=[None]*m
 dist[0]=0;fac[0]=(0,)*d;pq=[(0,fac[0],0)]
 while pq:
  w,x,r=heappop(pq)
  if (w,x)!=(dist[r],fac[r]):continue
  for j,b in enumerate(a):
   v=w+b;s=v%m;y=tuple(x[k]+(k==j) for k in range(d))
   if v<dist[s] or (v==dist[s] and y<fac[s]):dist[s]=v;fac[s]=y;heappush(pq,(v,y,s))
 if N in dist:return None
 if any(tuple(int(k==j) for k in range(d)) not in fac for j in range(d)):return None
 return set(fac),dist

def check(T,a):
 d=len(a);m=len(T);w=lambda x:sum(v*b for v,b in zip(x,a));M=max(map(w,T));D=d*m*M-(d+1)*sum(map(w,T))
 Ps=[];old=[];bottom=[];details=[];Ds=[]
 for i,b in enumerate(a):
  cols=defaultdict(list)
  for x in T:cols[x[:i]+x[i+1:]].append(x[i])
  A=len(cols);h=min(map(len,cols.values()));old.append(2*A*(h-1)>=m);bottom.append(A*h*(h-1)>=m-1)
  slices=[]
  for z in range(max(map(len,cols.values()))):
   slices.append(frozenset(u for u,c in cols.items() if len(c)>z))
  blocks=[];r=0
  while r<len(slices):
   s=r+1
   while s<len(slices) and slices[s]==slices[r]:s+=1
   blocks.append((r,s-r,slices[r]));r=s
  P=sum(len(F)*L*(L-1) for r,L,F in blocks);Ps.append(P)
  Di=sum(len(c)*(M-w(u[:i]+(max(c),)+u[i:])) for u,c in cols.items());Ds.append(Di)
  total=Di
  aa=a[:i]+a[i+1:]
  for r,L,F in blocks:
   vals=[sum(v*b for v,b in zip(u,aa)) for u in F];A0=len(F);MF=max(vals);SF=sum(vals)
   delta=(d-1)*A0*MF-d*SF;gap=M-MF-b*(r+L-1)
   assert delta>=0 and gap>=0
   total+=L*delta+(d-1)*A0*L*gap+(d-1)*A0*b*L*(L-1)//2
  assert total==D,(T,a,D,total)
  assert 2*D>=(d-1)*b*P
  details.append({'direction':i,'A':A,'h':h,'P':P,'blocks':[(r,L,len(F)) for r,L,F in blocks]})
 assert sum(Ds)==D
 assert 2*D>=sum(a[i]*Ps[i] for i in range(d))
 return D,Ps,old,bottom,details

if __name__=='__main__':
 rng=Random(963017);examples=[];cnt=0
 for trial in range(20000):
  m=rng.randrange(10,151);a=tuple(sorted(rng.sample(range(m+1,12*m),3)))
  ans=apery(m,a)
  if ans is None:continue
  T,dist=ans;cnt+=1;D,Ps,old,bottom,details=check(T,a)
  c=max(dist)-m+1;W=(D-m*(m-1))//m
  if (not any(old)) and (any(bottom) or max(Ps)>=m-1):
   examples.append({'generators':(m,)+a,'m':m,'c':c,'W':W,'D':D,'P':Ps,'old':old,'bottom':bottom,'details':details})
   if len(examples)>=10:break
 randomcnt=0
 for d in [3,4,5]:
  for trial in range(100):
   maxima=[tuple(rng.randrange(1,5) for _ in range(d)) for _ in range(5)]
   from itertools import product
   T=set()
   for z in maxima:T.update(product(*[range(v+1) for v in z]))
   a=tuple(rng.randrange(1,30) for _ in range(d));check(T,a);randomcnt+=1
 result={'semigroups_checked':cnt,'random_ideals_checked':randomcnt,'examples':examples}
 print(json.dumps(result,indent=2))
 with open('/workspace/scratch/a8c8677e5545/boundary/slab_bound_results.json','w') as f:json.dump(result,f,indent=2)
