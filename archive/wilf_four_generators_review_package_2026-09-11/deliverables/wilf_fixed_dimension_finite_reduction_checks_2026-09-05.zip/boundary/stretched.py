from itertools import product
for t in range(0,51):
 h=[[6+t,5+t,4+t],[5+t,3+t,3+t],[4+t,3+t,0]]
 T=[(x,y,z) for x in range(3) for y in range(3) for z in range(h[x][y])];m=len(T)
 sol=[]
 for C in range(1,m):
  for A in range(1,m):
   B=(-A-(3+t)*C)%m
   if len({(A*x+B*y+C*z)%m for x,y,z in T})==m:sol.append((A,B,C))
 if sol: print(t,m,sol[:5],flush=True)
print('done')
