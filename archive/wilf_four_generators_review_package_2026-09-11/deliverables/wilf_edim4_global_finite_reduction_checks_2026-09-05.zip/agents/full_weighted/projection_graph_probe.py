from random import Random
from itertools import product
R=Random(12987)
def shape(n):
    # Three arbitrary two-dimensional lower-ideal restrictions.
    h=[]
    for _ in range(3):
        v=sorted([R.randrange(1,n+1) for _ in range(n)],reverse=True)
        h.append(v)
    p=tuple(R.randrange(1,n) for _ in range(3)) if R.randrange(2) else (n,n,n)
    T={(x,y,z) for x,y,z in product(range(n),repeat=3) if y<h[0][x] and z<h[1][x] and z<h[2][y] and not all(q>=r for q,r in zip((x,y,z),p))}
    return T,p
bad=[]; best=-100
for _ in range(10000):
    T,p=shape(R.randrange(3,13))
    Z={t for t in T if all(tuple(q+(j==k) for j,q in enumerate(t)) not in T for k in range(3))}
    for j in range(3):
        ks=[k for k in range(3) if k!=j]
        for cut in sorted({t[j] for t in Z}):
            H=[t for t in Z if t[j]>=cut]
            v=sum(len({t[k] for t in H}) for k in ks)
            excess=len(H)-v
            if excess>best:
                best=excess; witness=(sorted(Z),j,cut,p)
            if excess>0:
                bad.append((excess,witness))
                break
print('maximum edges-minus-vertices:',best,'witness:',witness,'bad count:',len(bad))
