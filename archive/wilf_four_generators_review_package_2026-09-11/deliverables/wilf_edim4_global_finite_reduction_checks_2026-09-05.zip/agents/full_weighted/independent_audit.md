# Independent audits: slab reduction and explicit stability

Audit performed by the `full_weighted` agent, 5 September 2026. This is an internal mathematical audit, not external peer review and not a claim that unrestricted Wilf is proved.

## 1. Slab theorem

Reviewed `/workspace/scratch/a8c8677e5545/boundary/slab_theorem.md`.

**Result: no gap found.** The exact decomposition of \(D-D_i\), its nonnegative terms, the summed inequality \(2D\ge\sum_i a_iP_i\), the integer cell inequality, and the endpoint \(m\ge4K-2\) are valid.

One explanatory detail should be explicit: the distinct maximal-point coordinates \(z_i+1\) are precisely the places where slices in direction \(i\) change. At a maximal point \(z\), its projection occurs in slice \(z_i\), and cannot occur in slice \(z_i+1\), since that would dominate \(z\). Conversely, every column ending can be extended in the other directions to a maximal point with the same coordinate \(i\). Thus the cell decomposition agrees with the slab runs and the claimed exact cell identity holds.

The single-direction threshold can be strengthened to \(P_i\ge m-2\): the displayed lower bound then gives \(mW_e\ge-(d-1)\), while \(mW_e\) is an integer multiple of \(m\ge d+1\). A negative value is impossible. The threshold \(P_i\ge m-1\) actually yields \(W_e\ge1\).

The one-interior-corner condition alone does not give universally strict growth of the earlier projection score under coordinate insertion. For example,

\[
Z=\{(0,1,4),(0,2,3),(0,3,2),(1,0,3),(1,3,0),
(2,0,2),(2,2,0),(3,0,1),(3,1,0)\}
\]

has a 32-point completion obtained by taking its pairwise closure and removing the orthant at \((1,1,1)\). Every element of \(Z\) remains maximal. Translating all third coordinates upward gives score increment \(3+3+3-9=0\).

A negative-increment example is

\[
\begin{split}
Z=\{&(0,0,7),(0,2,4),(0,3,3),(0,4,2),(1,0,6),(1,1,5),\\
&(2,1,3),(2,4,0),(3,1,2),(3,3,0),(4,1,1),(4,2,0)\}.
\end{split}
\]

Its analogous completion removes \((1,2,1)+\mathbb N^3\) and has 66 points. The same insertion gives increment \(4+4+3-12=-1\). These are geometric fixtures, with no claim of Apéry realizability. Exact construction scripts are in this audit directory.

## 2. Qualitative stability theorem

Reviewed `/workspace/scratch/a8c8677e5545/stability/uniform_gap_draft.md`.

**Result: no gap found.** In particular:

1. The line-deficit expectations are \(E\delta_j=1-\mu-\mu_j\), with nonnegative deficits summing in expectation to \(\kappa\). Hence \(\mu_j\to1/4\) if \(\kappa\to0\).
2. In the shift argument, the deficit difference is \(-s\) modulo the coarse step \(u_j\), and \(0<s\le u_j/2\). Its absolute value is therefore at least \(s\). The paired sum counts each point at most twice. This validates the argument forcing every lattice step to zero.
3. Thickening and rescaling preserve lower closure and the exclusion-by-orthants description exactly under half-open pixel conventions.
4. Slicing by the minimum coordinate gives planar lower ideals after translation, validating \(\mu_K\le2/3+E\min_jX_j\). This prevents volume collapse at centroid \(3/4\).
5. Monotone-indicator compactness is valid. Equality at centroid \(3/4\) forces the full simplex.
6. The two outside points and their interior projection witnesses force two full-support exclusion corners unless their minimum is excluded. Their minimum lies inside the simplex. This contradiction is valid and robust under grid-boundary conventions.

For item 5, an alternative equality proof is radial integration. A positive-volume downset contains a positive cube and is star-shaped. Its radial extent \(R(\theta)\) in every positive simplex direction is positive and at most one. Radial integration expresses the centroid as \((3/4)(\int R^4)/(\int R^3)\). Equality forces \(R=1\) almost everywhere, hence the entire simplex up to null sets.

## 3. Explicit stability theorem

Reviewed `/workspace/scratch/a8c8677e5545/stability/explicit_gap_draft.md`.

**Result: no gap found, including all numerical constants.**

The propagation argument's three lower bounds are

\[
J_x\ge6.03\cdot10^{-6},\quad
J_y\ge8.1\cdot10^{-7},\quad
J_z\ge1.6875\cdot10^{-7}.
\]

Since the volume is at most \(1/6\), even the weakest bound gives \(\kappa_c\ge1.0125\cdot10^{-6}>10^{-6}\). The required fiber lower and upper endpoints follow respectively from a dominating included point and a dominated excluded point on each specified rectangle. All seven target points meet the stated coordinate and total-coordinate bounds.

For the phase estimate, \(v\le U/20\) implies \(v\le s_0/2\), where \(s_0=\min(U/4,1/10)\), using \(U\le1\). Under \(\kappa\le1/15\), the minimum-step coordinate mean is at least \(1/5\). Thus the paired-deficit argument indeed gives \(U\le400\kappa\) in that branch, and consequently \(U\le400\kappa+20v\) in all cases.

The exact thickening relation is

\[
\kappa_c=\frac{\kappa+s}{1+s}\le1201\kappa+60v.
\]

Cardinality gives \(v\le((6m)^{1/3}-3)^{-1}\). For \(m\ge10^{27}\), this is less than \(6\cdot10^{-10}\), and the proposed contradiction proves \(\kappa\ge6\cdot10^{-10}\).

For a genuine four-generator Apéry staircase,

\[
\frac D{m^2}=\kappa\frac M m>
(6\cdot10^{-10})(1.8\cdot10^9-3)
=1.08-1.8\cdot10^{-9}>1.
\]

Therefore the claimed cutoff is valid: any four-generator Wilf counterexample must have multiplicity below \(10^{27}\). Combining it with the separately proved analytic conductor cutoff gives a finite generator search region. The enormous remaining region has not been verified, so unrestricted Wilf remains unproved by these results.
