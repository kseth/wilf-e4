Z=[(0,0,11),(0,3,8),(0,4,7),(0,5,6),(0,6,5),(0,7,4),(0,8,2),(0,10,1),(1,11,0),(2,0,10),(2,1,9),(3,1,8),(3,8,0),(4,1,7),(5,1,5),(5,7,0),(6,1,4),(6,6,0),(8,5,0),(9,1,3),(10,1,2),(10,4,0),(11,0,0)]
def excess(Z):return len(Z)-len({p[0] for p in Z})-len({p[1] for p in Z})
from random import Random
R=Random(897)
best=Z
for _ in range(10000):
    U=Z.copy();R.shuffle(U)
    for p in U.copy():
        W=[q for q in U if q!=p]
        if excess(W)>=1:U=W
    if len(U)<len(best):best=U
lev=[sorted({p[i] for p in best}) for i in range(3)]
C=sorted(tuple(lev[i].index(p[i]) for i in range(3)) for p in best)
print('original',sorted(best),'compressed',C,'k',len(C),'excess',excess(C))
# Complete using pair projections, one corner. Direct search allowed dimensions small.
from itertools import product
projs=[{tuple(p[i] for i in range(3) if i!=j) for z in C for p in product(*[range(t+1) for t in z])} for j in range(3)]
V={p for p in product(*[range(max(z[i] for z in C)+1) for i in range(3)]) if all(tuple(p[i] for i in range(3) if i!=j) in projs[j] for j in range(3))}
for corner in product(*[range(1,max(z[i] for z in C)+1) for i in range(3)]):
    T={p for p in V if not all(x>=y for x,y in zip(p,corner))}
    if set(C)<=T and all(tuple(x+(i==j) for i,x in enumerate(p)) not in T for p in C for j in range(3)):
        print('completion corner',corner,'size',len(T));break
