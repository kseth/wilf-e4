# Analytic full-weighted Apéry theorem in embedding dimension four

**Status:** Complete analytic proof of a sufficient class and of the previously conditional quadratic conductor reduction. This does not prove unrestricted Wilf in embedding dimension four. No priority claim.

Let \(S=\langle m,a,b,d\rangle\) be minimally generated, with \(m<a<b<d\), conductor \(c\), \(n=|S\cap[0,c)|\), and \(W=4n-c\). Let \(T\subset\mathbb N^3\) be the preferred Apéry factorization lower ideal, \(|T|=m\), with weight \(w(x,y,z)=ax+by+dz\). Its labels are bijective modulo \(m\). Write

\[
M=\max_Tw=c+m-1,\qquad \Sigma=\sum_Tw,\qquad D=3mM-4\Sigma.
\]

The coordinate-line identity and genus identity are

\[
D=\sum_{\ell}L_\ell(M-w(t_\ell)),\qquad mW=D-m(m-1).
\tag{1}
\]

## 1. Full weighted staircases satisfy Wilf

**Theorem.** If \(T=\{x\in\mathbb N^3:w(x)\le M\}\), then \(W\ge0\).

The uniform-conductor checkpoint already proves that the projection of a full weighted staircase onto its last two coordinates is one of:

\[
\{(0,0),(1,0),(0,1)\},\qquad
\{(0,0),(1,0),(2,0),(0,1)\},\qquad
\{(y,z):y+z\le2\}.
\tag{2}
\]

That classification uses only residue bijectivity and the following elementary support fact. For any minimal excluded point \(p\), its residue representative \(q\in T\) has support disjoint from \(p\). Otherwise subtracting a coordinate present in both gives two distinct points of \(T\) with equal residues. Likewise, minimal excluded points with intersecting supports have different residues. An interior minimal excluded point consequently represents zero and is unique.

### 1.1 Excluding the six-column triangle

Here is an independently derived short exclusion. Let the column lengths at \((y,z)=(0,0),(1,0),(2,0),(0,1),(1,1),(0,2)\) be \(A,B,C,F,E,G\), respectively. They are positive. The full weighted condition gives

\[
A>B>C,\qquad A>F>G,\qquad E<\min(B,F).
\]

Work in \(\mathbb Z/m\mathbb Z\), writing the weights with the same letters \(a,b,d\), and let \(r\) be the order of \(a\). The interior minimal excluded point \((E,1,1)\) gives

\[
Ea+b+d=0.
\tag{3}
\]

Thus the origin and mixed columns are disjoint sets of residues in the subgroup \(\langle a\rangle\), and \(r\ge A+E\).

The two minimal excluded points \((B,1,0),(C,2,0)\) have representatives permuting \(d,2d\). Neither can represent zero because its support meets the interior point's support. There are two cases.

* If \(Ba+b=2d\) and \(Ca+2b=d\), then eliminating \(b,d\) with (3) yields
  \[
  (B-C+E)a=0.
  \]
  But \(0<B-C+E<A+E\le r\), impossible.
* Therefore \(Ba+b=d\) and \(Ca+2b=2d\). The same argument with \(b,d\) interchanged forces \(Fa+d=b\) and \(Ga+2d=2b\). Consequently all three positive integers
  \[
  B+F,\qquad 2B-C,\qquad 2F-G
  \]
  are multiples of \(r\). Each is less than \(2A\le2r\), so each equals \(r\). Adding the last two and comparing with twice the first gives \(C+G=0\), contradicting positivity.

Thus the third projection in (2) is impossible. This argument actually excludes every residue-bijective lower ideal with that projection and the stated strict column descents; exact floor formulas are unnecessary.

### 1.2 An analytic boundary inequality

For completeness, the sufficient estimate used below has no finite enumeration input. Put

\[
Z=\{x\in T:M-w(x)<m\},\quad k=|Z|,\quad
P(T)=\sum_{j=1}^3|\pi_jT|,
\]

\[
E(Z)=\sum_{z\in Z}|z|_1-\sum_{j=1}^3\max_{z\in Z}z_j,
\quad \Phi(T,Z)=P(T)-3k-E(Z).
\]

Every point of \(Z\) is maximal, since all generator weights exceed \(m\). Then

\[
\boxed{mW\ge m\Phi(T,Z)+E(Z).}
\tag{4}
\]

To prove it, for a line in direction \(j\) write its top deficit as \(mq+\beta\), \(0\le\beta<m\). With \(A_j=[a_j]_m\), set

\[
R=\sum_{s=0}^{L-1}[sA_j]_m,\qquad
C=|\{0\le s<L:[sA_j]_m+\beta\ge m\}|.
\]

The sum of the residues of point deficits on that line is \(L\beta+R-mC\). Each direction partitions \(T\), whose deficit residues are complete modulo \(m\). Therefore (1) gives

\[
mW=\binom m2+\sum_\ell(mL_\ell q_\ell+mC_\ell-R_\ell).
\]

A line whose top is outside \(Z\) has \(q\ge1\). Its axis residues are distinct, so \(R\le m(L-1)-\binom L2\), and its summand is at least \(m\). There are \(P(T)-3k\) such lines. For lines with tops in \(Z\), discard their nonnegative carry terms. Across these lines, pay once for every distinct positive axis residue from \(\binom m2\). Axis points in different directions have distinct residues because they are distinct points of \(T\). The number of remaining copies is exactly \(E(Z)\), each costing at most \(m-1\). This proves (4).

### 1.3 The two axis projections

Let \(K=\operatorname{Max}(T)\). For any subset \(Z\subseteq K\), both \(|Z|\le|K|\) and \(E(Z)\le E(K)\): in each coordinate, adding a point increases the sum at least as much as it increases the maximum. Thus

\[
\Phi(T,Z)\ge\Phi(T,K).
\tag{5}
\]

For the three-column projection, let the lengths be \(A,B,C\) at \((0,0),(1,0),(0,1)\). Full weightedness gives \(A>B,C\ge1\), so the three column tops are precisely \(K\), and \(A\ge2\). Direct counting gives

\[
m=A+B+C,\quad P(T)=3+2A+B+C=3+A+m,
\]
\[
E(K)=m-A-2,\qquad \Phi(T,K)=2A-4\ge0.
\]

For the four-column projection, let the lengths be \(A,B,C,F\) at \((0,0),(1,0),(2,0),(0,1)\). Full weightedness gives \(A>B>C\ge1\), \(A>F\ge1\). Again the column tops are precisely \(K\), and \(A\ge3\). Now

\[
m=A+B+C+F,\quad P(T)=4+2A+B+C+F=4+A+m,
\]
\[
E(K)=m-A-2,\qquad \Phi(T,K)=2A-6\ge0.
\]

Equations (4) and (5) prove \(W\ge0\) in both cases, completing the theorem.

## 2. Consequence: an entirely analytic quadratic reduction

If \(p\) is a minimal excluded exponent with \(w(p)\le M\), its predecessor coordinate lines contribute exactly

\[
\sum_{j:p_j>0}p_j\bigl(M-w(p-e_j)\bigr)
=M+(|p|_1-1)(M-w(p))\ge M.
\]

Their contributions are distinct for different minimal excluded points. Thus, if \(H\) such points exist,

\[
D\ge HM+\sum_{\substack{p\text{ minimal excluded}\\w(p)\le M}}
(|p|_1-1)(M-w(p)).
\tag{6}
\]

If \(W<0\), the theorem shows that the staircase is not full weighted, so \(H\ge1\). Integrality and (1) give \(D\le m(m-2)\), whence

\[
M\le m(m-2),\qquad
\boxed{c\le m^2-3m+1},\qquad
\boxed{d\le m(m-2)}.
\]

More generally, a putative counterexample with \(H\) low-weight minimal excluded points satisfies

\[
\boxed{c\le\left\lfloor\frac{m(m-2)}{H}\right\rfloor-m+1}.
\]

The extra nonnegative sum in (6) strengthens this further when omitted corners are substantially below \(M\). No universal lower bound \(H\ge2\) is established here, and these estimates do not bound multiplicity.

## 3. Audit and provenance

The six-column exclusion was obtained independently by the `alternate` and `full_weighted` agents in this turn. The proof printed in Section 1.1 is the stronger strict-descent variant from `alternate`, independently audited by `full_weighted`. The axis computation and removal of the finite dependency were derived by `full_weighted`. The projection estimate is re-derived from the earlier checkpoint to make its lack of computational input explicit.

The preceding uniform-conductor checkpoint supplies the elementary projection classification (2), the line identity, and its Apéry application. The present proof removes the sole invocation of its six-point computer-assisted theorem. It does not establish priority in the literature or a solution of the remaining unbounded family.
