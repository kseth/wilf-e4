# Wilf e=4: global finite-reduction research package

The authoritative report is `wilf_edim4_global_finite_reduction_2026-09-05.md` at the archive root.

The unrestricted conjecture remains unresolved. The main proved result here is Wilf for every minimally four-generated numerical semigroup with multiplicity at least 10^27. Combined with the analytic conductor bound, all possible counterexamples lie in one finite but enormous generator region. That region has not been exhaustively verified.

## Contents

- `root_research/check_exact.py`: standard-library exact rational verification of all proof constants, plus independent Apéry and direct-membership computations for six examples.
- `root_research/exact_check_results.json`: recorded successful output.
- `stability/`: development drafts of the qualitative and explicit stability arguments. The integrated report supersedes their provisional wording and fills in their standalone definitions.
- `agents/full_weighted/`: analytic conductor argument and an independent mathematical audit.
- `alternate/`: independent triangle exclusion, independent stability audit, and a rigorously verified infinite family disproving a tempting stronger inequality.
- `boundary/`: slab theorem, exact diagnostics, and results.
- `root_research/geometry_probe.py`: exploratory geometric LP diagnostics, not proof input. Requires SciPy and the included two helper modules under `prior/`.

Run the exact check from the archive root:

```sh
python3 root_research/check_exact.py
```

This verifies the recorded constants and examples. It does not mechanically certify the analytic proof, and it does not enumerate the residual counterexample region.

The report contains the complete mathematical dependencies of the main results. None of its main theorems depends on a random sample or the earlier six-point finite enumeration. No claim of external peer review or publication priority is made.
