"""Exact diagnostic: a counterexample to D >= (m-1) * a_min, not to Wilf."""
from heapq import heappop, heappush
import json
from pathlib import Path

T = {(0,0,0),(1,0,0),(0,1,0),(0,0,1),(2,0,0),(0,2,0),(1,0,1),(0,1,1)}
C = {(3,0,0),(0,3,0),(0,0,2),(1,1,0),(2,0,1),(0,2,1)}

def apery(gens):
    m = gens[0]
    dist = [None]*m
    dist[0] = 0
    queue = [(0,0)]
    while queue:
        distance, residue = heappop(queue)
        if distance != dist[residue]:
            continue
        for a in gens[1:]:
            candidate = distance+a
            target = candidate % m
            if dist[target] is None or candidate < dist[target]:
                dist[target] = candidate
                heappush(queue, (candidate,target))
    return dist

rows=[]
for q in (1,2,3,4,10,100,10**6):
    gens=[8,8*q+1,8*q+3,8*q+4]
    weights=gens[1:]
    dot=lambda p:sum(x*a for x,a in zip(p,weights))
    labels={dot(p)%8:dot(p) for p in T}
    assert set(labels)==set(range(8))
    assert all(dot(p)>labels[dot(p)%8] for p in C)
    ap=apery(gens)
    assert set(ap)==set(labels.values())
    M=max(ap)
    Sigma=sum(ap)
    D=3*8*M-4*Sigma
    genus_numerator=2*Sigma-8*7
    assert genus_numerator%16==0
    genus=genus_numerator//16
    c=M-7
    n=c-genus
    W=4*n-c
    assert (M,Sigma,D,c,n,W)==(16*q+7,88*q+28,32*q+56,16*q,5*q,4*q)
    rhs=7*weights[0]
    assert D-rhs==49-24*q
    rows.append(dict(q=q,generators=gens,apery=sorted(ap),M=M,Sigma=Sigma,D=D,rhs=rhs,c=c,n=n,W=W))

out=Path(__file__).with_name('stronger_amin_bound_counterexample.json')
out.write_text(json.dumps({'status':'Exact finite diagnostics for analytically proved infinite family','rows':rows},indent=2)+'\n')
print(json.dumps(rows[2],indent=2))
print('All exact diagnostic checks passed.')
