# Failure of the proposed stronger minimum-generator bound

The proposed sufficient inequality

`D >= (m-1) a_min`

is false, even for genuine minimally four-generated numerical semigroups whose Apéry staircase has no interior excluded corner. This does **not** refute Wilf's inequality.

Take `S=<8,25,27,28>`. Its Apéry set modulo 8 is

`{0,25,27,28,50,53,54,55}`.

Consequently `M=55`, `Sigma=292`, `D=3*8*55-4*292=152`, whereas `(m-1)a_min=7*25=175`. The semigroup has `c=48`, `n=15`, and `W=4n-c=12>0`.

## An infinite family

For every integer `q>=1`, let

`S_q=<8,8q+1,8q+3,8q+4>`.

These four generators are minimal: the three larger generators differ by less than 8, are nonzero modulo 8, and a sum of two of them exceeds all three. Their gcd is one because `8q+1` is coprime to 8.

The preferred Apéry exponent set is

`T={0,e1,e2,e3,2e1,2e2,e1+e3,e2+e3}`.

Its residues are `0,1,3,4,2,6,5,7`, a permutation of all residues modulo 8. Its minimal excluded points are

`3e1, 3e2, 2e3, e1+e2, 2e1+e3, 2e2+e3`.

Under their respective reductions to `e2,e1,0,e3,2e2,2e1`, their weights decrease by

`16q,16q+8,16q+8,8q,8q,8q+8`,

all positive multiples of 8. Replacing a dominated minimal excluded point by its listed representative strictly decreases positive integer weight, so reduction terminates in T. Residue uniqueness then proves these are exactly the Apéry representatives. There are no factorization ties in these boundary reductions.

The exact formulas are

`M=16q+7`, `Sigma=88q+28`, `D=32q+56`,

`c=16q`, `n=5q`, `W=4q`.

The proposed bound's difference is

`D - (m-1)a_min = (32q+56)-7(8q+1)=49-24q`.

It is negative for every `q>=3`. In contrast, Wilf's number is positive for every `q>=1`.

The companion standard-library Python file checks the stated family formulas at seven selected parameter values, including one million. Those computations are diagnostics for the all-parameter argument above.
