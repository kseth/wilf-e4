# Excluding a triangular six-column Apéry staircase

Let `T` be a finite lower ideal in `N^3`, of size `m`, and suppose `xA+yB+zC` labels its points bijectively modulo `m`. Suppose its projection on the last two coordinates is exactly

`F = {(0,0),(1,0),(2,0),(0,1),(0,2),(1,1)}`.

Write the first-coordinate column lengths, in that order, as `n0,n1,n2,k1,k2,l`. Assume

`n0 > n1 > n2 >= 1`, `n0 > k1 > k2 >= 1`, and `1 <= l < min(n1,k1)`.

**Theorem. Such a residue labeling cannot exist.**

Proof. A minimal excluded point and its representative have disjoint supports: otherwise subtract a shared unit vector and contradict injectivity in `T`. Two distinct minimal excluded points with intersecting supports likewise have distinct residues. Thus there is at most one full-support minimal excluded point, and it represents residue zero.

The hypotheses make `(l,1,1)` a minimal excluded point. Therefore

`lA+B+C = 0 (mod m)`.

Its corresponding mixed column has labels `-l A,(-l+1)A,...,-A`; the origin column has labels `0,A,...,(n0-1)A`. These are all distinct. Writing `L=ord(A)` in `Z/mZ`, we obtain

`L >= n0+l`.

The two plane corners `(n1,1,0)` and `(n2,2,0)` are minimal excluded points. Their representatives lie on the third axis. They cannot represent zero, since they intersect the full-support corner, and they have distinct residues. Thus their representatives must permute `C,2C`. For some `epsilon in {1,2}`,

`n1 A+B = epsilon C`,
`n2 A+2B = (3-epsilon) C`.

If `epsilon=2`, substitute `B=-lA-C`. The first relation gives `(n1-l)A=3C`; the second gives `(n2-2l)A=3C`. Hence `(n1-n2+l)A=0`. But

`0 < n1-n2+l < n0+l <= L`,

an impossibility. Consequently `epsilon=1`, giving `(2n1-n2)A=0`. Applying the same argument to the corners `(k1,0,1),(k2,0,2)` gives

`k1 A+C=B`, `(2k1-k2)A=0`.

Adding `n1 A+B=C` to `k1 A+C=B` gives `(n1+k1)A=0`. Each of

`2n1-n2`, `2k1-k2`, `n1+k1`

is positive and smaller than `2L`, since `n1,k1<n0<=L`. Thus all three equal `L`. Adding the first two equalities and using the third gives `n2+k2=0`, contrary to positivity. QED.

## Consequence for full weighted staircases

Suppose `T={x in N^3: ax+by+dz<=M}` with `0<a<=b<=d` and all three unit vectors present. In the six-column alternative of the previous checkpoint, its projection is `F`, and its column lengths are `floor((M-by-dz)/a)+1`. Since `b,d>=a`, all the strict descent hypotheses above hold. Therefore the six-column alternative is impossible.

The preceding analytic classification then leaves at most four columns. In particular, it leaves at most four maximal points and at most four final-window Apéry elements. The previous analytic theorem for at most five final-window points applies; the computer-assisted six-point theorem is no longer needed for the quadratic conductor reduction.

This proof has been independently checked by the agent working on full weighted staircases. It uses residue bijectivity and the specified column geometry, not a finite search or a bound on weights.
