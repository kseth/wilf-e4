# Wilf in embedding dimension four: an explicit global finite reduction

**Date:** 5 September 2026.  
**Status:** The unrestricted conjecture is not proved or disproved here. This note gives an explicit large-multiplicity theorem, its complete analytic proof, and a finite region containing every possible four-generator counterexample. The arguments were independently checked during this research session; they have not undergone external peer review or formal proof-assistant verification. Publication priority has not been established.

## 1. Results and the exact unresolved task

Let
\[
S=\langle m,a_1,a_2,a_3\rangle,\qquad m<a_1<a_2<a_3,
\]
be a numerical semigroup with this minimal generating set. Write
\[
c=\text{conductor}(S),\quad n=|S\cap[0,c)|,\quad W=4n-c.
\]

**Theorem 1 (explicit large-multiplicity result).**
\[
\boxed{m\ge10^{27}\quad\Longrightarrow\quad W>0.}
\]

The proof establishes a quantitative moment inequality for every three-dimensional lower ideal containing the three unit vectors and having at most one minimal excluded point with all coordinates positive. Every preferred Apéry staircase satisfies that structural condition.

**Theorem 2 (analytic conductor reduction).**
\[
\boxed{W<0\quad\Longrightarrow\quad c\le m^2-3m+1,
\qquad a_3\le m(m-2).}
\]

The conductor bound was present in the preceding checkpoint with a computer-assisted dependency. The proof below removes that dependency by excluding a six-column configuration arithmetically and proving the remaining full weighted cases directly.

Together, these theorems give the unconditional finite reduction
\[
\boxed{W<0\ \Longrightarrow\ 4\le m<10^{27},
\quad m<a_1<a_2<a_3\le m(m-2).}
\tag{R}
\]
Using the published verification at multiplicity at most 19, the lower endpoint can be raised to 20. The core finite reduction (R) does not depend on that verification. Further published exclusions include conductor at most three times the multiplicity and genus at most 100 [3].

This is one finite region, rather than a finite box for each of infinitely many multiplicities. Its enormous size makes direct enumeration impractical. **No argument or exhaustive verification in this note eliminates the remaining region.** Thus (R) is a reduction, not a solution of Wilf in dimension four.

The supplementary slab theorem proves
\[
m\ge4K-2\Longrightarrow W\ge0,
\]
where \(K\) is the number of occupied rectangular cells obtained by compressing the coordinate intervals of the maximal Apéry exponents. It supplies another rigorous filter for (R), but does not bound all remaining compressed patterns.

## 2. Apéry preliminaries and the arithmetic restriction

Let \(\mathbb N=\{0,1,2,\ldots\}\). The Apéry set
\[
\operatorname{Ap}(S,m)=\{s\in S:s-m\notin S\}
\]
contains exactly one representative of every residue modulo \(m\). Select the lexicographically least factorization of each Apéry element using \(a_1,a_2,a_3\). The selected exponent set \(T\subset\mathbb N^3\) is a finite lower ideal of size \(m\), and contains \(0,e_1,e_2,e_3\).

To check downward closure, a divisor of an Apéry factorization is Apéry: otherwise adding its remaining factors would put the original element minus \(m\) in \(S\). Replacing a nonpreferred divisor factorization would also replace the original by a lexicographically smaller factorization. Both possibilities contradict its selection. Minimal generation places the three unit vectors in \(T\).

Set
\[
w(x)=a_1x_1+a_2x_2+a_3x_3,\quad
M=\max_Tw=c+m-1,\quad \Sigma=\sum_Tw,\quad D=3mM-4\Sigma.
\]
The classical Apéry genus formula gives
\[
g=\frac{\Sigma}{m}-\frac{m-1}{2},\qquad
\boxed{mW=D-m(m-1).}
\tag{1}
\]

If \(p\) is a coordinatewise minimal element of \(\mathbb N^3\setminus T\), let \(q\in T\) represent its residue. Their supports are disjoint. Indeed, a common positive coordinate \(j\) would put the distinct points \(p-e_j,q-e_j\) in \(T\) with equal residues. Likewise, two distinct minimal excluded points with a common positive coordinate cannot have the same residue. Consequently a minimal excluded point with all three coordinates positive has representative zero, and there is at most one such point.

This restriction is established prior work: see Hellus–Rechenauer–Waldi, Proposition 2.6 [2]. The proof is included to make the exact hypothesis of the stability theorem explicit.

For a coordinate line \(\ell\), let \(L_\ell\) be its length and \(t_\ell\) its top exponent. A separate partition into lines in each of the three directions gives
\[
\boxed{D=\sum_\ell L_\ell\bigl(M-w(t_\ell)\bigr)\ge0.}
\tag{2}
\]
For direction \(j\), the top weight averaged on a line is the mean total weight plus the mean contribution of coordinate \(j\). Summing over directions therefore gives \(4\Sigma\). This proves (2), the slack form of Zhai's lower-ideal inequality [1]. Wilf requires the additional correction \(m(m-1)\), which is why mere nonnegativity of (2) does not suffice.

## 3. Proof of the large-multiplicity theorem

The continuous lemma below is stated only for the exact sets needed: bounded downsets whose complements in the nonnegative orthant are finite unions of closed upper orthants. In the application these are unions of half-open rectangular cells. This fixes membership at boundary points while leaving all volume identities unchanged.

