"""Exact diagnostics; not an enumeration of the residual Wilf region."""
from fractions import Fraction as F
from heapq import heappop, heappush
from math import gcd
from functools import reduce
from pathlib import Path
import json


def invariants(gens):
    assert sorted(set(gens)) == list(gens)
    assert reduce(gcd, gens) == 1
    m = gens[0]
    dist = [None] * m
    dist[0] = 0
    heap = [(0, 0)]
    while heap:
        value, residue = heappop(heap)
        if dist[residue] != value:
            continue
        for generator in gens[1:]:
            new_value = value + generator
            new_residue = new_value % m
            if dist[new_residue] is None or new_value < dist[new_residue]:
                dist[new_residue] = new_value
                heappush(heap, (new_value, new_residue))
    assert all(x is not None for x in dist)
    max_ap = max(dist)
    conductor = max_ap - m + 1
    genus = sum(x // m for x in dist)
    n = conductor - genus
    D = 3 * m * max_ap - 4 * sum(dist)
    W = 4 * n - conductor
    assert m * W == D - m * (m - 1)

    # Independent bounded integer-membership computation.
    limit = max(max_ap, max(gens)) + m
    reachable = [False] * (limit + 1)
    reachable[0] = True
    for value in range(1, limit + 1):
        reachable[value] = any(value >= g and reachable[value-g] for g in gens)
    assert all(reachable[value] for value in range(conductor, limit+1))
    assert not reachable[conductor-1]
    assert sum(reachable[:conductor]) == n
    assert sum(not x for x in reachable[:conductor]) == genus
    for g in gens:
        assert not any(reachable[x] and reachable[g-x] for x in range(1,g))
    return dict(gens=gens, apery=sorted(dist), M=max_ap, Sigma=sum(dist),
                c=conductor, n=n, W=W, D=D)


def main():
    t = F(8,100)
    r = F(15,1000)
    k_c = F(1,10**6)
    box_gaps = [6*t*r*r*F(335,1000),
                6*3*r**3*F(8,100),
                6*2*r**3*F(25,1000)]
    assert all(x > k_c for x in box_gaps)
    assert F(1,12) - k_c/4 > t
    eps = F(6,10**10)
    assert 1261*eps < k_c
    assert (18*10**8)**3 < 6*10**27
    assert 1/F(18*10**8-3) < eps
    final_product = eps*(18*10**8-3)
    assert final_product > 1

    fixtures = [invariants(g) for g in
                [[4,5,6,7],[5,6,8,9],[16,49,52,53],
                 [23,98,258,272],[27,232,302,314],[23,181,189,192]]]
    bad = fixtures[2]
    assert (bad['M'],bad['Sigma'],bad['D'],bad['W']) == (159,1752,624,24)
    assert bad['D'] < (16-1)*49
    result = dict(constants=dict(continuous_box_lower_bounds=[str(x) for x in box_gaps],
                                 phase_contradiction_upper_bound=str(1261*eps),
                                 final_Wilf_product=str(final_product)),
                  fixtures=fixtures,
                  scope='Exact constants and finite fixtures only; no residual-region enumeration.')
    target = Path(__file__).with_name('exact_check_results.json')
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status='passed',fixtures=len(fixtures),constants=result['constants'])))


if __name__ == '__main__':
    main()
