import sys,json,random,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'prior/wilf_edim4_reassessment_checks_2026-09-05'))
from wilf_reassessment import shape_from_pair_bounds, maximal, ordered_geometric_optimum
from wilf_work import apery
from scipy.optimize import linprog

def best_ratio(t):
    m=len(t); sums=[sum(x[j] for x in t) for j in range(3)]
    r=linprog([-s for s in sums],A_ub=maximal(t),b_ub=[1]*len(maximal(t)),bounds=[(0,None)]*3,method='highs')
    assert r.success
    d=3*m+4*r.fun
    return dict(m=m,D=d,ratio=d/m,scaled_error=(m/3-d)/math.sqrt(m),weights=r.x.tolist())

def main():
    rng=random.Random(9652026); out={'actual_failures':[],'pair_extrema':[]}
    best=(-1,None)
    for i in range(1200):
        base=rng.randint(3,32)
        bs=tuple(base+rng.randint(-base//2,base//2) for _ in range(3))
        corner=tuple(rng.randint(1,max(1,base//2)) for _ in range(3)) if i%5 else None
        t=shape_from_pair_bounds(bs,corner)
        r=best_ratio(t);r.update(bounds=bs,corner=corner)
        if r['scaled_error']>best[0]:
            best=(r['scaled_error'],r);out['pair_extrema'].append(r)
    print(json.dumps({'pair_extrema':out['pair_extrema']}),flush=True)
    n=0
    for i in range(2500):
        m=rng.randint(20,600);a=sorted(rng.sample(range(m+1,40*m),3))
        ap=apery([m,*a])
        if ap is None:continue
        n+=1;t={x for _,x in ap[2]};r=ordered_geometric_optimum(t)
        if not r['sufficient']:
            r['gens']=[m,*a];out['actual_failures'].append(r)
            print(json.dumps(r),flush=True)
    out['actual_count']=n
    Path(__file__).with_name('geometry_results.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({'actual_count':n,'actual_failures':len(out['actual_failures']),'largest_bad':max([r['m'] for r in out['actual_failures']],default=0)}),flush=True)

if __name__=='__main__':main()
