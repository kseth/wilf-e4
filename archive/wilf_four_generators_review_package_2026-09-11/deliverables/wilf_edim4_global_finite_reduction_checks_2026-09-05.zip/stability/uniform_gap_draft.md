# Candidate eventual uniform gap for one-interior-corner lower ideals

This is a proof draft for adversarial checking, not a Wilf proof.

Let T⊂N³ be a nonempty finite lower ideal, m=|T|, with positive weights a_j, M=max_T a·x>0, Σ=Σ_T a·x, and κ=(3mM−4Σ)/(mM). Suppose T has at most one coordinatewise minimal excluded point whose three coordinates are positive.

**Claim.** There exist absolute ε>0 and m₀ such that m≥m₀ implies κ≥ε.

## 1. Hypothetical sequence and coordinate means

Suppose the claim fails. Choose T_n with m_n→∞ and κ_n→0. Normalize u_j=a_j/M so max_T u·x=1. Uniform X∈T has coordinate means μ_j=E[u_jX_j] and total μ=Σ_jμ_j=(3−κ)/4.

For each direction j define H_j(x_{−j})=max{t:(x_{−j},t)∈T} and δ_j(x)=1−u_jH_j(x_{−j})−Σ_{i≠j}u_i x_i≥0. Uniformity on each integer coordinate line gives

Eδ_j=1−μ−μ_j,   Σ_jEδ_j=κ.

Thus Eδ_j→0 and μ_j→1/4 separately.

## 2. All normalized lattice steps tend to zero

First min_j u_j→0, since otherwise T⊂{x:|x|≤1/min u} would have bounded cardinality.

Pass to a subsequence so some fixed k has u_k→0. Suppose some fixed j≠k has u_j≥η>0 along a further subsequence. Set s₀=min(η/4,1/10), h=floor(s₀/u_k), s=h u_k. Eventually s∈[s₀/2,s₀]⊂(0,u_j/2].

For every x∈T with x_k≥h, y=x−h e_k is in T. The difference δ_j(x)−δ_j(y) is −s plus an integer multiple of u_j, so its absolute value is at least s. Nonnegativity gives δ_j(x)+δ_j(y)≥s. Summing these pairs counts each point at most twice, so

2Eδ_j ≥ s P(u_kX_k≥s) ≥ s(μ_k−s).

The final inequality follows from 0≤u_kX_k≤1 and E[u_kX_k]≤s+P(u_kX_k≥s). Its RHS stays positive, contradicting Eδ_j→0. Thus every u_j→0.

## 3. Continuous thickening

Let s=Σ_j u_j. Form the measurable downset

K = ⋃_{x∈T} Π_j [u_j x_j/(1+s), u_j(x_j+1)/(1+s)).

It lies in the continuous standard simplex Δ={z≥0:Σz_j≤1}. Its uniform mean total coordinate is

μ_K = (μ+s/2)/(1+s) → 3/4.

It retains the same exclusion description: every complement point dominates a scaled minimal excluded grid corner, and at most one such corner has full support. Boundary conventions have measure zero; half-open intervals make the domination description exact.

## 4. Volume cannot vanish

For ANY measurable continuous downset K⊂Δ of positive volume, let Z be uniform in K and R=min_j Z_j. Then

E[ΣZ_j] ≤ 2/3+E[R].

Indeed, partition almost every point by its unique smallest coordinate j and its value r. The remaining two coordinates minus r form a planar lower ideal with total coordinate at most 1−3r. The continuous two-dimensional lower-ideal inequality bounds their mean sum by (2/3)(1−3r). Adding 3r gives conditional mean total at most 2/3+r. Integrate using Fubini/coarea; the minimum-coordinate slices have ordinary planar measure and dr Jacobian one.

Consequently μ_K→3/4 forces E[R]≥1/12−o(1). Eventually K contains a point with all coordinates at least 1/25, and downward closure gives volume(K)≥25⁻³.

## 5. Compactness and continuous equality

Indicators of downsets in [0,1]³ have an L¹-convergent subsequence (standard elementary compactness of coordinatewise monotone bounded functions; also follows by diagonal selection on rational grid boxes and uniform boundary-brick approximation). Let limit be a downset K⊂Δ. The volume lower bound gives positive volume, and moment convergence gives μ_K=3/4.

Continuous coordinate-line integration gives

3vol(K)−4∫_K Σz_j dz = Σ_j ∫_{π_jK} H_j(y)(1−Σy−H_j(y))dy,

where H_j is the upper endpoint of the j-fiber. Every summand is nonnegative. Equality implies H_j(y)=1−Σy for almost every nonempty fiber.

This forces K=Δ up to a null set. One elementary justification: positive volume and lower closure give a positive cube [0,t]³⊂K modulo boundaries. Full x-fibers over 0<y,z<t show that π_yK contains almost every (x,z) with z<t and x+z<1. Full y-fibers then fill almost all of Δ∩{z<t}. Their projection onto (x,y) is the full triangle x+y<1, so full z-fibers fill Δ.

## 6. One-corner contradiction

L¹ convergence of downsets K_n to Δ implies that every point strictly inside Δ with positive coordinates eventually belongs to K_n, while every point with positive coordinates and coordinate sum >1 eventually lies outside K_n. For otherwise the upper or lower orthant box at that point gives a fixed positive symmetric-difference volume.

Take outside points p=(1/2,3/10,3/10) and q=(3/10,1/2,3/10). Each has sum 11/10. For each of their three two-coordinate projections, replace the remaining coordinate by 1/100. These six witness points lie strictly inside Δ, hence eventually in K_n. Meanwhile p,q are eventually outside.

A minimal excluded grid corner below p cannot have support of size one or two, since the corresponding witness point has exactly the same coordinates on that support and belongs to K_n. Hence p dominates an interior corner. The same holds for q. Uniqueness forces the same corner below both, thus below r=(3/10,3/10,3/10). But r is strictly inside Δ and eventually in K_n, a contradiction.

Therefore the claimed eventual positive gap follows, subject to independent audit of all steps above.

## Consequence for four-generator Wilf (conditional only on the draft's correctness)

For a genuine Apéry staircase, a_min>m and m≤binom(floor(M/a_min)+3,3). Thus M/m→∞ whenever m→∞. The asserted κ≥ε gives D≥ε mM>m(m−1) for sufficiently large m. It proves existence of a finite multiplicity threshold beyond which embedding-dimension-four Wilf holds, but provides neither explicit constants nor a verification of the remaining multiplicities. It is not a proof of all embedding dimension four.
