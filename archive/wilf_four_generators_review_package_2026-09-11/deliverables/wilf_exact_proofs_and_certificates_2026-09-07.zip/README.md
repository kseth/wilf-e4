# Wilf exact proofs and certificates, 7 September 2026

Read deliverables/wilf_no_interior_theorem_and_remaining_cases_2026-09-07.md for the report and full proofs.

The unrestricted four-generator conjecture remains unresolved by this work.
Completed: the continuous no-interior mean theorem, the subclass bound 1836,
the equal-weight integer theorem, and the stated secondary quotient family.

Run `python3 round4/verify_completed_results.py` from the extracted archive.
Its exact certificate checks require only the Python standard library.
The checks establish finite identities and recurrences used in the proofs;
the analytic arguments also require reading the manuscript and audit notes.
The runner does not enumerate all remaining numerical semigroups.

Files described as probes, searches, or diagnostics are bounded experiments,
not universal certificates. Some require NumPy, SciPy, or SymPy. They are
not called by the proof-certificate runner. Third-party installations are
excluded. Historical checkpoint archives are included in deliverables/ to
preserve the earlier proofs and their exact scripts without replacing them.
Older notes may call a formerly missing implication "unproved" or
"conditional"; the dated main report states which are now completed.

MANIFEST.json contains SHA-256 hashes of the archived content. Rerunning
checkers may regenerate JSON outputs (including timing data).
