"""Assemble the completed family proof and the precise unresolved obligations."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'deliverables' / 'wilf_secondary_family_and_remaining_gaps_2026-09-05.md'

INTRO = r'''# Wilf: a completed secondary-family proof and the remaining four-generator gap

**Research manuscript, 5 September 2026.**

This manuscript does **not** prove or disprove Wilf's conjecture for every
four-generated numerical semigroup. It contains a complete argument for an
unbounded family, additional proved reductions, and exact counterexamples
to two proposed closing lemmas. None of those auxiliary counterexamples is
a counterexample to Wilf.

The proofs received independent checks within this research session. The
polynomial certificates use exact rational arithmetic. This is not external
peer review, and no publication-priority claim is made.

## The completed family theorem

For a numerical semigroup \(S\), let \(c(S)\) be its conductor,
\(n(S)=|S\cap[0,c(S))|\), and \(W_4(S)=4n(S)-c(S)\).
Write \(A/q=\{k\in\mathbb N:qk\in A\}\).

Let \(A=\langle a,b\rangle\) and \(B=\langle c,d\rangle\) be
two-generated numerical semigroups, let \(p,q\) be coprime positive integers,
and assume \(S=pA+qB\) has exactly four minimal generators. If, for some
integer \(g\ge1\),
\[
A/q=B/p=R=\langle2,2g+1\rangle,
\]
and
\[
q(R\setminus\{0\})\subseteq(a+b)+A,
\qquad
p(R\setminus\{0\})\subseteq(c+d)+B,
\]
then
\[
\boxed{W_4(S)\ge1.}
\]

The parameter \(g\), the multiplicity and conductor of \(S\), and its
final-window cardinality are unrestricted. The proof derives exact genus
and conductor formulas, reduces the desired inequality to a piecewise
polynomial, and certifies its sign on sixteen regions. All 1,600 rational
coefficients in the nonnegative basis are nonnegative; all sixteen reverse
basis expansions agree exactly with the original polynomial.

For example, the theorem covers
\[
S=\langle3030,3725,3737,5066\rangle,
\quad c=134796,\quad n=48366,\quad W_4=58668.
\]
Its final window has sixteen Apéry points, so this example is beyond the
earlier six-point theorem's hypothesis.

Part I gives the complete invariant derivation, parameterization, theorem,
and certificate construction. The companion archive includes every
certificate coefficient and an executable standard-library checker.

## Additional results and their scope

| Result | Status and scope |
| --- | --- |
| A triple containing the multiplicity has gcd greater than one | Proved: \(W_4\ge2\). |
| Gcd of the other three generators exceeds one | Proved conductor descent; a minimum-conductor counterexample has gcd one for every triple. |
| No interior excluded corner and at most two pair-interaction types | Proved Wilf, using a discrete mean bound and Eliahou's published \(c\le3m\) theorem. |
| Any staircase with no interior excluded corner | Proved central-box/three-arm structure; the full moment inequality remains unproved. |
| Three full-cap arms, each with an initial plateau followed by arbitrary boundary profiles | Proved continuous mean at most \(2/3\) after normalization. This profile restriction is essential to the current proof. |
| An arbitrary arm based at outward coordinate at least \(1/3\), after normalizing maximum height to one | Proved explicit potential bound, including initial slack. Earlier-base arms still require a bound. |
| A staircase between successive three-face shells, radius at least five | Proved the ordered weighted inequality for every radius; exact polynomial and finite scalar certificates. |
| Every remaining four-generated semigroup | **Unresolved.** |

## Why these results do not complete the conjecture

The earlier finite-reduction manuscript gives the necessary counterexample
region
\[
20\le m<2\times10^{14},\qquad
m<a_1<a_2<a_3\le m(m-2),\qquad c\le m^2-3m+1.
\]
Its analytic arguments were audited again for degenerate limits in this
continuation. The new gcd theorem adds
\(\gcd(m,a_i,a_j)=1\) for every pair. A minimum-conductor counterexample
must have gcd one for all four triples. These conditions have not been
shown inconsistent, and the finite region has not been exhausted.

The new family theorem has a precise boundary: a common quotient can have
multiplicity at least three. The compatible paired example
\(A=\langle5,7\rangle,q=9,B=\langle5,8\rangle,p=11\) has common quotient
\(\langle3,4,5\rangle\), and gives \(S=\langle45,55,72,77\rangle\).
That semigroup satisfies Wilf, but the multiplicity-two quotient theorem
does not apply. The unrestricted primary class is also outside its scope.

There are two logically separate missing obligations:

1. For arbitrary no-interior staircases, the central-box/three-arm theorem
   still allows underfilled caps and multiple off-boundary plateaus. The
   proved boundary-profile inequality does not cover them. Even a proof of
   the full continuous inequality would require a discrete/arithmetic
   argument to settle every associated numerical semigroup.
2. The remaining interior-corner and general paired-quotient cases have not
   been eliminated by the new family theorem or the earlier finite reduction.

Consequently, neither a proof of emptiness nor a negative-Wilf semigroup is
provided here. The remaining work is a substantive universal inequality or
exhaustive certificate, not an omitted algebraic step.

## Exact failed closing lemmas

The adjoining-one-generator shortcut
\(n(T)+4(g(T)-g(S))\ge3(c(T)-c(S))\) is false even if one may choose
which nonmultiplicity generator to adjoin. The exact witness is
\(S=\langle31,171,251,553\rangle\), with \(W_4(S)=833>0\).
All three eligible three-generator bases violate that stronger shortcut.

The claim that every horn is optimized by a capped-balanced taper is also
false. For central sides \((1/5,2/5,2/5)\), an admissible alternating
boundary profile improves the best such taper by exactly \(1/120000\).
The improved profile still satisfies the combined three-horn inequality.
The broader theorem in Part V explicitly incorporates this improvement.

## Reproduction

Extract the companion archive and, from its top-level directory, run:

```sh
python3 round3/verify_checkpoint.py
```

This reruns the exact secondary polynomial certificate, independent Apéry
invariant checks, the shell certificate, the boundary-profile polynomial
identities, and the exact counterexample to the taper ansatz. The code and
the full rational coefficient data are both supplied. The analytic proofs
are necessary parts of the family theorems; checking numerical examples
alone would not establish them.

Historical finite-reduction manuscripts and their original verification
archive are retained under `dependencies/`. Exploratory LP/MILP and random
search records under `round3/` are labeled as diagnostics and are not used
to claim an exhaustive four-generator proof.

---

# Part I. Complete proof for the secondary quotient-two family

'''

PARTS = [
    ('round3/secondary/quotient_two_exact_formulas.md', None),
    ('round3/audit/quotient_two_wilf_certificate.md', 'Part II. Independent exact certificate audit'),
    ('round3/gcd_and_extension_reductions.md', 'Part III. Arithmetic reductions and an exact failed extension lemma'),
    ('round3/no_interior/clique_tree_and_bipartite_bound.md', 'Part IV. No-interior structure and the bipartite Wilf theorem'),
    ('round3/horns_optimization/fullcap_boundary_theorem.md', 'Part V. The sharp full-cap boundary-profile theorem'),
    ('round3/horns_optimization/ansatz/ansatz_counterexample.md', 'Part VI. Exact obstruction to the simpler taper ansatz'),
    ('round3/arithmetic/face_shell_analytic.md', 'Part VII. Unbounded face-shell theorem'),
    ('round3/descent/late_horn_potential.md', 'Part VIII. An arbitrary-arm theorem for bases at least one third'),
    ('round3/audit/final_reduction_scope_audit.md', 'Part IX. Scope audit'),
]

REFERENCES = r'''
---

# Primary background sources

- A. Zhai, *An asymptotic result concerning a question of Wilf*,
  https://arxiv.org/abs/1111.2779. The weighted lower-ideal bound is used in
  the gcd reduction.
- S. Eliahou, *Wilf's conjecture and Macaulay's theorem*,
  https://arxiv.org/abs/1703.01761. Its \(c\le3m\) theorem completes the
  conductor ranges in the bipartite subclass.
- J. R. S. Blair and B. W. Peyton, *An introduction to chordal graphs and
  clique trees*, ORNL/TM-12203, 1992,
  https://people.math.binghamton.edu/zaslav/Oldcourses/580.S13/blair-peyton.chordal-graphs-clique-trees.ornl1992.pdf.
  The clique-tree theorem supplies the standard graph-theoretic input.
- M. Hellus, A. Rechenauer and R. Waldi, *Variants on a question
  of Wilf*, https://arxiv.org/abs/1804.06141. Proposition 2.6 supplies the
  established unique full-support-corner restriction.
- C. Cisto, *On some numerical semigroup transforms*,
  https://arxiv.org/abs/2209.05803. The archive examines an existing transform
  as a conditional counterexample descent; it does not furnish a universal
  descent in this work.
- *The type and cardinality of minimal presentations of numerical
  semigroups with embedding dimension four*,
  https://arxiv.org/html/2609.04000v1. This is background for the paired
  secondary classification. The family theorem above states all of its
  own hypotheses explicitly and proves its invariant formulas directly.

The manuscript's remaining-gap statement is a statement about the scope
of these arguments. No claim is made that bounded tests establish the
unrestricted conjecture or that every theorem here is new in the literature.
'''

text = INTRO
for path, title in PARTS:
    if title:
        text += '\n\n---\n\n# ' + title + '\n\n'
    text += (ROOT/path).read_text() + '\n'
text += REFERENCES
OUT.parent.mkdir(exist_ok=True)
OUT.write_text(text)
print(OUT)
print(f'{len(text.split())} words; {len(text.encode())} bytes')
