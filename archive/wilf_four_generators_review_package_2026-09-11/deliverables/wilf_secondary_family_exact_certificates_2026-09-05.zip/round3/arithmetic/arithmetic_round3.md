# Round 3: adversarial geometric checks and an unbounded shell theorem

The universal proposed statement

> Every three-dimensional lower ideal with at most one full-support minimal excluded point and size at least 32 satisfies the ordered geometric moment inequality

has **not** been proved or disproved by this branch. No counterexample to that statement was found. A stronger proposed simplification was disproved, and one unbounded structural family was proved.

## 1. The completed unbounded result

For

`F_R={x∈N^3: |x|_1<=R, min_i x_i=0}`,

all lower ideals `F_R⊆T⊆F_{R+1}`, with `R>=5`, satisfy

`3m max_T(a·x)-4 sum_T(a·x) >=m(m-1)`

for arbitrary real weights `a1>=m+1`, `a2>=a1+1`, and `a3>=a2+1`. No residue condition is assumed. The full self-contained proof is in `face_shell_analytic.md`.

The proof uses elementary shell-point counts and piecewise linear minimization. Positive-coefficient polynomial identities handle all radii at least 13; 228 explicit rational scalar inequalities cover radii 5 through 12. The standard-library checker `face_shell_verify.py` passed every scalar case and recession condition, and writes `face_shell_verification.json`. The argument was derived by the delegated face-shell agent and checked by the arithmetic agent.

At radius 4, all 32,767 lower ideals `F_4⊊T⊆F_5` were exhaustively checked by the existing rational LP primal/dual verifier; every one passed. This is recorded in `shell5.py` and `shell5_results.json`. Combined with the analytic theorem, all these single-shell shapes of size at least 32 are covered.

This is a theorem about the geometric relaxation. Since these shapes have the interior corner `(1,1,1)`, their genuine semigroup realizations were already covered by the prior structural six-point result. It does not add a proof for arbitrary remaining Apéry shapes.

## 2. Counterexamples to the stronger cube/eta claim

The proposed implication

`(1,1,1)∈T and at most one full corner ⇒ η(T)>=m-1`,

where `η(T)=min_{u_i>=1}[3m max_T u·x-4 sum_T u·x]`, is false. Both counterexamples below have a unique full corner `(2,1,1)`.

First, let

`T={x+y+z<=3, y+z<=2}`.

It contains 16 points and `(1,1,1)`. At unit weights, `M=3`, `Σ=33`, and `D=12<15`. Its ordered geometric certificate nevertheless passes.

There is also a counterexample above the proposed multiplicity cutoff. Define `b=(6,4,3,1,1,1)` and

`T={(x,y,z)∈{0,...,5}³: x+y<=5, x+z<=5, z<b_y, and not(x>=2,y>=1,z>=1)}`.

It has 46 points, contains `(1,1,1)`, and has exactly one full minimal excluded point `(2,1,1)`. At unit weights, `M=5`, `Σ=162`, and `D=42<45`.

This example does **not** refute the ordered geometric conjecture. Its coordinate sums are `(60,49,53)`. In the displayed coordinate order, `M=5a3` and

`D=42a1+282(a2-a1)+478(a3-a2) >=2734>2070`.

Even after permuting coordinate axes, the smallest ordered bound is 2662, still above 2070. The standard-library checker `verify_cube_counterexamples.py` verifies both counterexamples, their corner conditions, and the 46-point ordered bounds. Its output is `cube_counterexamples_exact.json`.

## 3. Targeted optimization diagnostics

These searches were directed at geometric obstructions rather than random semigroup generation.

- Coordinate-level insertions into the previous bad three-face shapes explored 42 shapes. Two inserted shapes failed, of sizes 11 and 14. The branch only continued through failing intermediate shapes, so this was not a classification of all stretched shapes.
- A binary optimization model selects a lower ideal inside a weighted simplex and permits at most one full-support minimal excluded point. In 33 fixed-radius problems, the solver reported 25 optima and eight infeasible problems. None yielded a counterexample.
- A second model minimizes the full deficit directly, with `M` as a variable. It ran 24 fixed-weight problems at `m∈{32,40,46,64,80,100}`, including unequal weight ratios. Fourteen reported an optimum and ten reached their 15-second limit. No feasible candidate violated the target.
- Every one of the 49 feasible shapes from those two searches was independently checked for the downset and corner conditions, and its ordered LP optimum was then verified by exact rational primal/dual arithmetic. All passed. The smallest exact margin among them was 60, attained by `F_5` at `m=46`, with weights `(47,48,49)`.

Solver optimality statuses are numerical diagnostics, not exact infeasibility certificates or a proof of the universal conjecture. The exact verification applies to the returned shapes and their geometric LPs. See `milp_adversary.py`, `milp_direct.py`, their result files, and `verify_milp_candidates.py` / `milp_candidate_exact_checks.json`.

The cube/eta optimization was stopped once the exact size-46 counterexample was found. Its preliminary results are in `cube_eta_results.json`; the standalone verification above is the proof that the stronger statement is false.

## 4. Remaining obligation

A proof still needs an argument covering arbitrary coordinate-plane profiles, arbitrary interval stretching, and arbitrary positive ordered weights. Single-shell face shapes are only one subfamily. Neither the finite optimizations nor the absence of a geometric counterexample supplies that missing classification.
