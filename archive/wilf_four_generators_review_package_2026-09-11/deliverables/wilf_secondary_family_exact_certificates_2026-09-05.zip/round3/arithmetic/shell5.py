import sys,itertools,json
sys.path.insert(0,'prior/wilf_edim4_reassessment_checks_2026-09-05')
from wilf_reassessment import ordered_geometric_optimum
base=frozenset(x for x in itertools.product(range(5),repeat=3) if sum(x)<=4 and min(x)==0)
shell=sorted(x for x in itertools.product(range(6),repeat=3) if sum(x)==5 and min(x)==0)
bad=[];genuine=[];total=0
for mask in range(1,1<<len(shell)):
 t=set(base)|{x for j,x in enumerate(shell) if mask>>j&1};m=len(t);r=ordered_geometric_optimum(t);total+=1
 if mask%5000==0:print('PROGRESS',mask,len(bad),flush=True)
 if r['sufficient']:continue
 triangles=[]
 for k in range(3):
  p={tuple(x[j] for j in range(3) if j!=k) for x in t if x[k]==0}
  if p=={(i,j) for i in range(5) for j in range(5) if i+j<=4}:triangles.append(k)
 bijections=[]
 # Interior corner forces C=-A-B. Exact full residues.
 for A in range(1,m):
  for B in range(1,m):
   C=(-A-B)%m
   if not C:continue
   residues={(A*x+B*y+C*z)%m for x,y,z in t}
   if len(residues)==m:bijections.append((A,B,C))
 rec={'m':m,'missing_shell':[x for x in shell if x not in t],'LP':r,'triangular_faces':triangles,'residue_bijections':bijections}
 bad.append(rec)
 if bijections:genuine.append(rec)
open('round3/arithmetic/shell5_results.json','w').write(json.dumps({'total':total,'bad_count':len(bad),'bad':bad,'with_residue_bijection':genuine},indent=2))
print('FINAL',total,len(bad),len(genuine),flush=True)
for r in bad:print(json.dumps({k:v for k,v in r.items() if k!='LP'}),flush=True)
