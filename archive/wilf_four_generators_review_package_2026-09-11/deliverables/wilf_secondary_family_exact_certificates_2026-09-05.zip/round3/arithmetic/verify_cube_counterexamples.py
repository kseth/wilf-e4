"""Exact standard-library checks of counterexamples to the stronger eta claim."""
from itertools import product
import json

def corners(T):
 cand={tuple(v+(i==j) for i,v in enumerate(x)) for x in T for j in range(3)}-T
 return sorted(p for p in cand if all(tuple(v-(i==j) for i,v in enumerate(p)) in T for j in range(3) if p[j]))

def check(T,m,full,expected_M,expected_sum,expected_D):
 assert len(T)==m and (1,1,1) in T
 assert all(tuple(v-(i==j) for i,v in enumerate(x)) in T for x in T for j in range(3) if x[j])
 fulls=[p for p in corners(T) if all(p)];assert fulls==[full]
 M=max(map(sum,T));Sigma=sum(map(sum,T));D=3*m*M-4*Sigma
 assert (M,Sigma,D)==(expected_M,expected_sum,expected_D)
 assert D<m-1
 return dict(m=m,full_corner=full,M=M,Sigma=Sigma,D=D,target=m-1,T=sorted(T))
T16={x for x in product(range(4),repeat=3) if sum(x)<=3 and x[1]+x[2]<=2}
profile=(6,4,3,1,1,1)
T46={(x,y,z) for x,y,z in product(range(6),repeat=3) if x+y<=5 and x+z<=5 and z<profile[y] and not(x>=2 and y>=1 and z>=1)}
out=[check(T16,16,(2,1,1),3,33,12),check(T46,46,(2,1,1),5,162,42)]
# For the 46-point shape, every axis reaches 5, and all total degrees are at most5.
# Thus M=5*a3 for ordered weights. Coordinate sums are (60,49,53).
assert tuple(sum(x[j] for x in T46) for j in range(3))==(60,49,53)
# In the displayed order D=42*a1+282*(a2-a1)+478*(a3-a2).
assert 42*47+282+478==2734>46*45
# Permuting axes maximizes Sigma by assigning coordinate sums49,53,60 to a1,a2,a3.
assert 42*47+238+450==2662>46*45
open('round3/arithmetic/cube_counterexamples_exact.json','w').write(json.dumps(out,indent=2))
print('PASS: eta counterexamples m16 andm46 verified exactly; m46 ordered bound passes in every axis order.')
