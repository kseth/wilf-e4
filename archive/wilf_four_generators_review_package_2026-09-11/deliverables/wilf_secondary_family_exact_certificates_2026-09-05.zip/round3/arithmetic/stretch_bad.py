import sys,itertools,json
sys.path.insert(0,'prior/wilf_edim4_reassessment_checks_2026-09-05')
from wilf_reassessment import ordered_geometric_optimum,corners

def stretch(T,j,k):
 U=set()
 for x in T:
  y=list(x)
  if x[j]>=k:y[j]+=1
  U.add(tuple(y))
  if x[j]==k:y[j]=k;U.add(tuple(y))
 return frozenset(U)

seeds=[frozenset(x for x in itertools.product(range(d+1),repeat=3) if sum(x)<=d and min(x)==0) for d in [2,3,4]]
seen=set(seeds);level=seeds;out=[]
for depth in range(8):
 nxt=[]
 for T in level:
  for j in range(3):
   for k in range(1,max(x[j] for x in T)+1):
    U=stretch(T,j,k)
    if U in seen:continue
    seen.add(U)
    r=ordered_geometric_optimum(U)
    if not r['sufficient']:
     rec={'depth':depth+1,'m':len(U),'T':sorted(U),'LP':r,'corners':corners(U)};out.append(rec);nxt.append(U)
     print(json.dumps(rec),flush=True)
 level=nxt
 print('LEVEL',depth+1,'seen',len(seen),'bad',len(nxt),flush=True)
 if not nxt:break
open('round3/arithmetic/stretch_bad_results.json','w').write(json.dumps({'tested':len(seen),'bad':out},indent=2))
