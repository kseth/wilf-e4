import itertools,json,time
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import lil_matrix

def run(m,R,ratios=(1,1,1),limit=5):
 a=ratios;M=R*a[2]
 pts=[x for x in itertools.product(range(int(M/min(a))+2),repeat=3) if sum(v*w for v,w in zip(a,x))<=M]
 idx={x:i for i,x in enumerate(pts)};N=len(pts)
 candidates=set()
 for x in pts:
  for j in range(3):
   p=tuple(v+(i==j) for i,v in enumerate(x))
   if all(p) and all(tuple(v-(i==k) for i,v in enumerate(p)) in idx for k in range(3)):candidates.add(p)
 cs=sorted(candidates);ci={x:N+j for j,x in enumerate(cs)};V=N+len(cs)
 rows=[];lo=[];hi=[]
 def add(row,l=-np.inf,h=np.inf):rows.append(row);lo.append(l);hi.append(h)
 for x,i in idx.items():
  for j in range(3):
   if x[j]:add({i:1,idx[tuple(v-(k==j) for k,v in enumerate(x))]:-1},h=0)
 for p,i in ci.items():
  row={i:1}
  for k in range(3):row[idx[tuple(v-(j==k) for j,v in enumerate(p))]]=-1
  if p in idx:row[idx[p]]=1
  add(row,l=-2)
 add({i:1 for i in ci.values()},h=1)
 add({i:1 for i in range(N)},l=m,h=m)
 mat=lil_matrix((len(rows),V))
 for k,row in enumerate(rows):
  for j,v in row.items():mat[k,j]=v
 low=np.zeros(V);up=np.ones(V)
 for x in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,1)]:low[idx[x]]=1
 costs=np.array([-sum(v*w for v,w in zip(a,x)) for x in pts]+[0]*len(cs),float)
 start=time.time();res=milp(costs,integrality=np.array([1]*N+[0]*len(cs)),bounds=Bounds(low,up),constraints=LinearConstraint(mat.tocsr(),lo,hi),options={'time_limit':limit,'mip_rel_gap':0})
 rec={'m':m,'R':R,'a':a,'M_limit':M,'status':res.status,'message':res.message,'seconds':time.time()-start,'dual_bound':getattr(res,'mip_dual_bound',None)}
 if res.x is not None:
  T=[x for x,i in idx.items() if res.x[i]>.5];vals=[sum(v*w for v,w in zip(a,x)) for x in T];D=3*m*max(vals)-4*sum(vals);rec.update(D=D,target=m-1,T=T,full_corners=[p for p in cs if all(tuple(v-(j==k) for j,v in enumerate(p)) in T for k in range(3)) and p not in T])
 return rec


out=[]
for ratios in [(1,1,1),(1,1,2),(1,2,3)]:
 for R in [3,4,5,6,7,8]:
  for m in [8,10,12,16,20,24,28,32,40,46,50,64,80,100]:
   r=run(m,R,ratios,3);out.append(r);print(json.dumps({k:v for k,v in r.items() if k!='T'}),flush=True)
   open('round3/arithmetic/cube_eta_results.json','w').write(json.dumps(out,indent=2))
   if 'D' in r and r['D']<r['target']:
    print('COUNTEREXAMPLE',flush=True)
    if m>=32:raise SystemExit
