import sys,json
from pathlib import Path
sys.path.insert(0,'prior/wilf_edim4_reassessment_checks_2026-09-05')
from wilf_reassessment import ordered_geometric_optimum,corners
out=[]
for name in ['milp_adversary','milp_direct']:
 for j,r in enumerate(json.load(open(f'round3/arithmetic/{name}_results.json'))):
  if 'T' not in r:continue
  T=set(map(tuple,r['T']));m=len(T)
  assert m==r['m']
  assert {(0,0,0),(1,0,0),(0,1,0),(0,0,1)}<=T
  assert all(tuple(v-(k==i) for k,v in enumerate(x)) in T for x in T for i in range(3) if x[i])
  assert len([p for p in corners(T) if all(p)])<=1
  opt=ordered_geometric_optimum(T);assert opt['sufficient']
  out.append({'source':name,'index':j,'m':m,'LP':opt})
Path('round3/arithmetic/milp_candidate_exact_checks.json').write_text(json.dumps(out,indent=2))
print('PASS',len(out),'feasible MILP candidates checked exactly')
