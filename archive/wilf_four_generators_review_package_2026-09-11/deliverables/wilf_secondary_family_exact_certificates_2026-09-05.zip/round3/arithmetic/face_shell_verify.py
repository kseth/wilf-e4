"""Exact arithmetic for face_shell_analytic.md; Python standard library only."""
from fractions import Fraction as F
from math import comb
import json
from pathlib import Path


def mul(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return out


def add(*polys):
    return [sum(p[i] if i < len(p) else 0 for p in polys)
            for i in range(max(map(len, polys)))]


def neg(p):
    return [-v for v in p]


def shift(p, h):
    return [sum(p[i] * comb(i, j) * h ** (i-j)
                for i in range(j, len(p))) for j in range(len(p))]


def params(R, s):
    n = 1 + 3 * R * (R+1) // 2
    K = R * (R+1) * (2*R+1) // 6
    m = n + s
    B = 3*n - s
    A = (R+1)*B - 12*K
    G = A-B
    assert G == R*(R-1)*(R-2)//2-R*s
    return n, K, m, B, A, G


# Ascending power coefficients of 4E_0 and 4E(L).
p0 = add(mul([0, 2, -3, 1], [8, 3, 3]), [0, 8, 24, 16],
         neg(mul([2, 3, 3], [0, 3, 3])))
pL = add(mul([0, -4, -9, 1], [14, 9, 3]), [0, 8, 24, 16],
         neg(mul([8, 9, 3], [6, 9, 3])))
assert shift(p0, 5) == [240, 2028, 1536, 453, 60, 3]
assert shift(pL, 13) == [39264, 124860, 33708, 3549, 168, 3]
assert all(v > 0 for v in shift(p0, 5) + shift(pL, 13))

middle = []
for R in range(6, 13):
    rows = []
    L = 3*(R+1)
    for s in range(1, L+1):
        n, K, m, B, A, G = params(R, s)
        J = min(R+1, (L-s+1)//2)
        assert B > 0 and A >= 0
        V0 = A*(m+3)+12*K-2*B*J
        vertices = [F(V0)]
        slopes = [F(A), F(A+4*K) if J == 0 else F(G+4*K)]
        if J >= 2:
            assert m+1 > 2*(J-1)
            slopes.append(F(G*J+4*K))
            vertices.append(F((G*J+4*K)*(m+1), J-1)+4*K)
        assert min(slopes) >= 0
        slack = min(vertices)-m*(m-1)
        assert slack > 0
        rows.append(dict(s=s, J=J, slack=slack, slopes=slopes))
    worst = min(rows, key=lambda x: x['slack'])
    middle.append(dict(R=R, minimum=worst, cases=rows))

small = []
N = [1, 4, 8, 13, 15, 17, 18]
for s in range(1, 19):
    n, K, m, B, A, G = params(5, s)
    h = next(h for h, count in enumerate(N) if count > 18-s)
    U0 = A*(m+3)+12*K-3*B*h
    vertices = [F(U0)]
    if h:
        assert F(2*m+3, 2)/(h-F(1, 2)) > 3
        slopes = [F(A), F(G, 2)+4*K, F(G*h+4*K)]
        vertices.append(F(G*h+4*K)*F(2*m+3, 2)/(h-F(1, 2)))
    else:
        slopes = [F(A), F(A, 2)+4*K]
    assert min(slopes) > 0
    slack = min(vertices)-m*(m-1)
    assert slack > 0
    small.append(dict(s=s, h=h, slack=slack, slopes=slopes))

# Independently verify every N_h bound at every arrangement breakpoint and
# every intervening midpoint. All deficiency lines are affine in v, and
# crossing a threshold h is the only way a count can change.
shell = [(x,y,6-x-y) for x in range(7) for y in range(7-x)
         if min(x,y,6-x-y) == 0]
assert len(shell) == 18
count_checks = []
for h, required in enumerate(N):
    breakpoints = {F(0), F(1, 2)}
    for x,y,z in shell:
        if x != y:
            v = F(h-x, y-x)
            if 0 <= v <= F(1,2):
                breakpoints.add(v)
    points = sorted(breakpoints)
    points += [(a+b)/2 for a,b in zip(points, points[1:])]
    minimum = min(sum(x+(y-x)*v <= h for x,y,z in shell) for v in points)
    assert minimum >= required
    count_checks.append(dict(h=h, required=required, verified_minimum=minimum))

result = dict(status='PASS', base_shift5=shift(p0,5), large_shift13=shift(pL,13),
              middle=middle, radius5=small, count_checks=count_checks)
path = Path(__file__).with_name('face_shell_verification.json')
path.write_text(json.dumps(result, default=str, indent=2)+'\n')
print('PASS: all R>=5 certified; finite scalar cases:',
      sum(len(r['cases']) for r in middle)+len(small))
for r in middle:
    print('R',r['R'],'minimum',r['minimum']['slack'])
print('R 5 minimum',min(r['slack'] for r in small))
print(path)
