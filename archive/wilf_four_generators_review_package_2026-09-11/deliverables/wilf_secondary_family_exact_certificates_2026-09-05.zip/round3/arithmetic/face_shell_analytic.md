# An elementary certificate for all three-face shells of radius at least five

This is a self-contained geometric argument, with exact finite arithmetic tables. It makes no claim of research novelty.

## Statement

For an integer \(R\ge5\), let
\[
F_R=\{x\in\mathbb N^3:|x|\le R,\ \min_i x_i=0\}.
\]
Suppose \(F_R\subseteq T\subseteq F_{R+1}\), put \(m=|T|\), and let the real weights satisfy
\[
a_1\ge m+1,\qquad a_2\ge a_1+1,\qquad a_3\ge a_2+1.
\]
Then
\[
\boxed{3m\max_{x\in T}(a\cdot x)-4\sum_{x\in T}a\cdot x\ \ge\ m(m-1).}
\]
No arithmetic realizability, residue bijection, or numerical-semigroup condition on \(T\) is used.

## Common notation and identity

Write
\[
n=|F_R|=1+\frac{3R(R+1)}2,\quad K=\frac{R(R+1)(2R+1)}6,
\quad L=3(R+1),\quad s=m-n.
\]
Each coordinate has sum \(K\) on \(F_R\), and the outer shell has \(L\) points. Set
\[
c=a_3,\quad u=c-a_1,\quad t=c-a_2,\quad z=u+t,
\quad M=\max_T a\cdot x.
\]
The weight assumptions imply
\[
u\ge2,\quad t\ge1,\quad t\le u-1,\quad
c\ge m+1+u,\quad z\ge3,\quad c\ge m+\tfrac32+\tfrac z2.
\]
For \(s>0\), let \(d=(R+1)c-M\). Since \(Rc\le M\le(R+1)c\), we have \(0\le d\le c\). For an outer-shell point \(x=(x_1,x_2,x_3)\), its deficiency from \((R+1)c\) is \(u x_1+t x_2\). Every selected outer-shell point has deficiency at least \(d\). Consequently, with
\[
B=3n-s>0,\qquad A=(R+1)B-12K,\qquad G=A-B=\frac{R(R-1)(R-2)}2-Rs,
\]
the desired left side \(D\) obeys
\[
\begin{aligned}
D
&\ge 3mM-4K(3c-z)-4sM\\
&=B((R+1)c-d)-12Kc+4Kz\\
&=Ac+4Kz-Bd.\tag{1}
\end{aligned}
\]
This inequality is the only estimate on the sum of the chosen shell points.

## The unsupplemented shape \(s=0\), for every \(R\ge5\)

Here \(M=Rc\) and, on writing \(Q=R(R-1)(R-2)/2\),
\[
D\ge Qc+12K\ge Q(n+3)+12K.
\]
Put \(E_0=Q(n+3)+12K-n(n-1)\). If \(v=R-5\), direct polynomial expansion gives
\[
4E_0=240+2028v+1536v^2+453v^3+60v^4+3v^5>0.
\]
This proves the assertion when \(s=0\).

## All radii \(R\ge13\)

Using only \(M\ge Rc\) and \(z\ge3\) in (1) gives
\[
D\ge (Q-Rs)c+12K.
\]
For \(0\le s\le L\) the coefficient is positive: its smallest value is
\[
Q-RL=\frac{R(R^2-9R-4)}2>0.
\]
Therefore it suffices to prove
\[
E(s)=(Q-Rs)(n+s+3)+12K-(n+s)(n+s-1)\ge0.
\]
This is a concave quadratic in \(s\), with leading coefficient \(-(R+1)\). Its minimum on \([0,L]\) is at an endpoint. The endpoint \(s=0\) was proved above. For \(v=R-13\), the other endpoint has expansion
\[
4E(L)=39264+124860v+33708v^2+3549v^3+168v^4+3v^5>0.
\]
This proves every \(R\ge13\), with no computational range cutoff assumption.

## The seven radii \(6\le R\le12\)

Let \(k=L-s\) be the number of omitted shell points and define
\[
J=\min\left(R+1,\left\lceil\frac{k}{2}\right\rceil\right).
\]
We claim \(d\le Ju\). If \(J\le R\), the two outer edges issuing from \((0,0,R+1)\) contain \(2J+1>k\) distinct points with \(x_1+x_2\le J\); all of their deficiencies are at most \(Ju\). At least one is selected. If \(J=R+1\), every shell point has deficiency at most \((R+1)u\). This proves the claim, including \(J=0\).

Since \(z\ge u+1\), equation (1) yields
\[
D\ge f(c,u)=Ac+4K(u+1)-B\min(c,Ju),\quad
u\ge2,\quad c\ge m+1+u.\tag{2}
\]
The exact minimum of this piecewise-linear convex function is elementary. For \(J=0\) or \(1\), its only relevant vertex is \((c,u)=(m+3,2)\), giving
\[
V_0=A(m+3)+12K-2BJ.
\]
For \(J\ge2\), the additional vertex is the intersection of \(c=Ju\) and \(c=m+1+u\), giving
\[
V_1=\frac{(GJ+4K)(m+1)}{J-1}+4K.
\]
In all the cases in this section \(m+1>2(J-1)\), so this vertex belongs to the domain. The recession slopes are \(A\), \(G+4K\), and \(GJ+4K\) (the latter when \(J\ge2\)); they are all nonnegative. For \(J=0\), the slopes are \(A\) and \(A+4K\).

The following table lists the exact smallest value of \(\min(V_0,V_1)-m(m-1)\) over the indicated finite range \(1\le s\le3(R+1)\); \(V_1\) is omitted when \(J\le1\). Substitution of the displayed formulas verifies every row using rational arithmetic. The accompanying script checks every individual value and all recession slopes.

| \(R\) | Minimum slack | A minimizing \(s\) | Corresponding \(J\) |
|---:|---:|---:|---:|
| 6 | \(422\) | 10 | 6 |
| 7 | \(3662\) | 11 | 7 |
| 8 | \(73896/7\) | 12 | 8 |
| 9 | \(92977/4\) | 13 | 9 |
| 10 | \(400820/9\) | 14 | 10 |
| 11 | \(78003\) | 15 | 11 |
| 12 | \(1408782/11\) | 16 | 12 |

Thus (2) proves these seven radii.

## Radius \(R=5\)

Here \(n=46\), \(K=55\), and \(L=18\). Normalize a shell deficiency by \(z=u+t\), and put \(v=t/z\in(0,1/2)\). Its normalized value is
\[
x_1(1-v)+x_2v.
\]
Uniformly in \(v\), the number of shell points with normalized deficiency at most the integer \(h\) is at least the following value \(N_h\):

| \(h\) | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
|---:|---:|---:|---:|---:|---:|---:|---:|
| \(N_h\) | 1 | 4 | 8 | 13 | 15 | 17 | 18 |

These counts have short direct proofs:

- \(h=0\): the point \((0,0,6)\).
- \(h=1\): the three points \((0,j,6-j)\), \(0\le j\le2\), and \((1,0,5)\).
- \(h=2\): if \(v\le1/3\), all seven points \((0,j,6-j)\), plus \((1,0,5)\) and \((2,0,4)\), qualify. If \(v>1/3\), the five points on that first edge with \(j\le4\) and the three points \((i,0,6-i)\), \(1\le i\le3\), qualify.
- \(3\le h\le5\): all seven points \((0,j,6-j)\), the \(h\) points \((i,0,6-i)\), \(1\le i\le h\), and the \(h\) points \((i,6-i,0)\), \(1\le i\le h\), qualify. For the last group, \(i+(6-2i)v\le\max(i,3)\le h\). The three groups are disjoint.
- \(h=6\): all eighteen points qualify.

Choose the smallest listed \(h\) with \(N_h>18-s\). Since only \(18-s\) shell points are omitted, this proves \(d\le hz\). Equation (1) gives
\[
D\ge Ac+4Kz-B\min(c,hz),\qquad
z\ge3,\quad c\ge m+\tfrac32+\tfrac z2.\tag{3}
\]
The first vertex gives
\[
U_0=A(m+3)+12K-3Bh.
\]
For \(h\ge1\), the other vertex, \(c=hz\), gives
\[
U_1=\frac{(Gh+4K)(m+3/2)}{h-1/2}.
\]
It belongs to the domain because \((m+3/2)/(h-1/2)>3\). The recession slopes \(A\), \(G/2+4K\), and \(Gh+4K\) are positive for all these cases. When \(h=0\), only \(U_0\) is needed; its recession slopes are also positive.

Every case has positive slack:

| \(s\) | \(h\) | \(\min(U_0,U_1)-m(m-1)\) |
|---:|---:|---:|
| 1 | 6 | \(12108/11\) |
| 2 | 5 | \(1264\) |
| 3 | 5 | \(8627/9\) |
| 4 | 4 | \(9630/7\) |
| 5 | 4 | \(1050\) |
| 6 | 3 | \(2056\) |
| 7 | 3 | \(1713\) |
| 8 | 3 | \(1356\) |
| 9 | 3 | \(985\) |
| 10 | 3 | \(600\) |
| 11 | 2 | \(2826\) |
| 12 | 2 | \(2454\) |
| 13 | 2 | \(2068\) |
| 14 | 2 | \(1668\) |
| 15 | 1 | \(1623\) |
| 16 | 1 | \(1192\) |
| 17 | 1 | \(747\) |
| 18 | 0 | \(648\) |

Together with the \(s=0\) proof, this proves radius five and completes the theorem.

## Scope

This settles every one-shell extension \(F_R\subseteq T\subseteq F_{R+1}\) for \(R\ge5\), uniformly over an unbounded range of radii and weights. It does not assert that arbitrary three-face order ideals have this form, and it does not settle Wilf's conjecture in embedding dimension four.

The exact arithmetic checker is `face_shell_verify.py`. It requires only Python's standard library and produces `face_shell_verification.json`. It does not enumerate subsets of the shell, perform floating-point optimization, or use any numerical-semigroup enumeration.
