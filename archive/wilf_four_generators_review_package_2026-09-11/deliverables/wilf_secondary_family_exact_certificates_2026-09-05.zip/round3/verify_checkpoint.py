"""Reproduce the exact certificates in this checkpoint, not all of Wilf."""
from pathlib import Path
import subprocess
import sys
import json

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = [
    'round3/audit/quotient_two_certificate.py',
    'round3/secondary/quotient_two_formulas.py',
    'round3/arithmetic/face_shell_verify.py',
    'round3/horns_optimization/fullcap_boundary_verify.py',
    'round3/horns_optimization/ansatz/exact_counterexample.py',
]
rows = []
for script in SCRIPTS:
    result = subprocess.run([sys.executable, script], cwd=ROOT,
                            text=True, capture_output=True, timeout=60)
    rows.append(dict(script=script, returncode=result.returncode,
                     stdout=result.stdout, stderr=result.stderr))
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(f'FAILED: {script}')
    print(f'PASS: {script}')

out = dict(status='All listed exact certificates and invariant checks passed.',
           scope='No unrestricted four-generator proof or counterexample.',
           checks=rows)
(ROOT/'round3/checkpoint_verification.json').write_text(json.dumps(out, indent=2)+'\n')
print('All exact checks passed. The unrestricted four-generator conjecture remains unresolved by this work.')
