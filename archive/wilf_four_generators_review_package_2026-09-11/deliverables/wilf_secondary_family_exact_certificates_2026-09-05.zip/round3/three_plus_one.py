"""Exact diagnostic for an adjoining-one-generator closing inequality."""
from heapq import heappop, heappush
from math import gcd
from functools import reduce
from pathlib import Path
import json
import random


def invariants(gens):
    gens=tuple(sorted(gens)); m=gens[0]
    if reduce(gcd,gens)!=1:return None
    w=[None]*m;w[0]=0;h=[(0,0)]
    while h:
        d,r=heappop(h)
        if w[r]!=d:continue
        for a in gens[1:]:
            rr=(r+a)%m;v=d+a
            if w[rr] is None or v<w[rr]:
                w[rr]=v;heappush(h,(v,rr))
    contains=lambda v:v>=0 and v>=w[v%m]
    if any(contains(a-b) for a in gens for b in gens if b<a):return None
    c=max(w)-m+1;g=sum(v//m for v in w);n=c-g
    return dict(gens=gens,m=m,c=c,g=g,n=n,W=len(gens)*n-c,apery=w)


def main():
    rng=random.Random(2026090601);valid=eligible=0
    any_failure=None;all_failure=None;minimum=None
    for attempt in range(10000):
        m=rng.randint(5,180)
        scale=rng.choice((3,10,m))
        gens=(m,*sorted(rng.sample(range(m+1,scale*m+1),3)))
        S=invariants(gens)
        if S is None:continue
        valid+=1;rows=[]
        for j in range(1,4):
            base=gens[:j]+gens[j+1:]
            T=invariants(base)
            if T is None:continue
            delta=T['c']-S['c'];H=T['g']-S['g']
            score=T['n']+4*H-3*delta
            assert S['W']==T['W']+score
            # Check the min-plus representation on each residue exactly.
            kmax=m//gcd(m,gens[j])
            expected=[min(k*gens[j]+T['apery'][(r-k*gens[j])%m]
                          for k in range(kmax)) for r in range(m)]
            assert expected==S['apery']
            rows.append(dict(added=gens[j],base=base,base_W=T['W'],
                             base_c=T['c'],base_n=T['n'],delta=delta,H=H,score=score))
        if len(rows)!=3:continue
        eligible+=1
        rec={'gens':gens,'c':S['c'],'n':S['n'],'W4':S['W'],'rows':rows}
        if any_failure is None and min(r['score'] for r in rows)<0:any_failure=rec
        best=max(r['score'] for r in rows)
        if minimum is None or best<minimum['best_score']:
            minimum={'best_score':best,**rec}
        if best<0:
            all_failure=rec;break
    out={'status':'exact identities passed; search is diagnostic',
         'attempts':attempt+1,'valid':valid,'eligible':eligible,
         'one_extension_sufficient_inequality_failure':any_failure,
         'every_extension_sufficient_inequality_failure':all_failure,
         'minimum_best_extension':minimum}
    Path(__file__).with_name('three_plus_one_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
