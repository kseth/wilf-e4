# Horn optimization results

The unrestricted monotone-horn inequality remains unproved in this branch. Two concrete results were completed.

1. **The capped-balanced optimal-profile ansatz is false.** At `a=1/5,b=c=2/5`, an exact feasible boundary zigzag attains `J=171/40000`, exceeding the maximum over all capped-balanced cap choices by `1/120000`. Full proof and standard-library exact verification are in `ansatz/ansatz_counterexample.md` and `ansatz/exact_counterexample.py`.

2. **The full-cap plateau/boundary three-horn class is proved.** For any positive central sides with sum at most one, assume each horn initially uses its full central caps until their sum reaches the simplex boundary, then follows any monotone profile on that boundary. The sum of all three horn objectives is at most the central credit. The proof optimizes every boundary profile, including zigzags; it does not assume a balanced taper. See `fullcap_boundary_theorem.md`.

The exact boundary optimizer has one tent, with parameter `q=min(C,(1-B)/2)` for sorted caps `B>=C`. For ordered central sides `a<=b<=c`, define `δ=1-a-b-c`, `x=b-a`, `y=c-b`, and `e2=ab+ac+bc`. The final certified lower bound on central credit minus the three optimized horn values is

`δ² e2/2+δ x²(2x+3y)/6+x²y²/8+(7/24)x³y+(31/192)x⁴ >=0`.

The standard-library verifier `fullcap_boundary_verify.py` proves the four polynomial identities with exact rational coefficient arithmetic; `fullcap_boundary_verification.json` records its successful checks. The sharp-stability agent independently audited the control envelopes, feasible parameter range, equality cases, and precise scope, and reran the checker successfully.

**Remaining obligation:** arbitrary underfilled initial rectangles and arbitrary multiple off-boundary plateaus are not covered. The full-cap hypothesis must not be silently removed when using this theorem.

The canonical-global numerical probe is diagnostic only; the exact theorem and counterexample rely on the displayed analytic arguments and exact arithmetic checkers instead.
