"""Exact rational certificate against the capped-balanced horn ansatz.

No external dependencies. This is a counterexample to profile optimality,
not to the desired total three-horn inequality or Wilf's conjecture.
"""
from fractions import Fraction as Q
from pathlib import Path
import json


def multiply(p,q):
    out=[Q(0)]*(len(p)+len(q)-1)
    for i,x in enumerate(p):
        for j,y in enumerate(q):out[i+j]+=x*y
    return out


def integrate(poly,lo,hi):
    return sum(c*(hi**(i+1)-lo**(i+1))/(i+1) for i,c in enumerate(poly))


def integral_segment(u,v,lo,hi):
    # u,v are affine polynomials in r. Sum constraints ensure F simplification.
    uv=multiply(u,v)
    coefficient=[Q(1)+Q(3,2)*(u[0]+v[0]),-Q(3)+Q(3,2)*(u[1]+v[1])]
    return integrate(multiply(uv,coefficient),lo,hi)


def capped_balanced(R,U,V):
    U,V=max(U,V),min(U,V)
    return U*V*(R-Q(3,2)*R*R+(Q(3,2)*R-Q(1,2))*U+(Q(3,2)*R-1)*V-U*U/2-Q(3,4)*U*V)+V**3/6-V**4/4

R=Q(4,5); B=Q(2,5)
segments=[([Q(0),Q(1,2)],[Q(0),Q(1,2)],Q(0),Q(3,5)),
          ([Q(3,10),Q(0)],[-Q(3,10),Q(1)],Q(3,5),Q(7,10)),
          ([-Q(2,5),Q(1)],[Q(2,5),Q(0)],Q(7,10),Q(4,5))]
J=sum(integral_segment(*x) for x in segments)
base=capped_balanced(R,B,B)
assert J==Q(171,40000)
assert base==Q(8,1875)
assert J-base==Q(1,120000)
# Every segment is continuous, nonnegative, nondecreasing, caps <=B, and u+v=r.
for u,v,lo,hi in segments:
    assert u[1]>=0 and v[1]>=0
    assert u[0]+v[0]==0 and u[1]+v[1]==1
    for r in [lo,hi]:
        assert 0<=u[0]+u[1]*r<=B
        assert 0<=v[0]+v[1]*r<=B
# Positive quadratic in dJ/dV along full U cap:
# V^2 - V/10 + 1/25 = (V-1/20)^2 + 3/80.
assert Q(1,400)+Q(3,80)==Q(1,25)
result={'a':'1/5','b':'2/5','c':'2/5','best_capped_balanced_J':str(base),
        'alternative_J':str(J),'strict_gain':str(J-base),
        'status':'Exact counterexample to capped-balanced optimality; no Wilf counterexample.'}
Path(__file__).with_name('exact_counterexample.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
