# The capped-balanced single-horn ansatz is false

This note concerns only single-horn profile optimization. It does **not** provide a counterexample to Wilf's conjecture, or to the combined three-horn inequality.

## Functional and candidate family

Put \(R=1-a\), and reverse the variable by \(r=1-t\). The functional becomes

\[
J[u,v]=\int_0^R uv\,[1-3r+\tfrac32(u+v)]\,dr,
\]

where \(u,v\) are nondecreasing, \(0\le u\le b\), \(0\le v\le c\), and \(u+v\le r\). We assume \(b+c\le R\).

For chosen caps \(U\ge V\), the candidate capped-balanced profile is

\[
(u,v)=\begin{cases}
(r/2,r/2),&0\le r\le2V,\\
(r-V,V),&2V\le r\le U+V,\\
(U,V),&U+V\le r\le R.
\end{cases}
\]

Direct integration gives

\[
\boxed{
J_R(U,V)=UV\left[R-\tfrac32R^2+
(\tfrac32R-\tfrac12)U+(\tfrac32R-1)V
-\tfrac12U^2-\tfrac34UV\right]
+\tfrac16V^3-\tfrac14V^4.
}
\]

The derivative identities are

\[
\boxed{\partial_U J_R=V(R-U-V)(1-\tfrac32R+\tfrac32U)}
\]

and

\[
\boxed{\partial_V J_R=
\tfrac12(U-V)^2(1-U-2V)+
U(R-U-V)(1-\tfrac32R+\tfrac32V).}
\]

For fixed \(V\), the derivative in \(U\) changes sign at most once, from negative to positive. Thus the maximum in the larger cap lies at \(U=V\) or its allowed upper endpoint. On the balanced branch,

\[
J_R(d,d)=(R-\tfrac32R^2)d^2+(3R-\tfrac43)d^3-\tfrac32d^4,
\]

\[
\frac{d}{dd}J_R(d,d)=d(R-2d)(2-3R+3d).
\]

This branch likewise attains its maximum at one of its two endpoints.

## Exact counterexample

Take

\[
a=\tfrac15,\qquad b=c=\tfrac25,\qquad R=\tfrac45.
\]

First establish the best value within the candidate family. By symmetry suppose \(U\ge V\). The preceding derivative reduction leaves the balanced branch or \(U=2/5\). On the balanced branch the maximum is at \(d=0\) or \(d=2/5\). On the other branch,

\[
\partial_V J_{4/5}(2/5,V)
=(\tfrac25-V)(V^2-\tfrac1{10}V+\tfrac1{25})
\ge0.
\]

The quadratic is strictly positive because it equals
\((V-1/20)^2+3/80\). Hence the maximum over **all chosen candidate caps** is

\[
\max_{0\le U,V\le2/5}J_{4/5}(U,V)
=J_{4/5}(2/5,2/5)=\frac8{1875}.
\]

Now choose a different feasible profile:

\[
(u,v)=\begin{cases}
(r/2,r/2),&0\le r\le3/5,\\
(3/10,r-3/10),&3/5\le r\le7/10,\\
(r-2/5,2/5),&7/10\le r\le4/5.
\end{cases}
\]

Both coordinates are continuous and nondecreasing, they stay in \([0,2/5]\), and \(u+v=r\) throughout. Direct exact integration gives

\[
\boxed{J[u,v]=\frac{171}{40000}
=\frac8{1875}+\frac1{120000}
>\max_{U,V}J_{4/5}(U,V).}
\]

Equivalently, the excess over the balanced profile is

\[
-\int_{3/5}^{7/10}(r/2-3/10)^2(1-3r/2)\,dr
-\int_{7/10}^{4/5}(r/2-2/5)^2(1-3r/2)\,dr
=\frac1{120000}.
\]

The obstruction is the sign change at \(r=2/3\). At larger \(r\), maximizing the product \(uv\) while keeping \(u+v=r\) decreases the objective. A controlled departure from balance, followed by a second capped segment, improves the integral.

## A family of improving profiles

For equal caps \(B\), endpoint \(R=2B\), and a parameter \(0\le q\le B\), use

\[
(u,v)=\begin{cases}
(r/2,r/2),&0\le r\le2q,\\
(q,r-q),&2q\le r\le B+q,\\
(r-B,B),&B+q\le r\le2B.
\end{cases}
\]

The difference from the fully balanced profile is

\[
\Delta(B,q)=\frac{(B-q)^3[3(B+q)-2]}{12}.
\]

For \(1/3<B\le1/2\), this expression is maximized at
\(q=(1-B)/2\), giving

\[
\boxed{\Delta_{\max}(B)=\frac{(3B-1)^4}{192}>0.}
\]

For \(B=2/5\), this is precisely the exact counterexample above. This family only proves improvement over the full balanced profile; the comparison with the optimum over every capped-balanced profile was established explicitly at \(B=2/5\).

## The smaller selected cap can also optimize in the interior

Even inside the candidate family, reducing to both full caps is invalid. For

\[
R=17/20,\quad b=3/5,\quad c=1/4,
\]

on the \(U=b\) branch,

\[
\partial_V J_R=\frac{123}{4000}-\frac{21}{100}V+\frac12V^2-V^3.
\]

This is positive at \(V=1/5\) and negative at \(V=1/4\), yielding an interior local maximum. Its derivative is strictly decreasing over this interval, so the maximum there is unique. A correct finite-dimensional candidate optimization must allow roots of this cubic.

## Verification files and scope

`exact_counterexample.py` uses only Python's exact rational arithmetic and checks all three pieces, feasibility at segment endpoints, exact integrals, and the strict gain. `exact_counterexample.json` records its output. `probe.py` and `probe_results.json` record the exploratory numerical search that found the profile; the proof above does not depend on floating-point optimization.

The general monotone single-horn optimization remains open in this note. The capped-balanced optimality ansatz cannot supply its missing proof.
