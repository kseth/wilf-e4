import numpy as np
from scipy.optimize import minimize, differential_evolution, LinearConstraint
import json
from pathlib import Path

N=56

def value(a,U,V):
    R=1-a;U,V=max(U,V),min(U,V)
    return U*V*(R-1.5*R*R+(1.5*R-.5)*U+(1.5*R-1)*V-.5*U*U-.75*U*V)+V**3/6-V**4/4

def caps(a,b,c):
    q=differential_evolution(lambda x:-value(a,*x),[(0,b),(0,c)],tol=1e-10,popsize=8,seed=164,polish=True)
    return q.x, -q.fun

def profile(r,U,V):
    u=np.minimum(U,np.maximum(r-V,r/2));v=np.minimum(V,np.maximum(r-U,r/2))
    return u,v

def probe(a,b,c,rng):
    R=1-a;r=(np.arange(N)+.5)*R/N
    upper=np.zeros((N,2*N));upper[np.arange(N),np.arange(N)]=1;upper[np.arange(N),N+np.arange(N)]=1
    mono=np.zeros((2*(N-1),2*N))
    for j in range(2):
      for i in range(N-1):mono[j*(N-1)+i,j*N+i]=-1;mono[j*(N-1)+i,j*N+i+1]=1
    con=[LinearConstraint(upper,0,r),LinearConstraint(mono,0,np.inf)]
    def obj(z):
      u,v=z[:N],z[N:];return -np.mean(u*v*(1-3*r+1.5*(u+v)))*R
    def jac(z):
      u,v=z[:N],z[N:];return -np.r_[v*(1-3*r+3*u+1.5*v),u*(1-3*r+1.5*u+3*v)]*R/N
    (U,V),J=caps(a,b,c)
    ans=np.r_[*profile(r,U,V)];ja=-obj(ans)
    best=(-obj(ans),ans)
    for ini in [ans,np.r_[*profile(r,b,c)],np.r_[*profile(r,b*rng.random(),c*rng.random())]]:
      q=minimize(obj,ini,jac=jac,bounds=[(0,b)]*N+[(0,c)]*N,constraints=con,method='SLSQP',options={'ftol':1e-13,'maxiter':600})
      if -q.fun>best[0]:best=(-q.fun,q.x)
    return dict(a=a,b=b,c=c,cap_U=U,cap_V=V,ansatz_exact=J,ansatz_grid=ja,optimized_grid=best[0],improvement=best[0]-ja,profile=best[1].tolist())

rng=np.random.default_rng(128)
ps=[(a,b,c) for a,b,c in [(0,.5,.5),(.1,.45,.45),(.2,.4,.4),(.1,.7,.2),(.2,.65,.15),(.01,.5,.2),(.3,.5,.2)]]
for i in range(30):
    x=rng.dirichlet([1,1,1,1]);ps.append(tuple(x[:3]))
out=[]
for p in ps:
    z=probe(*p,rng);out.append(z)
    print({k:v for k,v in z.items() if k!='profile'},flush=True)
Path(__file__).with_name('probe_results.json').write_text(json.dumps(out,indent=2))
