from fractions import Fraction as Q

def add(*ps):
 o={}
 for p in ps:
  for k,v in p.items():o[k]=o.get(k,Q(0))+v
 return {k:v for k,v in o.items() if v}
def mul(p,q):
 o={}
 for i,a in p.items():
  for j,b in q.items():
   k=tuple(x+y for x,y in zip(i,j));o[k]=o.get(k,Q(0))+a*b
 return {k:v for k,v in o.items() if v}
def scale(p,q):return {k:v*q for k,v in p.items() if v*q}
def sq(p):return mul(p,p)
a={(1,0,0):Q(1)};b={(0,1,0):Q(1)};c={(0,0,1):Q(1)};S=add(a,b,c)
def J(R,U,V):
 inside=add(mul(R,S),scale(sq(R),Q(-3,2)),scale(mul(R,U),Q(3,2)),scale(mul(U,S),Q(-1,2)),scale(mul(R,V),Q(3,2)),scale(mul(V,S),-1),scale(sq(U),Q(-1,2)),scale(mul(U,V),Q(-3,4)))
 return add(mul(mul(U,V),inside),scale(mul(mul(sq(V),V),S),Q(1,6)),scale(sq(sq(V)),Q(-1,4)))
credit=scale(mul(mul(mul(a,b),c),S),Q(1,2))
difference=add(credit,scale(J(add(b,c),c,b),-1),scale(J(add(a,c),c,a),-1),scale(J(add(a,b),b,a),-1))
x=add(b,scale(a,-1));y=add(c,scale(b,-1));z=add(c,scale(a,-1))
target=scale(mul(sq(x),add(scale(sq(z),2),sq(y))),Q(1,12))
assert add(difference,scale(target,-1))=={}
print('PASS: central credit minus sum full-cap canonical horns = (b-a)^2*[2(c-a)^2+(c-b)^2]/12 for a<=b<=c, a+b+c=1.')
