import numpy as np
from scipy.optimize import differential_evolution,minimize
import json

def J(a,U,V):
 if U<V:U,V=V,U
 R=1-a
 return U*V*(R-1.5*R*R+(1.5*R-.5)*U+(1.5*R-1)*V-.5*U*U-.75*U*V)+V**3/6-V**4/4

def opt(a,b,c):
 if b>c:b,c=c,b
 R=1-a;U=c
 coeff=[-1,.5,2*U*(1.5*R-1-.75*U),U*(R-1.5*R*R+(1.5*R-.5)*U-.5*U*U)]
 vs=[0,b]+[float(r.real) for r in np.roots(coeff) if abs(r.imag)<1e-8 and 0<r.real<b]
 vals=[(J(a,U,v),U,v) for v in vs]+[(0,0,0),(J(a,b,b),b,b)]
 return max(vals)

def objective(x):
 a,b=x;c=1-a-b
 if c<0:return 1e3-c
 js=[opt(a,b,c),opt(b,a,c),opt(c,a,b)]
 margin=a*b*c*.5-sum(j[0] for j in js)
 return margin

best=(1,None)
for i in range(1,100):
 for j in range(i,100-i):
  a=i/100;b=j/100;c=1-a-b
  if c<b:continue
  v=objective([a,b])
  if v<best[0]:best=(v,(a,b,c))
print('GRID',best,flush=True)
r=minimize(objective,best[1][:2],method='Nelder-Mead',options={'xatol':1e-12,'fatol':1e-14,'maxiter':2000})
a,b=r.x;c=1-a-b
out={'a':a,'b':b,'c':c,'margin':r.fun,'horns':[opt(a,b,c),opt(b,a,c),opt(c,a,b)]};print(json.dumps(out),flush=True)
open('round3/horns_optimization/canonical_global_results.json','w').write(json.dumps(out,indent=2))
