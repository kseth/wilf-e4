# Rectangular horn reductions: proved bridges and the remaining slack obstruction

This note concerns the no-interior-corner geometric route to Wilf's
conjecture. It does not complete that route or claim a proof of Wilf's
conjecture. The independently audited clique-tree theorem reduces the
continuous geometry to a central box and at most three horns with nested
rectangular fibers. Normalize the maximum of `x+y+z` to one and write

`J(K)=integral_K [3(x+y+z)-2] dV`.

The desired continuous mean inequality is `J(K)<=0`. For an outward
coordinate `t`, with transverse side lengths `u(t),v(t)`, the horn integrand
is

`F(t;u,v)=uv[3t+(3/2)(u+v)-2]`.

## 1. Finite endpoint convexity: proved

Fix a finite nested sequence of nonnegative transverse rectangles,

`u_1>=...>=u_n`, `v_1>=...>=v_n`,

and a starting coordinate `a`. Put `A_i=u_i v_i`, `S_i=u_i+v_i`.
Let rectangle `i` occupy the interval `(t_(i-1),t_i]`, where

`a=t_0<=t_1<=...<=t_n`, and `t_i<=1-S_i`.

These endpoint inequalities are exactly the height constraints for these
fixed nested rectangles. Their total objective is

`J=sum_i A_i[(3/2)(t_i^2-t_(i-1)^2)+((3/2)S_i-2)(t_i-t_(i-1))]`.

As a function of the endpoints, this is a convex quadratic: its quadratic
coefficient at `t_i` is `(3/2)(A_i-A_(i+1))>=0`, using `A_(n+1)=0`, and
there are no cross terms. A maximum on the compact endpoint polytope is
therefore attained at a vertex.

At a vertex, each block of equal endpoint values either has value `a` or
hits an upper bound. Otherwise the entire block can move slightly in both
directions, contradicting extremality. Since `1-S_i` is nondecreasing,
a positive-length surviving slab ends at the upper bound belonging to
its first index in the corresponding block. Coalescing equal endpoints
and deleting zero-length slabs therefore gives a horn of at least the
same objective such that every surviving right endpoint is tight:

`t_i+u_i+v_i=1`.

Thus arbitrary finite step horns can be reduced to endpoint-tight
staircases. This statement does not assert that their entire profiles
lie on the height boundary.

## 2. Exact signed staircase formula: proved

For a tight slab with previous endpoint `t_0`, next endpoint `t_1`, and
rectangle `u_1 v_1`, direct integration yields

`J_slab=((3t_0-1)/2)(t_1-t_0)u_1v_1`.

The sign is determined by the left endpoint, not by the right endpoint.
Consequently an endpoint-tight staircase gives a signed left/right
Riemann sum. Its early slabs, with `t_0<1/3`, can retain a real advantage
over a continuous interpolation.

In reverse coordinates, a plane state with caps `(u,v)` has sum `r=u+v`.
A jump to nested caps `(x,y)` contributes exactly

`(1-(3/2)r)(r-x-y)xy`.

This is the appropriate transition payoff for a Bellman formulation.

## 3. A valid boundary bridge after the sign threshold: proved

Assume the horn begins at `a>=1/3`, and its full available starting caps
`B,C` satisfy `a+B+C=1`. Then every nested rectangular profile with these
caps and `t+u(t)+v(t)<=1` is dominated in objective by a profile on the
height boundary.

Here is an explicit construction, including discontinuous input
profiles. Reverse coordinates by `r=1-t`, with `0<=r<=R=B+C`. The original
sides `u(r),v(r)` are nondecreasing and have sum at most `r`. At the single
endpoint `R`, assign `u(R)=B`, `v(R)=C`; changing endpoint values has no
effect on the integrals. Define

`f(r)=sup_(0<=s<=R) [u(s)-max(0,s-r)]`, and `g(r)=r-f(r)`.

Each function inside the supremum is nondecreasing and 1-Lipschitz;
therefore so is `f`, and `g` is also nondecreasing. Clearly `f>=u`.
For `s<=r`, the expression in brackets is at most `u(r)<=r-v(r)`.
For `s>=r`, it is at most `r-v(s)<=r-v(r)`. Hence `f<=r-v(r)`, so `g>=v`.
The endpoint assignments give `f<=B`, `g<=C`, and `f(R)=B`, `g(R)=C`.
Thus `(f,g)` is a nested boundary profile majorizing the original profile.

Set `w(t)=(3t-1)/2>=0` and
`delta(t)=1-t-u(t)-v(t)>=0`. Its original fiber objective is

`uv[w(t)-(3/2)delta(t)] <= uv w(t) <= fg w(t)`.

The last expression is exactly the boundary majorant's objective.
Integrating proves the bridge.

Because `R<=2/3`, the best boundary profile in this case maximizes the
fiber product pointwise: it balances the two side lengths subject to
their caps. In particular, if the central box has all three sides `1/3`,
the bridge applies to all its arbitrary slack horns and proves their
union has mean at most `2/3`.

The hypothesis `B+C=1-a` is material to this direct majorant construction.
The following stronger argument accounts for the initial slack interval.

### 3.1 Stronger late-horn theorem allowing central slack: audited proof

The theorem in `round3/descent/late_horn_potential.md` removes the full-sum
hypothesis: for every `a>=1/3`, `B,C>=0`, `a+B+C<=1`, an arbitrary
rectangular-fiber horn satisfies

`J_horn<=H(a;x,y)`, where `x=min(B,C)`, `y=max(B,C)`,

`H(a;x,y)=P(x,y)+(3a-1)xy(1-a-x-y)/2`.

Here `P` is the capped-balanced boundary integral defined in Section6.
Equality is attained by retaining the full caps until their tight endpoint
and then using the capped-balanced boundary tail.

For a finite horn, first apply endpoint convexity. Retain its first
constant rectangle, with effective caps `(b,c)`, from `a` to `1-b-c`.
Between subsequent tight endpoints, interpolate both sides linearly along
the height boundary. The new rectangle has product `p>=p_0`, where `p_0`
is the old slab product. In reverse time `u=1-t`, its pointwise objective
gain is

`(p-p_0)(1-(3/2)u)+(3/2)p_0(u-s)>=0`,

where `s` is the old rectangle side sum. Both terms are nonnegative since
`u<=1-a<=2/3` and `s<=u`. Complete the boundary tail to zero as well.
The boundary objective then increases by pointwise product maximization,
giving `H(a;min(b,c),max(b,c))`.

It remains to raise the effective caps to the full caps. Set
`r=1-a-x-y>=0`. Exact differentiation gives

`H_y=xr[3(a+y)-1]/2>=0`,

`H_x=[(a-x)(x-y)^2+r(x^2+2ay-yr)]/2>=0`.

For the second sign, `x<=(1-a)/2<=a` and `r<=1-a<=2a` make every
displayed term nonnegative. Symmetry treats reordered caps. Thus `H` is
nondecreasing in each cap, proving the full-cap bound. The displayed
`H_x` factorization was also checked on50 exact rational admissible
triples; the factorization and sign argument, rather than this finite
check, prove monotonicity.

General bounded monotone profiles follow by approximation with finite
step profiles from below and dominated convergence. The approximation
preserves the height constraint. This theorem is therefore valid for
arbitrary central slack, while the earlier-base case `a<1/3` remains
unresolved.

## 4. Unconditional staircase interpolation is false: exact example

Suppose one tight step changes only one transverse side, keeping the
other side `v` fixed. Let its time increment be `Delta=t_1-t_0`, and let
its final smaller side be `u_1`, so `t_1+u_1+v=1`. Replacing the plateau
by the straight boundary segment with side `u(t)=u_1+t_1-t` changes the
objective by

`J_boundary-J_step = v Delta^2(2-3v-2Delta)/4`.

This can be negative. Take the central corner

`(t_0,u_0,v)=(1/20,3/20,4/5)`

and the next tight corner

`(t_1,u_1,v)=(3/20,1/20,4/5)`.

Then `Delta=1/10` and the difference is exactly `-3/2500`.
Thus simply filling each tight staircase to the height boundary is not a
valid extremality proof. This example concerns the interpolation step;
it is not a counterexample to the mean inequality or to Wilf's conjecture.

There is also a positive-horn obstruction to merely omitting troublesome
horns. With that same central box, use effective caps `(1/20,4/5)` in the
outward first coordinate, keep them constant up to the boundary, and
then use their balanced capped taper. Its objective is
`613/1920000>0`, whereas the optimal boundary horn using the full initial
caps has objective `-1/4800`. Effective caps cannot be ignored.

## 5. Boundary optimization independently audited: proved in its scope

The full theorem in
`round3/horns_optimization/fullcap_boundary_theorem.md` was independently
checked. It proves the sharp mean bound for a central box of arbitrary
side sum at most one, when each horn first uses the full central caps on
its entire initial plateau, then follows an arbitrary monotone boundary
profile.

For sorted boundary caps `B>=C`, the difference of the two sides is
1-Lipschitz between

`L(r)=max(0,r-2C)` and `U(r)=min(r,2B-r)`.

At the sign switch `r=2/3`, fixing its value gives a simultaneously
attainable lower envelope before the switch and upper envelope after it.
The resulting one-parameter profile has optimum

`q*=min(C,(1-B)/2)`.

The gain over the capped-balanced profile is, with
`w=(B+2C-1)_+` and `y=B-C`,

`w^2 y^2/8+w^3 y/24+w^4/192`.

The envelope feasibility, maximizing parameter, and gain coefficients
were checked analytically. The accompanying exact polynomial checker
also passed. This theorem explicitly excludes underfilled initial caps
and multiple off-boundary plateaus.

## 6. The remaining Bellman conjecture

Let `Q(x,y)` be the exact optimum for a continuous boundary horn with
caps `x<=y`. Put `k=min(x,(1-y)/2)` and

`P(x,y)=x^3/6-x^4/4+xy^2/2-3x^2y^2/4-xy^3/2`.

Then

`Q(x,y)=P(k,y)+integral_(y+k)^(x+y) y(r-y)(1-(3/2)r) dr`.

A plausible missing bridge is that every endpoint-tight staircase is
dominated by one initial constant slab with effective caps, followed by
this optimal continuous boundary continuation. Equivalently, the
single-jump envelope built from `Q` would be closed under all nested
Bellman transitions.

The targeted checker `probe_slack_bridge.py` compared that envelope with
the full multiple-jump dynamic program on grids of denominators 40, 80,
and 160. No gap was found. This is numerical evidence only, not a proof.

One valid two-jump reduction helps identify the obstruction. Fix an
initial cap sum `r>2/3`, an intermediate rectangle `(x,y)` with sum `s`,
and final caps `(u,v)` with sum `t`. The two-jump payoff before the final
continuation is

`F=(1-(3/2)r)(r-s)xy+(1-(3/2)s)(s-t)uv`.

At fixed `s`, the coefficient of `xy` is nonpositive. Hence an optimizing
intermediate rectangle may be chosen at an endpoint of its feasible
fixed-sum interval: at least one of its coordinates meets an initial or
final cap bound. A balanced interior rectangle is a minimum, not a
maximum, unless the coefficient vanishes. This reduces potential
obstructions to cap-boundary cases, but does not establish closure of
the single-jump envelope.

Two genuine steps remain before this approach could prove the universal
no-interior mean bound: prove a valid reduction for arbitrary slack
profiles based at `a<1/3`, and control the effective-cap horn maxima jointly against the
central-box contribution. Neither follows from the finite grid probe.
