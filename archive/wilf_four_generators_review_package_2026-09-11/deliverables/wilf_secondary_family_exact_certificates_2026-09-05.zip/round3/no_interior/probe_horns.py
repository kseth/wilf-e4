"""Numerical search in a capped-balanced horn family; not a proof."""
from scipy.optimize import differential_evolution
from pathlib import Path
import json


def horn(a,B,C):
    B,C=max(B,C),min(B,C)
    t0=1-B-C;t1=1-2*C
    V=B*C*(t0-a)
    J=.5*(3*a-1)*V
    P=lambda t:C*((1-C)*t-t*t/2)
    Q=lambda t:C*(-t**3/2+(1-.75*C)*t*t-.5*(1-C)*t)
    V+=P(t1)-P(t0)+2*C**3/3
    J+=Q(t1)-Q(t0)+2*C**3/3-1.5*C**4
    return V,J


def decode(x):
    c=[x[0],(1-x[0])*x[1],(1-x[0])*(1-x[1])*x[2]]
    caps=[]
    for i in range(3):
        others=[c[j] for j in range(3) if j!=i]
        caps.append([others[0]*x[3+2*i],others[1]*x[4+2*i]])
    return c,caps


def score(x):
    c,caps=decode(x)
    V=c[0]*c[1]*c[2];J=V*(1.5*sum(c)-2)
    for a,(B,C) in zip(c,caps):
        v,j=horn(a,B,C);V+=v;J+=j
    return J/V


def main():
    r=differential_evolution(lambda x:-score(x),[(.00001,.99999)]*3+[(0,1)]*6,seed=3819,popsize=12,maxiter=300,tol=1e-10,polish=True)
    c,caps=decode(r.x)
    result={'normalized_J':score(r.x),'mu':(score(r.x)+2)/3,'central':c,'caps':caps,'parameters':r.x.tolist(),'status':'Numerical optimization only.'}
    Path(__file__).with_name('horn_probe.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
