"""Targeted counterexample search; numerical results are not a theorem."""
import numpy as np
from scipy.optimize import linprog
import random,json,time
from pathlib import Path

rng=random.Random(6192026)
N=18
grid=np.indices((N,N,N)).reshape(3,-1).T

def score(p):
    f,g,h=p
    ok=(grid[:,1]<f[grid[:,0]])&(grid[:,2]<g[grid[:,0]])&(grid[:,2]<h[grid[:,1]])
    t=grid[ok]
    if not len(t):return None
    mu=t.mean(axis=0)+.5
    # Checking all cells keeps the geometric normalization exact up to LP precision.
    r=linprog(-mu,A_ub=t+1,b_ub=np.ones(len(t)),bounds=[(0,None)]*3,method='highs')
    assert r.success
    return -r.fun,len(t),r.x.tolist()

best=(0,None)
for trial in range(5):
    p=np.array([[max(1,N-i) for i in range(N)] for _ in range(3)])
    if trial==0:p[2]=[1]*N
    cur=score(p)
    for step in range(1500):
        z=p.copy();j=rng.randrange(3);i=rng.randrange(N)
        lo=int(z[j,i+1]) if i+1<N else 0
        hi=int(z[j,i-1]) if i else N
        z[j,i]=rng.randint(lo,hi)
        s=score(z)
        temp=.005*(1-step/1500)
        if s and (s[0]>=cur[0] or rng.random()<np.exp((s[0]-cur[0])/max(temp,1e-8))):p=z;cur=s
        if cur[0]>best[0]:
            best=(cur[0],{'score':cur[0],'m':cur[1],'weights':cur[2],'profiles':p.tolist(),'trial':trial,'step':step})
            print(json.dumps(best[1]),flush=True)
        if cur[0]>2/3+1e-8:break
    if best[0]>2/3+1e-8:break
Path(__file__).with_name('continuous_probe.json').write_text(json.dumps(best[1],indent=2)+'\n')
