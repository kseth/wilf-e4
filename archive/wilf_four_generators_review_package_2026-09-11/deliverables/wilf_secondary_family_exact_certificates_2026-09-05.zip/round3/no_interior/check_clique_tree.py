"""Exact finite checks of clique-tree and horn identities; not a universal proof."""
from itertools import product
from pathlib import Path
import random,json


def maxima(T):
    return sorted(x for x in T if all(tuple(v+(i==j) for i,v in enumerate(x)) not in T for j in range(3)))


def tree(z):
    n=len(z); used={0}; edges=[]
    while len(used)<n:
        _,a,b=max((sum(min(x,y)+1 for x,y in zip(z[a],z[b])),a,b) for a in used for b in range(n) if b not in used)
        edges.append((a,b));used.add(b)
    return edges


def path(adj,a,b):
    prev={a:None};todo=[a]
    for x in todo:
        if x==b:break
        for y in adj[x]:
            if y not in prev:prev[y]=x;todo.append(y)
    out=[]
    while b is not None:out.append(b);b=prev[b]
    return out[::-1]


def check(T):
    z=maxima(T);E=tree(z);adj=[[] for _ in z]
    for a,b in E:adj[a].append(b);adj[b].append(a)
    for j in range(3):
        for r in range(1+max(x[j] for x in z)):
            nodes={i for i,x in enumerate(z) if x[j]>=r}
            a=next(iter(nodes))
            for b in nodes:assert all(v in nodes for v in path(adj,a,b))
    leaves=[i for i,a in enumerate(adj) if len(a)==1]
    assert len(leaves)<=3
    chosen=[max(range(len(z)),key=lambda i:z[i][j]) for j in range(3)]
    med=set(path(adj,chosen[0],chosen[1]))&set(path(adj,chosen[0],chosen[2]))&set(path(adj,chosen[1],chosen[2]))
    assert len(med)==1
    root=med.pop();c=z[root]
    arm_coord={}
    for nbr in adj[root]:
        component=set();todo=[nbr]
        for v in todo:
            component.add(v)
            for w in adj[v]:
                if w!=root and w not in component and w not in todo:todo.append(w)
        js=[j for j,v in enumerate(chosen) if v in component]
        assert len(js)==1
        j=js[0];arm_coord[nbr]=j
        for v in component:
            p=path(adj,root,v)
            for a,b in zip(p,p[1:]):
                assert z[b][j]>z[a][j]
                assert all(z[b][k]<=z[a][k] for k in range(3) if k!=j)
    vol=lambda x:(x[0]+1)*(x[1]+1)*(x[2]+1)
    m=sum(map(vol,z));twosigma=sum(vol(x)*sum(x) for x in z)
    for a,b in E:
        x=tuple(min(v,w) for v,w in zip(z[a],z[b]))
        m-=vol(x);twosigma-=vol(x)*sum(x)
    assert m==len(T) and twosigma==2*sum(map(sum,T))
    for x in T:
        beyond=[j for j in range(3) if x[j]>c[j]]
        assert len(beyond)<=1
    return dict(m=len(T),q=len(z),leaves=len(leaves),central=list(c))


def main():
    rng=random.Random(60392026);rows=[]
    for case in range(200):
        A,B,C=[rng.randint(2,12) for _ in range(3)]
        f=sorted([rng.randint(1,B) for _ in range(A)],reverse=True)
        g=sorted([rng.randint(1,C) for _ in range(A)],reverse=True)
        h=sorted([rng.randint(1,C) for _ in range(B)],reverse=True)
        T={(x,y,z) for x in range(A) for y in range(f[x]) for z in range(min(g[x],h[y]))}
        rows.append(check(T))
    result={'count':len(rows),'largest_m':max(x['m'] for x in rows),'largest_q':max(x['q'] for x in rows),'status':'All exact assertions passed.'}
    Path(__file__).with_name('clique_tree_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':main()
