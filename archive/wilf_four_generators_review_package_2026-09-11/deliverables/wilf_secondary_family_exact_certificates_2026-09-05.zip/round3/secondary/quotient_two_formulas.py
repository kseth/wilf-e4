import sys,json
sys.path.insert(0,'prior/wilf_edim4_six_point_verification_2026-09-05')
from wilf_work import inspect

def gapform(z,a,b):
 if z<0:return None
 # Unique representation z=ab-u*a-v*b for a positive gap.
 u=(-z*pow(a,-1,b))%b
 v=(a*b-u*a-z)//b
 if not(1<=u<b and 1<=v<a):return None
 assert z==a*b-u*a-v*b
 return u,v

def inspect_pair(a,b,q):
 F=a*b-a-b
 gaps=[z for z in range(1,F//q+1) if gapform(q*z,a,b)]
 if not gaps or gaps!=list(range(1,2*len(gaps),2)):
  raise ValueError(('not mult2 quotient',a,b,q,gaps))
 g=len(gaps)
 forms=[gapform(q*(2*j-1),a,b) for j in range(1,g+1)]
 D=[u*v for u,v in forms]+[0]
 H=[D[j]-D[j+1] for j in range(g)]
 delta=[min(u*a,v*b) for u,v in forms]+[0]
 assert all(h>=0 for h in H)
 return dict(F=F,g=g,forms=forms,D=D,H=H,delta=delta)

def formulas(p,q,a,b,c,d):
 A=inspect_pair(a,b,q);B=inspect_pair(c,d,p)
 assert A['g']==B['g']
 gamma=A['g'];P=p*q;X=p*A['F']+q*B['F']
 G0=(X+P+1)//2
 assert 2*G0==X+P+1
 genus=G0-p*A['D'][0]-q*B['D'][0]+sum(x*y for x,y in zip(A['H'],B['H']))
 losses=[2*P*j+p*A['delta'][j]+q*B['delta'][j] for j in range(gamma+1)]
 L=min(losses);F=X+P-L;cS=F+1;n=cS-genus;W=4*n-cS
 data=dict(gens=sorted([p*a,p*b,q*c,q*d]),params=dict(p=p,q=q,a=a,b=b,c=c,d=d),quotient_genus=gamma,A=A,B=B,losses=losses,L=L,F=F,genus=genus,n=n,W=W)
 return data

if __name__=='__main__':
 cases=[(11,17,5,9,4,5),(149,101,25,34,30,37),(31,37,23,28,17,28),(49,43,23,40,29,40),(43,37,19,36,25,36)]
 out=[]
 for params in cases:
  data=formulas(*params);r=inspect(data['gens'],False)
  assert data['F']==r['c']-1,(params,data,r)
  assert data['genus']==r['g'],(params,data,r)
  assert data['W']==r['W']
  out.append(data)
 print(json.dumps(out,indent=2))
 open('round3/secondary/quotient_two_checks.json','w').write(json.dumps(out,indent=2))
