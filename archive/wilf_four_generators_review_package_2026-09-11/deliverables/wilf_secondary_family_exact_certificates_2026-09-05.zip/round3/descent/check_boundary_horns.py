"""Exact rational checks of the boundary-profile horn formulas."""
from fractions import Fraction as F
from pathlib import Path
import json


def j(m,x,y):
    return m*x**3/6-x**4/4+m*x*y**2/2-3*x*x*y*y/4-x*y**3/2


def constant_large_primitive(m,y,u):
    return y*(m*u*u/2-m*y*u-u**3/2+3*y*u*u/4)


def horn(m,x,y,k):
    return j(m,k,y)+constant_large_primitive(m,y,x+y)-constant_large_primitive(m,y,k+y)


checked=0
for ia in range(1,15):
    for ib in range(ia,15):
        for ic in range(ib,15):
            a,b,c=map(F,(ia,ib,ic))
            m=a+b+c
            p,q=b-a,c-b
            full=j(m,b,c)+j(m,a,c)+j(m,a,b)-m*a*b*c/2
            assert full == -p**4/6-p**3*q/3-p*p*q*q/4
            improvement=horn(m,b,c,(a+b)/2)-j(m,b,c)
            assert improvement==p*p*q*q/8+p**3*q/24+p**4/192
            optimum=full+improvement
            assert optimum==-p*p*q*q/8-7*p**3*q/24-31*p**4/192
            assert optimum<=0
            checked+=1

result={'status':'all exact checks passed','ordered_central_triples':checked,
        'verified':['full-cap polynomial identity','optimized boundary-horn gain',
                    'nonpositive total moment defect']}
Path(__file__).with_name('boundary_horns_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
