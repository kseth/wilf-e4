"""Exact diagnostics for primitive/small-gap swaps and inverse B edges."""
from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('work', ROOT/'prior/wilf_edim4_verification_2026-09-05/wilf_work.py')
work = importlib.util.module_from_spec(spec)
spec.loader.exec_module(work)


def membership(gens, bound):
    present = [False] * (bound+1)
    present[0] = True
    for v in range(1, bound+1):
        present[v] = any(v >= a and present[v-a] for a in gens)
    return present


def primitives(present, conductor):
    m = next(i for i in range(1, len(present)) if present[i])
    return [v for v in range(1, conductor+m)
            if present[v] and not any(present[i] and present[v-i]
                                     for i in range(1, v//2+1))]


def inspect_swaps(gens):
    source = work.inspect(gens, verify=False)
    assert source is not None
    m, c = source['m'], source['c']
    src = membership(gens, c+3*m)
    gaps = [v for v in range(c) if not src[v]]
    u = gaps[-2]
    swaps = []
    for y in gens:
        if y >= c:
            continue
        deleted = src.copy()
        deleted[y] = False
        for h in range(1, m):
            if not deleted[2*h]:
                continue
            if not all(deleted[h+s] for s in range(1, c) if deleted[s]):
                continue
            target = deleted.copy()
            target[h] = True
            target_gens = primitives(target, c)
            assert min(target_gens) == h
            assert max(i for i in range(c+1) if not target[i])+1 == c
            assert sum(target[:c]) == source['n']
            inverse_B = u < y < c-1
            if inverse_B:
                assert len(target_gens) <= 4
                target_gaps = [v for v in range(c) if not target[v]]
                assert target_gaps[-2] == y
            swaps.append({'removed': y, 'added': h,
                          'target_generators': target_gens,
                          'embedding_dimension': len(target_gens),
                          'inverse_B_edge': inverse_B})
    return {'source': source, 'sub_frobenius': u, 'swaps': swaps,
            'inverse_B_children': sum(s['inverse_B_edge'] for s in swaps)}


fixtures = [inspect_swaps([25,26,30,31]), inspect_swaps([23,24,25,26])]
assert fixtures[0]['swaps'] == []
assert fixtures[0]['inverse_B_children'] == 0
result = {'status': 'all exact diagnostic checks passed', 'fixtures': fixtures}
Path(__file__).with_name('gap_swaps_checks.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
