"""Exact finite diagnostics for one-element primitive deletion."""
from pathlib import Path
import importlib.util
import json
from random import Random

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('work', ROOT/'prior/wilf_edim4_verification_2026-09-05/wilf_work.py')
work = importlib.util.module_from_spec(spec)
spec.loader.exec_module(work)

def minimize(gens):
    gs = set(gens)
    out=[]
    attainable=[False]*(max(gs)+1)
    attainable[0]=True
    for v in range(1,len(attainable)):
        attainable[v]=any(v>=a and attainable[v-a] for a in out)
        if v in gs and not attainable[v]:
            out.append(v)
            attainable[v]=True
    return out

def membership(gens, bound):
    present=[False]*(bound+1)
    present[0]=True
    for v in range(1,bound+1):
        present[v]=any(v>=a and present[v-a] for a in gens)
    return present

def inspect_deletions(gens):
    source=work.inspect(gens,verify=False)
    if source is None or max(gens)>=source['c']:
        return None
    out=[]
    for b in gens[1:]:
        candidates=[a for a in gens if a!=b]+[2*b,3*b]+[b+a for a in gens if a!=b]
        target=minimize(candidates)
        new=[a for a in target if a not in gens]
        bound=source['c']+3*source['m']
        original=membership(gens,bound)
        deleted=membership(target,bound)
        assert [i for i,(x,y) in enumerate(zip(original,deleted)) if x!=y]==[b]
        assert min(target)==source['m']
        assert max(i for i,p in enumerate(deleted) if not p)+1==source['c']
        n=sum(deleted[:source['c']])
        assert n==source['n']-1
        assert 4*n-source['c']==source['W']-4
        assert len(target)==3+len(new)
        out.append({'delete':b,'target_generators':target,'new_primitives':new,
                    'target_embedding_dimension':len(target),
                    'target_actual_W':len(target)*n-source['c'],
                    'target_W4':4*n-source['c']})
    return {'source':source,'deletions':out}

fixtures=[inspect_deletions([25,26,30,31]),inspect_deletions([23,24,25,26])]
rng=Random(33060905)
checked=0
applicable=0
while checked<200:
    m=rng.randrange(8,70)
    gens=[m]+sorted(rng.sample(range(m+1,5*m),3))
    row=inspect_deletions(gens)
    if row is None:continue
    checked+=1
    applicable+=sum(len(x['new_primitives'])<=1 for x in row['deletions'])
result={'status':'all exact diagnostic checks passed','random_semigroups':checked,
        'random_deletions':3*checked,'applicable_random_deletions':applicable,
        'fixtures':fixtures}
Path(__file__).with_name('primitive_deletion_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='fixtures'}))
