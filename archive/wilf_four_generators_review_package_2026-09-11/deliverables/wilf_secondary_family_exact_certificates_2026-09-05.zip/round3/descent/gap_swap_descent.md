# Multiplicity descent by primitive/gap exchange

Let `T` be four-generated, with multiplicity `m`, conductor `c`, and
`W_4=4n-c<0`. Let `y<c` be a minimal generator, let `U=T\{y}`, and suppose
`1<=h<m` is a special gap of `U`: adjoining `h` alone makes a numerical
semigroup. Set `R=U∪{h}`. Then

\[
m(R)=h<m,\quad c(R)=c,\quad g(R)=g(T),\quad n(R)=n(T),
\quad W_4(R)=W_4(T).
\]

Therefore this is a valid counterexample-preserving multiplicity descent
whenever `e(R)<=4`. A negative source forces `e(R)=4`, since the lower
embedding dimensions satisfy Wilf. These statements follow directly from
the fact that exactly one left element is deleted and another is added.

## A known sufficient condition: the inverse B transform

Carmelo Cisto, *On some numerical semigroup transforms* (2022),
[arXiv:2209.05803](https://arxiv.org/pdf/2209.05803), studies the
Bras-Amorós transform `B(S)=(S∪{u(S)})\{m(S)}`, where `u` is the
second-largest gap. Theorem 6.5 describes its inverse edges exactly by the
exchange above with `u(T)<y<c-1`. Proposition 6.7 gives
`e(B(S))>=e(S)`. Thus every such inverse edge satisfies the required
dimension condition. Proposition 6.9 reduces counterexamples to leaves.

In embedding dimension four, every step of this descent preserves that
dimension, reduces multiplicity, and fixes the negative Wilf number. It
terminates at a leaf: for every primitive `y` between `u(T)` and `c-1`,
`T\{y}` has no special gap below `m(T)`. This is an existing reduction,
not a proof that all leaves satisfy Wilf.

## A concrete obstruction even to the more general exchange

Consider

\[
T=\langle25,26,30,31\rangle,
\quad c=100,\quad n=30,\quad W_4=20.
\]

Its second-largest gap is `98`, whereas every primitive is at most `31`.
It is therefore a B-tree leaf. In fact **no** primitive `y`, even the
multiplicity itself, allows a special gap `h<25` of `T\{y}`.

Here is a short direct proof. A necessary condition is `2h∈T\{y}`. Since
`0<2h<50`, and the positive elements of `T` below `50` are precisely
`25,26,30,31`, only `h=13` or `h=15` can occur. For `h=13`, both
`h+25=38` and `h+26=39` are gaps. Removing one primitive cannot remove
both obstructions. For `h=15`, the same argument uses the gaps `40,41`.
Thus neither candidate is special after deleting any single primitive.

The fixture also has all four primitives below the conductor, gcd one
for every triple, and nine points in its final Apéry window. It survives
the previously obtained structural filters. Its positive Wilf number
means it does not disprove a further descent theorem conditional on
negativity; that extra implication remains unproved.

The independent exact diagnostic `check_gap_swaps.py` verifies these
invariants, the empty set of exchanges, and the general finite tests used
to find exchanges. Results are in `gap_swaps_checks.json`.

## Combined minimum-counterexample normalization

If counterexamples exist, choose one minimizing the lexicographic tuple
`(c,m,n)`. The already derived inverse cyclic inflation decreases `c`
whenever any triple of minimal generators has gcd greater than one.
The exchange above decreases `m` at fixed `c`; the primitive-deletion
transform in `primitive_deletion.md` decreases `n` at fixed `c,m`.
Consequently, such a minimum counterexample must simultaneously have:

1. Gcd one for every triple of minimal generators.
2. No primitive/small-gap exchange whose target has dimension at most four;
   in particular, it is a B-tree leaf.
3. At least two genuinely new primitives after deleting each nonmultiplicity
   left primitive.

The fixture above satisfies all three obstruction conditions. There is
therefore no unconditional contradiction among these normalizations.
