# Round-three adversarial audit: degenerations and asymptotic density

**Source reviewed:** `deliverables/wilf_fixed_dimension_finite_reduction_2026-09-05.md`.

**Conclusion:** I found no counterexample or hidden degeneration invalidating the fixed-embedding-dimension finite-counterexample theorem. This round concentrated on conceptual attacks rather than repeating the previous line-by-line constant audit. It identifies an important scope limitation, constructs exact hostile test families, and checks relevant primary-source families.

The proof does imply a strict asymptotic density gap when multiplicity tends to infinity at fixed embedding dimension. It does **not** imply such a gap merely when conductor tends to infinity, or outside a finite set of all semigroups at fixed embedding dimension.

## 1. The main degeneration attacks

### Vanishing-volume continuous shapes

One might try downsets that become arbitrarily thin, letting their uniform measures concentrate on a lower-dimensional object whose mean approaches the simplex equality value.

The minimum-coordinate identity prevents this. If

`κ_c=d−(d+1)E[ΣX_i]→0`,

then

`E[min X_i]≥1/[d(d+1)]−κ_c/(d+1)`.

For all sufficiently small deficits, the downset must contain the fixed cube of side `1/[2d(d+1)]`. In particular its volume is bounded below independently of the number or positions of its excluded corners. Thus a vanishing-volume sequence cannot produce the asserted near-equality regime.

More directly, concentration on coordinate faces would force `E[min X_i]→0`, while the slicing inequality would bound the mean by `(d−1)/d+o(1)`, strictly below the equality value `d/(d+1)`.

### Extremely unequal normalized weights

The other natural attack is to let `v=min u_i→0`, keep `U=max u_i` bounded away from zero, and place increasingly many points along the fine direction. Then the pixel correction would not vanish merely because cardinality tends to infinity.

The proof does not silently assume that correction vanishes. Its phase lemma establishes

`U≤64(d+1)^2 κ+8(d+1)v`

when `κ` is small. Cardinality tending to infinity forces `v→0`. Consequently any hypothetical sequence with `κ→0` must also have `U→0`, so **every** pixel side length tends to zero. Conversely, a coarse weight bounded away from zero forces a positive discrete deficit. Arbitrarily large aspect ratios are permitted; what matters is that their absolute normalized side lengths vanish in the near-equality regime.

The coordinate mean bound supplies the reason: `κ→0` forces every weighted coordinate mean to approach at least `1/(d+1)`. A coordinate of negligible statistical contribution cannot quietly disappear from the dimension count. The nonnegative modular fibre deficits then detect a coarse direction against a fine direction.

### Arbitrarily many lower-support excluded vertices

The continuous argument does not bound the number of excluded vertices supported on fewer than d coordinates. Its contradiction uses a fixed finite list of witness points depending only on d. A deficient-support vertex below either outside test point would exclude one of these witnesses, regardless of the number of such vertices. The two outside points must therefore require two distinct full-support vertices, which the arithmetic hypothesis forbids.

This avoids a possible hidden compactness problem: the proof does not presume that a sequence with increasingly complicated boundaries has a limit with the same finite corner representation.

### Exact discrete equality followed by coordinate stretching

There really are small geometric equality examples inside the one-interior-corner class. In dimension three, the ten-point simplex `T={x:Σx_i≤2}` with equal weights has `κ=0` and exactly one full-support excluded corner, `(1,1,1)`. Thus a uniform positive discrete deficit for **all** cardinalities would be false.

The manuscript makes no such claim. Moreover, a natural attempt to turn this into an unbounded counterfamily fails quantitatively. Replace every first-coordinate unit cell of this simplex by N cells and use weights `(1/N,1,1)`. The resulting downset still has only one full-support excluded corner, now `(N,1,1)`, and has `10N` points. Its unnormalized maximum and mean weights are

`M=3−1/N`, `mean=2−1/(2N)`.

Consequently

`κ=3−4 mean/M=(N−1)/(3N−1)→1/3`.

Here `v→0` while `U→1/3`; the deficit becomes positive exactly as the phase lemma requires. The starting ten-point simplex cannot be a residue-bijective Apéry ideal anyway, by the manuscript's independently audited simplex exclusion.

Two further exact diagnostic families were checked:

- Three-column downsets with weights `(0.63,0.63,1/N)` have a limiting deficit about `0.46414`, even though one mesh size vanishes and the others stay coarse.
- The admissible one-interior-corner shell `T_R={x∈N^3:Σx_i≤R, x_1x_2x_3=0}` has `m=1+3R(R+1)/2` and `κ=(R−1)(R−2)/(2m)→1/3`.

These are geometric test families, not asserted numerical-semigroup families. Their exact formulas and checks are retained in the accompanying script.

## 2. The precise density consequence

Let `e=d+1` remain fixed and let multiplicity tend to infinity. The lattice count gives

`v→0`, `m/c→0`, and `M/c→1`.

Under the phase hypothesis, the manuscript proves

`δ_d≤P_d κ+Q_d v`.

Outside that hypothesis, `κ>1/(2d)>δ_d/P_d`. Hence, in all cases,

`liminf κ≥δ_d/P_d`.

The exact Apéry identity can be rewritten as

`n/c = 1/e + κ/e + [(m−1)/(ec)] [κ−(e−2)/2]`.

Since `0≤κ≤d`, the last term tends uniformly to zero as multiplicity grows. Therefore the actual implication is

`liminf_(e(S)=e, m(S)→∞) n(S)/c(S) ≥ 1/e+δ_d/(eP_d)>1/e`.

This is slightly stronger than using the intermediate constant `η_d=δ_d/(2P_d)`. It follows from the manuscript rather than from an external theorem.

The limit formulation matches Zhai's Question 1 in Section 5 of *An asymptotic result concerning a question of Wilf*, arXiv:1111.2779. It does not determine that limit's exact value.

## 3. An important compatible equality family

For every fixed `e≥3` and integer `q≥1`,

`S_q=⟨e,qe+1,qe+2,…,qe+e−1⟩`

has multiplicity `e`, conductor `qe`, and exactly `q` semigroup elements below the conductor. Thus `n/c=1/e` and `W=0` along an infinite sequence of unbounded conductors.

This would refute an assertion of a strict density gap for all but finitely many semigroups at fixed e. It does not refute the manuscript: its multiplicities remain fixed, and equality semigroups are not counterexamples. The current text maintains that distinction. Any presentation of the result should continue to state it explicitly.

In its normalized Apéry ideal, this equality family has the fixed simplex `Δ_1`, with `κ→0` but `v→1`; the cardinality-to-fine-mesh step is therefore inapplicable, exactly as expected.

## 4. A genuine three-generator family approaching density 4/9

To test the low-density regime directly, define, for integers `t≥1`,

`m=3t²+2t`, `A=m+t`, `B=m+2t+1`.

These generate a numerical semigroup of embedding dimension three: their gcd is one, and all three lie below `2m`.

Its Apéry exponent ideal is

`T_t={0≤x≤2t, 0≤y≤2t−1} \ {(x,y):x≥t+1,y≥t}`.

Here `|T_t|=m`. Its three minimal excluded exponents have the reductions

`(2t+1,0)→(0,t)`, `(0,2t)→(t,0)`, `(t+1,t)→(0,0)`.

The corresponding weight differences are respectively `(t+1)m`, `(t+1)m`, and `(2t+2)m`, all positive. Every exponent therefore reduces to `T_t` with the same residue and no larger weight. Since the generators generate every residue and `|T_t|=m`, its labels are residue-bijective and are exactly the Apéry set.

Direct moment summation gives

`c=9t³+5t²−4t`,

`g=5t³+3t²−2t`,

`n=4t³+2t²−2t`.

Thus `n/c→4/9`, comfortably above `1/3`. The exact formulas were independently compared with Dijkstra-computed Apéry sets at eight parameter values through `t=100` (`m=30200`). This family is derived here for the audit; no claim of a new family or of an optimal universal density is made.

I also inspected Fel's primary-source analysis of three-generated semigroups, arXiv:2406.13580v2 (March 2025). Its rescaled-genus estimates do not supply a conflicting family with multiplicity tending to infinity and density tending to `1/3`.

## 5. Current primary-source four-generator families

Chomicz, *On numerical semigroups with embedding dimension four*, arXiv:2604.25653v1, gives explicit Frobenius and genus formulas for four consecutive squares and four consecutive triangular numbers. Taking ratios of their leading coefficients yields:

| Family / congruence branch | Limit of n/c |
| --- | ---: |
| Four consecutive squares, starting index 0 or 1 mod 4 | 31/66 |
| Four consecutive squares, starting index 2 or 3 mod 4 | 1/2 |
| Four consecutive triangular numbers, even starting index | 23/48 |
| Four consecutive triangular numbers, odd starting index | 35/72 |

All have growing multiplicity and limits strictly above `1/4`. These are limits derived from that paper's Corollaries 4.1–4.2 and 5.1–5.2, not a sharp classification of low-density four-generated semigroups.

Targeted searches using two search engines did not locate a verified fixed-e family contradicting the strict multiplicity-asymptotic gap. That search result is limited evidence, not proof that no such publication or example exists.

## 6. Assessment and limitations

The most plausible conceptual failure modes—vanishing volume, dimension collapse, unequal meshes, proliferation of lower-support corners, and stretching small equality ideals—are addressed by explicit parts of the proof. I found no hidden assumption of convexity, comparable generator sizes, bounded numbers of lower-support corners, or nondegenerate limiting volume.

The all-dimension finite-generator bound also prevents a fixed multiplicity and unbounded conductor from supplying infinitely many negative Wilf numbers. Its exception at `m=e` is handled separately and allows the known infinite equality family.

This review therefore supports the claimed mathematical progress, subject to external mathematical review. It does not prove the remaining four-generator region empty. Numerical diagnostics here test formulas and attempted degenerations; they are not a universal enumeration certificate.

## Sources and reproduction

- Final manuscript: `deliverables/wilf_fixed_dimension_finite_reduction_2026-09-05.md`.
- Zhai: https://arxiv.org/pdf/1111.2779
- Fel: https://arxiv.org/pdf/2406.13580
- Chomicz: https://arxiv.org/html/2604.25653v1
- Exact script: `round3/audit/check_degenerate_families.py`.
- Output: `round3/audit/degenerate_families_checks.json`.

Root retrieval note: Chomicz was directly opened and its summary formulas found in source refs `turn228867view0`, `turn647273view0`, `turn647273view1`, `turn647273view2`; Fel in `turn322149view0`, `turn844676view0`, `turn844676view1`. Root should open the URLs itself before using those citations.
