"""Exact diagnostic families for the conceptual stability audit.

Finite checks support explicit analytic families; they are not proof of a
universal Wilf statement or a search of the remaining finite region.
"""
from fractions import Fraction as Q
from heapq import heappush, heappop
from pathlib import Path
import json


def apery(gens):
    m=min(gens)
    ds=[None]*m
    ds[0]=0
    todo=[(0,0)]
    while todo:
        value,res=heappop(todo)
        if ds[res]!=value:
            continue
        for a in gens[1:]:
            nr=(res+a)%m
            nv=value+a
            if ds[nr] is None or nv<ds[nr]:
                ds[nr]=nv
                heappush(todo,(nv,nr))
    assert all(x is not None for x in ds)
    M=max(ds)
    c=M-m+1
    g=Q(sum(ds),m)-Q(m-1,2)
    assert g.denominator==1
    return ds,c,int(g)


results={"three_generator_family":[],"coarse_weight_family":[],"coordinate_plane_shell":[],"stretched_equality_simplex":[]}

# Genuine cyclic L-shaped Apéry family.
for n in [1,2,3,5,10,20,50,100]:
    m=3*n*n+2*n
    a=m+n
    b=m+2*n+1
    T=[(x,y) for x in range(2*n+1) for y in range(2*n)
       if not(x>=n+1 and y>=n)]
    assert len(T)==m
    labels=[a*x+b*y for x,y in T]
    assert len({x%m for x in labels})==m
    ds,c,g=apery([m,a,b])
    assert sorted(ds)==sorted(labels)
    assert c==9*n**3+5*n*n-4*n
    assert g==5*n**3+3*n*n-2*n
    N=c-g
    assert N==4*n**3+2*n*n-2*n
    results["three_generator_family"].append({"parameter":n,"multiplicity":m,
        "generators":[m,a,b],"conductor":c,"genus":g,"density":str(Q(N,c)),
        "density_float":float(Q(N,c))})

# Abstract downsets with a coordinate weight staying at .63 while another
# tends to zero. There is no full-support excluded corner.
for N in [100,1000,10000,100000]:
    A=63*N//100
    L=N-A
    m=N+1+2*(L+1)
    total=Q(N*(N+1),2)+2*((L+1)*A+Q(L*(L+1),2))
    kappa=3-4*total/(m*N)
    U=Q(A,N)
    v=Q(1,N)
    # Dimension-three manuscript phase estimate whenever its hypothesis holds.
    if kappa<=Q(1,6):
        assert U<=1024*kappa+32*v
    results["coarse_weight_family"].append({"N":N,"size":m,"U":str(U),
        "v":str(v),"kappa":str(kappa),"kappa_float":float(kappa)})

# Abstract one-interior-corner shell, with all three axis heights diverging.
for R in [3,10,100,1000,100000]:
    m=1+3*R*(R+1)//2
    kappa=Q((R-1)*(R-2),2*m)
    results["coordinate_plane_shell"].append({"R":R,"size":m,
        "kappa":str(kappa),"kappa_float":float(kappa)})

# Start with the ten-point degree-two simplex (kappa=0, one interior corner).
# Stretch only its first coordinate cells by N and give that direction
# weight 1/N. This preserves the unique full-support excluded corner, now
# (N,1,1), but fails to preserve the zero discrete deficit.
for N in [1,2,10,100,10000,10**12]:
    M=3-Q(1,N)
    mean=2-Q(1,2*N)
    kappa=3-4*mean/M
    assert kappa==Q(N-1,3*N-1)
    results["stretched_equality_simplex"].append({"N":N,"size":10*N,
        "U":str(1/M),"v":str(1/(N*M)),"kappa":str(kappa),
        "kappa_float":float(kappa)})

out=Path(__file__).with_name('degenerate_families_checks.json')
out.write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:v[-1] for k,v in results.items()},indent=2))
