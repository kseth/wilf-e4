# Exact positivity certificate for the secondary quotient-two family

5 September 2026. This is a completed proof for the specified unbounded family. It does not prove the unrestricted four-generator conjecture. The proof and certificate were independently checked by the invariant-formula and audit agents; external mathematical review remains outstanding.

## The theorem certified

Let

\[
S=p\langle a,b\rangle+q\langle c,d\rangle
\]

be a minimally four-generated numerical semigroup, with coprime positive integers \(p,q\), two-generated numerical semigroups \(A=\langle a,b\rangle\) and \(B=\langle c,d\rangle\), and

\[
A/q=B/p=R=\langle2,2g+1\rangle,\qquad g\ge1.
\]

Assume the secondary interior property

\[
q(R\setminus\{0\})\subseteq (a+b)+A,
\qquad
p(R\setminus\{0\})\subseteq(c+d)+B.
\]

Then its Wilf number satisfies

\[
W_4(S)=4|S\cap[0,c(S))|-c(S)\ge1.
\]

In particular, this proves Wilf strictly for every secondary semigroup whose common quotient has multiplicity two. There is no bound on \(g\), the multiplicity or conductor of \(S\), its type, or its final-window cardinality.

## Analytic inputs and their audit

The exact genus and conductor formulas are proved in `../secondary/quotient_two_exact_formulas.md`, Sections 1–4. They have been independently audited, with attention to the following potential failure points.

1. Every normalized residue fibre is exactly \(\langle2,2h+1\rangle\), including \(h=0\), because it contains all even positions and a tail of odd positions. Reflection by two-generated symmetry preserves \(h\) and sends the minimum to \(F_A+q-2qh-A_u\). For \(h=0\), the normalized Frobenius number is \(-1\); the same expression remains valid.
2. For a positive gap \(z=ab-ua-vb\), the colon ideal is \((ua+A)\cup(vb+A)\). Its complement is the rectangle of canonical factorizations \(0\le i<u,0\le j<v\), hence has \(uv\) elements. This justifies the finite differences used in the genus expression, rather than merely matching examples.
3. In the conductor calculation, minimizing over normalized fibre types commutes with minimizing over \(0\le j\le g\): the elementary expression \(j+(h-j)_++(k-j)_+\) is at least \(\max(h,k)\), with equality at \(j=\max(h,k)\). Unrealized fibre types contribute infinity and cause no extra assumption.
4. The secondary hypothesis supplies the strict integer inequalities needed below. Its positive parameters can be oriented as

\[
\begin{aligned}
a&=2\beta+(2g-1)s,& b&=2\alpha+(2g-1)r,
&q&=r\beta+s\alpha+(2g-1)rs,\\
c&=2\beta'+(2g-1)s',& d&=2\alpha'+(2g-1)r',
&p&=r'\beta'+s'\alpha'+(2g-1)r's',
\end{aligned}
\]

with all parameters positive integers and

\[
0<x=\alpha/r\le y=\beta/s,\quad x<1,
\qquad
0<z=\alpha'/r'\le w=\beta'/s',\quad z<1.
\]

For clarity about strictness, the gap representation of the final missing odd multiple is \((2g-1)q=ab-\alpha a-\beta b\). For the next odd multiple set \(U=\alpha-r,V=\beta-s\), so \((2g+1)q=ab-Ua-Vb\). Both \(U,V>0\) would still give a gap. If \(U,V\ge0\) with a zero coefficient, this is a pure-axis element at most \(ab\) which cannot remain in \(A\) after subtracting \(a+b\). If \(U<0\), subtraction has the nonnegative representation \((-U-1)a+(a-V-1)b\); the other case is symmetric. Thus the required interior property forces \(\alpha<r\) or \(\beta<s\), and after ordering the ratios, it forces \(x<1\). Consequently

\[
\frac1r\le\min(x,1-x),\quad \frac1s\le\min(y,1),
\quad \frac1{r'}\le\min(z,1-z),\quad \frac1{s'}\le\min(w,1).
\]

These bounds use both \(\alpha\ge1\) and \(r-\alpha\ge1\). Discarding the strict secondary condition would invalidate the latter bound.

## Reduction to one piecewise polynomial

Put \(V=rsr's'>0\), \(h=g-1\ge0\), \(k=2h+1\),

\[
Q=k+x+y,\qquad P=k+z+w,
\qquad D_A=(h+x)(h+y),\quad D_B=(h+z)(h+w).
\]

The normalized genus-product sum and an upper bound for the normalized conductor correction are

\[
H=hPQ-h(h+1)(P+Q)+\frac23h(h+1)(2h+1)+xyzw,
\]

\[
L_h=2PQh+P(k+2y)x+Q(k+2w)z.
\]

In fact \(H=V^{-1}\sum_jH_j^AH_j^B\) and \(L/V\le L_h\). The proof below only needs this inequality; it does not assume which of the two conductor branches attains the minimum.

Define \(f(t)=\min(t,1-t)\) on \([0,1]\) and \(j(t)=\min(t,1)\) on \([0,\infty)\). The exact invariant expression and the inverse-integer bounds give

\[
W_4(S)\ge V\,\Psi(h,x,y,z,w)+1,
\]

where

\[
\begin{aligned}
\Psi={}&P(k+2x)(k+2y)+Q(k+2z)(k+2w)+PQ\\
&+4PD_A+4QD_B-4H-3L_h\\
&-P\{f(x)(k+2y)+j(y)(k+2x)\}\\
&-Q\{f(z)(k+2w)+j(w)(k+2z)\}.
\end{aligned}
\]

For example, the negative term \(p(a+b)/V\) is

\[
P\left(\frac{k+2y}{r}+\frac{k+2x}{s}\right)
\le P\{f(x)(k+2y)+j(y)(k+2x)\}.
\]

All sign directions therefore agree with the lower bound on \(W_4\). It remains to prove \(\Psi\ge0\) on the relaxed domain

\[
h\ge0,\quad 0\le x\le1,\quad y\ge x,
\quad 0\le z\le1,\quad w\ge z.
\]

## The exact finite certificate

For each \((\epsilon_x,\epsilon_z,\epsilon_y,\epsilon_w)\in\{0,1\}^4\), substitute

\[
x=(\epsilon_x+X)/2,\quad z=(\epsilon_z+Z)/2,
\qquad X,Z\in[0,1].
\]

When \(\epsilon_y=0\), put \(y=x+(1-x)Y\), with \(Y\in[0,1]\). When \(\epsilon_y=1\), put \(y=1+Y\), with \(Y\ge0\). Apply the corresponding choice to \(w\) using \(z,W,\epsilon_w\). These sixteen regions cover the domain, including all shared boundaries. The functions \(f,j\) have a fixed polynomial expression on each region.

In the variable order \((h,X,Y,Z,W)\), retain the power basis for unbounded variables, and use the Bernstein basis

\[
B_i^d(t)=\binom di t^i(1-t)^{d-i}
\]

in each bounded coordinate. Every resulting tensor-product basis function is nonnegative on its region. If \(c_e\) are the power coefficients, the mixed-basis coefficients are exactly

\[
b_\ell=
\sum_{\substack{e_i\le\ell_i\ (i\text{ bounded})\\
e_i=\ell_i\ (i\text{ unbounded})}}
c_e\prod_{i\text{ bounded}}
\frac{\binom{\ell_i}{e_i}}{\binom{d_i}{e_i}}.
\]

`quotient_two_certificate.py` performs this conversion using only exact rational arithmetic. It then performs a separate reverse calculation: every Bernstein basis function is expanded as \(\binom di t^i(1-t)^{d-i}\), and the resulting power polynomial is required to equal the original polynomial coefficient by coefficient. Thus the conversion is checked by an exact identity, as well as by an independent human audit of the formula.

The outcomes below hold for each of the four choices of \((\epsilon_x,\epsilon_z)\).

| Bounds on \(y,w\) | Coordinate degrees \((h,X,Y,Z,W)\) | Coefficients | Minimum |
| --- | --- | ---: | ---: |
| \(y\le1,w\le1\) | \((3,2,1,2,1)\) | 144 | \(8/3\) |
| \(y\le1,w\ge1\) | \((3,2,1,1,1)\) | 96 | 0 |
| \(y\ge1,w\le1\) | \((3,1,1,2,1)\) | 96 | 0 |
| \(y\ge1,w\ge1\) | \((3,1,1,1,1)\) | 64 | 0 |

All \(4(144+96+96+64)=1600\) rational coefficients are nonnegative, and all sixteen reverse expansions are exact. Hence \(\Psi\ge0\), proving \(W_4(S)\ge1\).

## Reproduction and files

Run with a standard Python 3 installation; no third-party package is needed:

```sh
python round3/audit/quotient_two_certificate.py
```

The program asserts all coefficient signs, all reverse expansion identities, and the total coefficient count. Its final line is:

```text
PASS: all 1600 coefficients are nonnegative; all 16 basis expansions reconstruct exactly.
```

The full certificate `quotient_two_certificate_full.json` records the region flags, bounded coordinates, coordinate degrees, original power coefficients, and every mixed-basis coefficient as an exact rational number. `quotient_two_certificate_summary.json` records the compact per-region results. These are finite exact proof data, not a parameter search or floating-point evidence.

The original exact invariant formulas also agree with independent shortest-path Apéry computations on the five examples recorded in `../secondary/quotient_two_checks.json`. Those computations provide implementation checks; the family theorem follows from the analytic identities and the exact polynomial certificate.
