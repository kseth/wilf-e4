from fractions import Fraction as Q
from math import comb
from itertools import product
import json
from pathlib import Path


class Poly:
    def __init__(self,p=0):
        self.p=p.p.copy() if isinstance(p,Poly) else ({(0,)*5:Q(p)} if p else {})
    @staticmethod
    def var(i):
        p=Poly();exp=[0]*5;exp[i]=1;p.p={tuple(exp):Q(1)};return p
    def __add__(self,b):
        b=Poly(b);c=Poly(self)
        for e,v in b.p.items():c.p[e]=c.p.get(e,0)+v
        c.p={e:v for e,v in c.p.items() if v};return c
    __radd__=__add__
    def __neg__(self):
        p=Poly();p.p={e:-v for e,v in self.p.items()};return p
    def __sub__(self,b):return self+-Poly(b)
    def __rsub__(self,b):return Poly(b)+-self
    def __mul__(self,b):
        b=Poly(b);c=Poly()
        for e,v in self.p.items():
            for f,w in b.p.items():
                ef=tuple(x+y for x,y in zip(e,f));c.p[ef]=c.p.get(ef,0)+v*w
        c.p={e:v for e,v in c.p.items() if v};return c
    __rmul__=__mul__
    def __pow__(self,n):
        p=Poly(1)
        for _ in range(n):p=p*self
        return p
    def eval(self,x):return sum(v*__import__('functools').reduce(lambda a,b:a*b,(t**k for t,k in zip(x,e)),Q(1)) for e,v in self.p.items())


def build(flags,intervals=None):
    # flags: x,z upper/lower half; y,w above/below one.
    hx,hz,hy,hw=flags
    h,X,Y,Z,W=[Poly.var(i) for i in range(5)]
    if intervals is not None:
        X=intervals[0][0]+(intervals[0][1]-intervals[0][0])*X
        Y=intervals[1][0]+(intervals[1][1]-intervals[1][0])*Y
        Z=intervals[2][0]+(intervals[2][1]-intervals[2][0])*Z
        W=intervals[3][0]+(intervals[3][1]-intervals[3][0])*W
    x=(hx+X)*Q(1,2);z=(hz+Z)*Q(1,2)
    y=1+Y if hy else x+(1-x)*Y
    w=1+W if hw else z+(1-z)*W
    fx=1-x if hx else x;fz=1-z if hz else z
    fy=1 if hy else y;fw=1 if hw else w
    k=2*h+1;P=k+z+w;R=k+x+y
    ab=(k+2*x)*(k+2*y);cd=(k+2*z)*(k+2*w)
    DA=(x+h)*(y+h);DB=(z+h)*(w+h)
    HH=h*P*R-h*(h+1)*(P+R)+Q(2,3)*h*(h+1)*(2*h+1)+x*y*z*w
    loss=2*P*R*h+P*(k+2*y)*x+R*(k+2*w)*z
    correction=P*(fx*(k+2*y)+fy*(k+2*x))+R*(fz*(k+2*w)+fw*(k+2*z))
    out=P*ab+R*cd+P*R+4*P*DA+4*R*DB-4*HH-3*loss-correction
    bounded=[1,3]+([] if hy else [2])+([] if hw else [4])
    return out,bounded


def bernstein(poly,bounded):
    deg=[max((e[i] for e in poly.p),default=0) for i in range(5)]
    out={}
    for ex in product(*(range(d+1) for d in deg)):
        b=Q(0)
        for e,v in poly.p.items():
            scale=Q(1)
            for i in range(5):
                if i in bounded:
                    if e[i]>ex[i]:scale=0;break
                    scale*=Q(comb(ex[i],e[i]),comb(deg[i],e[i]))
                elif e[i]!=ex[i]:scale=0;break
            b+=v*scale
        out[ex]=b
    return out


def reconstruct(coefficients, degrees, bounded):
    """Expand the mixed basis explicitly, independently of conversion."""
    variables=[Poly.var(i) for i in range(5)]
    basis={}
    for i,(variable,degree) in enumerate(zip(variables,degrees)):
        for j in range(degree+1):
            basis[i,j]=(comb(degree,j)*variable**j*(1-variable)**(degree-j)
                        if i in bounded else variable**j)
    result=Poly()
    for exponent,coefficient in coefficients.items():
        if not coefficient:
            continue
        term=Poly(coefficient)
        for i,j in enumerate(exponent):
            term=term*basis[i,j]
        result=result+term
    return result


if __name__=='__main__':
    summary=[]; certificate=[]
    for flags in product([0,1],repeat=4):
        p,bounded=build(flags)
        bs=bernstein(p,bounded)
        neg=[(k,v) for k,v in bs.items() if v<0]
        degrees=[max((e[i] for e in p.p),default=0) for i in range(5)]
        assert not neg, (flags,neg)
        assert reconstruct(bs,degrees,bounded).p==p.p, flags
        info={'flags':flags,'monomials':len(p.p),'bernstein_count':len(bs),'negative_count':len(neg),'minimum':str(min(bs.values())),'degrees':degrees,'exact_reconstruction':True}
        summary.append(info)
        certificate.append({'flags':flags,'bounded':bounded,'degrees':degrees,
            'power_coefficients':[[list(k),str(v)] for k,v in sorted(p.p.items())],
            'mixed_bernstein_coefficients':[[list(k),str(v)] for k,v in sorted(bs.items())]})
        print(info)
    assert sum(item['bernstein_count'] for item in summary)==1600
    directory=Path(__file__).resolve().parent
    (directory/'quotient_two_certificate_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (directory/'quotient_two_certificate_full.json').write_text(json.dumps({
        'variable_order':['h','X','Y','Z','W'],
        'flag_order':['upper_x_half','upper_z_half','y_at_least_one','w_at_least_one'],
        'all_1600_coefficients_nonnegative':True,
        'all_16_reconstructions_exact':True,
        'regions':certificate},indent=2)+'\n')
    print('PASS: all 1600 coefficients are nonnegative; all 16 basis expansions reconstruct exactly.')
