# Final bounded audit of the arithmetic and structural reductions

5 September 2026. Verdict: the three reviewed reductions are valid within their stated scopes. One displayed algebra typo in the secondary appendix was corrected; no theorem changes. No parameter enumeration was needed for this audit.

## 1. Deflating a triple containing the multiplicity

Reviewed `../gcd_and_extension_reductions.md`. Put \(d=\gcd(m,a_i,a_j)>1\), let \(b\) be the remaining generator, and let \(R=\langle m/d,a_i/d,a_j/d,b\rangle\). The claims remain valid when this displayed generating set is not minimal.

Since \(\gcd(d,b)=1\), multiplication by \(d\) permutes residues modulo \(b\). An Apéry-minimal representative modulo \(b\) in either semigroup has no \(b\) in any factorization. Consequently \(\operatorname{Ap}(S,b)=d\operatorname{Ap}(R,b)\) as sets. This yields the displayed conductor, genus and \(W_4\) identities, without a gluing or membership hypothesis on \(b\) in the three-generator part.

The multiplicity of \(R\) is exactly \(\mu=m/d\), because the other displayed generators are larger. Let \(e_R\) be its actual embedding dimension. For \(2\le e_R\le4\), Zhai's Theorem 1 gives

\[
W_{e_R}(R)\ge-\frac{(\mu-1)(e_R-2)}2.
\]

Since \(W_4(R)=W_{e_R}(R)+(4-e_R)n(R)\), this implies \(W_4(R)\ge-(\mu-1)\). The case \(R=\mathbb N\) has \(\mu=1\) and \(W_4(R)=0\), so it also causes no exception. Therefore

\[
W_4(S)\ge-m+d+(d-1)(b-1)
\ge(d-2)m+d\ge2.
\]

The other-triple reduction is correctly stated only for a counterexample of minimum conductor. Its deflation may change multiplicity, but it strictly decreases conductor and preserves negativity of \(W_4\). If its actual embedding dimension falls below four, known Wilf in dimensions at most three contradicts that negativity. Thus minimum-conductor counterexamples have gcd one in every triple; the argument does not settle all semigroups whose three nonmultiplicity generators share a divisor.

Primary source checked directly: A. Zhai, *An asymptotic result concerning a question of Wilf*, Theorem 1 and Lemma 3, [arXiv:1111.2779](https://arxiv.org/pdf/1111.2779). The new gcd deduction uses only the stated lower bound, not Zhai's asymptotic theorem.

## 2. No-interior ideals and the bipartite case

Reviewed `../no_interior/clique_tree_and_bipartite_bound.md`. The graph and tree claims are valid for nonempty finite lower ideals, as intended for Apéry ideals. An independent second audit also checked Sections 1–3.

An induced cycle of length at least four repeats a coordinate class. Nested external neighborhoods make the two adjacent repeated-class vertices create a chord. Thus the graph is chordal. Its maximal cliques are exactly the maximal boxes, and the clique-tree running-intersection property gives the exact tree inclusion-exclusion formula.

Every leaf uniquely maximizes at least one coordinate, so distinct leaves use distinct coordinates and there are at most three leaves. For completeness, every leaf is among the three selected coordinate-maximum nodes; hence their minimal connecting subtree is the entire clique tree. There is no branch omitted by the median/three-arm description. Along an arm, its outward coordinate increases and the other coordinates decrease; incomparability forces strict growth of the outward coordinate between consecutive nodes.

For the bipartite moment bound, the no-interior assumption is essential: together with the bipartite pair-corner graph it implies that each color-class fibre is a rectangle. If \(\mu_A,\mu_B\) are the weighted coordinate means, moving all coordinates of a color class to its fibre top gives

\[
2\mu_A+\mu_B\le M,\qquad \mu_A+2\mu_B\le M.
\]

The factor two is exact on every finite interval \(0,\ldots,H\), including \(H=0\). Thus \(\mu\le2M/3\) has no discrete endpoint error. For an Apéry ideal,

\[
W_4\ge M/3-(m-1),
\]

which settles \(M\ge3m-3\), equivalently \(c\ge2m-2\). The complementary conductor range is contained in the published \(c\le3m\) range. Hence the entire bipartite no-interior subclass satisfies Wilf. A triangle interaction graph is outside this moment argument; the manuscript correctly leaves it unresolved.

Primary source checked directly: S. Eliahou, *Wilf's conjecture and Macaulay's theorem*, J. Eur. Math. Soc. **20** (2018), 2105–2129, DOI 10.4171/JEMS/807, [published article](https://ems.press/content/serial-article-files/32312). The theorem covers every embedding dimension and includes the endpoint \(c=3m\).

## 3. Secondary common-quotient certificate and arithmetic appendix

The completed certificate theorem assumes the paired form with a common quotient \(\langle2,2g+1\rangle\) and the secondary interior property. Its conclusion \(W_4\ge1\) has no bound on \(g\) or on semigroup invariants. It does not cover arbitrary common quotients or the primary class. The exact invariant formulas, strict integer parameter condition, normalized inequality, 1,600 nonnegative rational coefficients and sixteen exact reconstruction identities were already audited in `quotient_two_wilf_certificate.md`; this scope check found no additional issue.

Section 8's general arithmetic criterion is valid:

\[
q(A/q)^*\subseteq(a+b)+A
\iff \operatorname{lcm}(q,a)>ab\ \text{ and }\ \operatorname{lcm}(q,b)>ab.
\]

It follows from the exact boundary

\[
A\setminus((a+b)+A)
=\{ia:0\le i\le b\}\cup\{jb:1\le j<a\}.
\]

The draft incorrectly displayed \(jb=(b-1)a+(j-a)b\). The coordinator corrected it to \(jb=ba+(j-a)b\), whose two coefficients are positive when \(j\ge a+1\). The boundary set, strict lcm inequalities, and all subsequent conclusions are unchanged. The equality cases \(\operatorname{lcm}=ab\) are correctly excluded.

The unbounded one-sided quotient example is explicitly labeled one-sided, and the paired quotient-multiplicity-three example correctly demonstrates that the certificate family does not exhaust all secondary semigroups. These scope qualifications should remain in the final report.
