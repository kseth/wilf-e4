import random, json


def coefficients(g,x,y,z,w):
    k=2*g-1
    Q=x+y+k
    P=z+w+k
    ab=(2*x+k)*(2*y+k)
    cd=(2*z+k)*(2*w+k)
    DA=(x+g-1)*(y+g-1)
    DB=(z+g-1)*(w+g-1)
    HH=sum((Q-2*j)*(P-2*j) for j in range(1,g))+x*y*z*w
    ls=[P*(2*y+k)*(x+g-1)+Q*(2*w+k)*(z+g-1),
        2*P*Q*(g-1)+P*(2*y+k)*x+Q*(2*w+k)*z,
        2*P*Q*g]
    base=P*ab+Q*cd+P*Q+4*P*DA+4*Q*DB-4*HH-3*min(ls)
    correction=P*(x*(2*y+k)+min(1,y)*(2*x+k))+Q*(z*(2*w+k)+min(1,w)*(2*z+k))
    return base,correction,ls.index(min(ls))


if __name__=='__main__':
    rng=random.Random(104)
    best=(float('inf'),None)
    for _ in range(200000):
        g=rng.choice([1,2,3,4,8,15,50])
        x=10**rng.uniform(-3,0)
        z=10**rng.uniform(-3,0)
        y=10**rng.uniform(__import__('math').log10(x),2)
        w=10**rng.uniform(__import__('math').log10(z),2)
        B,C,branch=coefficients(g,x,y,z,w)
        score=(B-C)/(1+B+C)
        if score<best[0]:best=(score,(g,x,y,z,w,B,C,branch))
    print(best)
