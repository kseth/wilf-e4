"""Package source proofs, exact certificates, and historical dependencies."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT/'deliverables/wilf_secondary_family_exact_certificates_2026-09-05.zip'
REPORT = ROOT/'deliverables/wilf_secondary_family_and_remaining_gaps_2026-09-05.md'

README = '''# Wilf research checkpoint, 5 September 2026

The unrestricted four-generator conjecture is not proved or disproved here.
The main manuscript completes the explicitly specified secondary family
with common quotient <2,2g+1>, and records additional proved reductions.

Run from this directory with standard Python 3:

    python3 round3/verify_checkpoint.py

This reproduces the exact nonnegative polynomial certificate (1,600 rational
coefficients and sixteen reverse identities), independent invariant checks,
the unbounded shell certificate, the full-cap boundary-profile identities,
and the exact counterexample to the simpler taper ansatz. A passing run
does not assert a solution of unrestricted Wilf.

Read the main manuscript first. Detailed source proofs, audits, full rational
certificate data, and recorded diagnostic results are under round3/.
Diagnostic LP/MILP and optimization scripts additionally require NumPy/SciPy;
they are not needed by the standard-library certificate runner.

The historical fixed-dimension reduction reports and original verification
archive are under dependencies/. Their scope is unchanged: a finite region
is left over, and finiteness does not establish that it is empty.

SHA256SUMS.json records every packaged file other than itself.
'''

files = {}
for path in (ROOT/'round3').rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
        files[str(path.relative_to(ROOT))] = path.read_bytes()
for dirname in (
    'prior/wilf_edim4_six_point_verification_2026-09-05',
    'prior/wilf_edim4_reassessment_checks_2026-09-05',
    'prior/wilf_edim4_verification_2026-09-05',
):
    for path in (ROOT/dirname).glob('*.py'):
        files[str(path.relative_to(ROOT))] = path.read_bytes()
for name in (
    'wilf_fixed_dimension_finite_reduction_2026-09-05.md',
    'wilf_fixed_dimension_finite_reduction_checks_2026-09-05.zip',
    'wilf_edim4_global_finite_reduction_2026-09-05.md',
):
    files['dependencies/'+name] = (ROOT/'deliverables'/name).read_bytes()
files[REPORT.name] = REPORT.read_bytes()
files['README.md'] = README.encode()
manifest = {name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}
files['SHA256SUMS.json'] = (json.dumps(manifest,indent=2)+'\n').encode()
with ZipFile(OUT, 'w', ZIP_DEFLATED) as archive:
    for name,data in sorted(files.items()):
        archive.writestr(name,data)
with ZipFile(OUT) as archive:
    assert archive.testzip() is None
print(OUT)
print(f'{len(files)} files; {OUT.stat().st_size} bytes')
