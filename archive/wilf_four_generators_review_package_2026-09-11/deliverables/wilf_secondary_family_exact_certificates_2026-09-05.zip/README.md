# Wilf research checkpoint, 5 September 2026

The unrestricted four-generator conjecture is not proved or disproved here.
The main manuscript completes the explicitly specified secondary family
with common quotient <2,2g+1>, and records additional proved reductions.

Run from this directory with standard Python 3:

    python3 round3/verify_checkpoint.py

This reproduces the exact nonnegative polynomial certificate (1,600 rational
coefficients and sixteen reverse identities), independent invariant checks,
the unbounded shell certificate, the full-cap boundary-profile identities,
and the exact counterexample to the simpler taper ansatz. A passing run
does not assert a solution of unrestricted Wilf.

Read the main manuscript first. Detailed source proofs, audits, full rational
certificate data, and recorded diagnostic results are under round3/.
Diagnostic LP/MILP and optimization scripts additionally require NumPy/SciPy;
they are not needed by the standard-library certificate runner.

The historical fixed-dimension reduction reports and original verification
archive are under dependencies/. Their scope is unchanged: a finite region
is left over, and finiteness does not establish that it is empty.

SHA256SUMS.json records every packaged file other than itself.
